import React, { useState } from 'react'
import { 
    Modal, 
    ModalTitle, 
    ModalContent, 
    ModalActions, 
    Button, 
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const DatasetFormModal = ({ 
    isOpen, 
    onClose, 
    onSave, 
    dataset = null, // For editing existing dataset
    availableDataElements = [],
    availableOrgUnits = [],
    availableCategoryOptions = [],
    availableIndicators = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: dataset?.name || '',
        shortName: dataset?.shortName || '',
        code: dataset?.code || '',
        description: dataset?.description || '',
        
        // Period and Timing
        periodType: dataset?.periodType || 'Monthly',
        openFuturePeriods: dataset?.openFuturePeriods || 0,
        expiryDays: dataset?.expiryDays || 0,
        timelyDays: dataset?.timelyDays || 15,
        
        // Data Elements and Categories
        dataElements: dataset?.dataElements || [],
        categoryCombo: dataset?.categoryCombo || 'default',
        
        // Organization Units
        organisationUnits: dataset?.organisationUnits || [],
        
        // Form and Display
        formType: dataset?.formType || 'default',
        dataEntryForm: dataset?.dataEntryForm || '',
        renderAsTabs: dataset?.renderAsTabs || false,
        renderHorizontally: dataset?.renderHorizontally || false,
        
        // Workflow and Approval
        workflow: dataset?.workflow || null,
        approvalRequired: dataset?.approvalRequired || false,
        
        // Notifications and Reminders
        notifyCompletingUser: dataset?.notifyCompletingUser || false,
        
        // Access and Sharing
        publicAccess: dataset?.publicAccess || 'r-------',
        
        // Indicators
        indicators: dataset?.indicators || [],
        
        // Mobile
        mobile: dataset?.mobile || false,
        
        // Validation
        skipOffline: dataset?.skipOffline || false,
        dataElementDecoration: dataset?.dataElementDecoration || false,
        
        // Compulsory Data Elements
        compulsoryDataElementOperands: dataset?.compulsoryDataElementOperands || []
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const periodTypes = [
        { value: 'Daily', label: i18n.t('Daily') },
        { value: 'Weekly', label: i18n.t('Weekly') },
        { value: 'WeeklyWednesday', label: i18n.t('Weekly (Wednesday)') },
        { value: 'WeeklyThursday', label: i18n.t('Weekly (Thursday)') },
        { value: 'WeeklySaturday', label: i18n.t('Weekly (Saturday)') },
        { value: 'WeeklySunday', label: i18n.t('Weekly (Sunday)') },
        { value: 'BiWeekly', label: i18n.t('Bi-weekly') },
        { value: 'Monthly', label: i18n.t('Monthly') },
        { value: 'BiMonthly', label: i18n.t('Bi-monthly') },
        { value: 'Quarterly', label: i18n.t('Quarterly') },
        { value: 'SixMonthly', label: i18n.t('Six-monthly') },
        { value: 'SixMonthlyApril', label: i18n.t('Six-monthly April') },
        { value: 'SixMonthlyNov', label: i18n.t('Six-monthly November') },
        { value: 'Yearly', label: i18n.t('Yearly') },
        { value: 'FinancialApril', label: i18n.t('Financial year (April)') },
        { value: 'FinancialJuly', label: i18n.t('Financial year (July)') },
        { value: 'FinancialOct', label: i18n.t('Financial year (October)') }
    ]

    const formTypes = [
        { value: 'default', label: i18n.t('Default') },
        { value: 'section', label: i18n.t('Section') },
        { value: 'custom', label: i18n.t('Custom') }
    ]

    const categoryCombos = [
        { value: 'default', label: i18n.t('Default') },
        { value: 'age_sex', label: i18n.t('Age and Sex') },
        { value: 'dqa_sources', label: i18n.t('DQA Data Sources (Register, Summary, Reported, Corrected)') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'period', label: i18n.t('Period & Timing') },
        { id: 'elements', label: i18n.t('Data Elements') },
        { id: 'orgUnits', label: i18n.t('Organisation Units') },
        { id: 'form', label: i18n.t('Form Design') },
        { id: 'workflow', label: i18n.t('Workflow & Approval') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}
        
        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }
        
        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }
        
        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }
        
        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }
        
        if (!formData.periodType) {
            newErrors.periodType = i18n.t('Period type is required')
        }
        
        if (formData.dataElements.length === 0) {
            newErrors.dataElements = i18n.t('At least one data element is required')
        }
        
        if (formData.organisationUnits.length === 0) {
            newErrors.organisationUnits = i18n.t('At least one organisation unit is required')
        }
        
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: dataset?.id || `ds_${Date.now()}`,
                created: dataset?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the dataset')}
                        />
                    </div>
                )

            case 'period':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Period type')}
                            selected={formData.periodType}
                            onChange={({ selected }) => updateFormData('periodType', selected)}
                            error={!!errors.periodType}
                            validationText={errors.periodType}
                            required
                        >
                            {periodTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <InputField
                            label={i18n.t('Open future periods for data entry')}
                            name="openFuturePeriods"
                            type="number"
                            min="0"
                            max="10"
                            value={formData.openFuturePeriods.toString()}
                            onChange={({ value }) => updateFormData('openFuturePeriods', parseInt(value) || 0)}
                            helpText={i18n.t('Number of future periods that will be available for data entry')}
                        />
                        
                        <InputField
                            label={i18n.t('Days after period end to qualify for timely submission')}
                            name="timelyDays"
                            type="number"
                            min="0"
                            value={formData.timelyDays.toString()}
                            onChange={({ value }) => updateFormData('timelyDays', parseInt(value) || 0)}
                            helpText={i18n.t('Number of days after period end date for timely data submission')}
                        />
                        
                        <InputField
                            label={i18n.t('Expiry days')}
                            name="expiryDays"
                            type="number"
                            min="0"
                            value={formData.expiryDays.toString()}
                            onChange={({ value }) => updateFormData('expiryDays', parseInt(value) || 0)}
                            helpText={i18n.t('Number of days after period end date when data entry will be blocked')}
                        />
                    </div>
                )

            case 'elements':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Data elements')}
                            selected={formData.dataElements}
                            onChange={({ selected }) => updateFormData('dataElements', selected)}
                            error={!!errors.dataElements}
                            validationText={errors.dataElements}
                            helpText={i18n.t('Select data elements to include in this dataset')}
                        >
                            {availableDataElements.map(element => (
                                <MultiSelectOption 
                                    key={element.id} 
                                    value={element.id} 
                                    label={`${element.name} (${element.shortName})`} 
                                />
                            ))}
                        </MultiSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Category combination')}
                            selected={formData.categoryCombo}
                            onChange={({ selected }) => updateFormData('categoryCombo', selected)}
                            helpText={i18n.t('Category combination for data disaggregation')}
                        >
                            {categoryCombos.map(combo => (
                                <SingleSelectOption key={combo.value} value={combo.value} label={combo.label} />
                            ))}
                        </SingleSelectField>
                        
                        {formData.dataElements.length > 0 && (
                            <NoticeBox title={i18n.t('Selected Data Elements')}>
                                {i18n.t('{{count}} data elements selected', { count: formData.dataElements.length })}
                            </NoticeBox>
                        )}
                    </div>
                )

            case 'orgUnits':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Organisation units')}
                            selected={formData.organisationUnits}
                            onChange={({ selected }) => updateFormData('organisationUnits', selected)}
                            error={!!errors.organisationUnits}
                            validationText={errors.organisationUnits}
                            helpText={i18n.t('Select organisation units where this dataset will be used')}
                        >
                            {availableOrgUnits.map(orgUnit => (
                                <MultiSelectOption 
                                    key={orgUnit.id} 
                                    value={orgUnit.id} 
                                    label={orgUnit.name} 
                                />
                            ))}
                        </MultiSelectField>
                        
                        {formData.organisationUnits.length > 0 && (
                            <NoticeBox title={i18n.t('Selected Organisation Units')}>
                                {i18n.t('{{count}} organisation units selected', { count: formData.organisationUnits.length })}
                            </NoticeBox>
                        )}
                    </div>
                )

            case 'form':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Form type')}
                            selected={formData.formType}
                            onChange={({ selected }) => updateFormData('formType', selected)}
                            helpText={i18n.t('Type of data entry form')}
                        >
                            {formTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <CheckboxField
                            label={i18n.t('Render as tabs')}
                            name="renderAsTabs"
                            checked={formData.renderAsTabs}
                            onChange={({ checked }) => updateFormData('renderAsTabs', checked)}
                            helpText={i18n.t('Render sections as tabs in data entry form')}
                        />
                        
                        <CheckboxField
                            label={i18n.t('Render horizontally')}
                            name="renderHorizontally"
                            checked={formData.renderHorizontally}
                            onChange={({ checked }) => updateFormData('renderHorizontally', checked)}
                            helpText={i18n.t('Render data elements horizontally')}
                        />
                        
                        <CheckboxField
                            label={i18n.t('Data element decoration')}
                            name="dataElementDecoration"
                            checked={formData.dataElementDecoration}
                            onChange={({ checked }) => updateFormData('dataElementDecoration', checked)}
                            helpText={i18n.t('Show data element totals and indicators in forms')}
                        />
                        
                        {formData.formType === 'custom' && (
                            <TextAreaField
                                label={i18n.t('Custom data entry form')}
                                name="dataEntryForm"
                                value={formData.dataEntryForm}
                                onChange={({ value }) => updateFormData('dataEntryForm', value)}
                                rows={8}
                                helpText={i18n.t('HTML content for custom data entry form')}
                            />
                        )}
                    </div>
                )

            case 'workflow':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <CheckboxField
                            label={i18n.t('Approval required')}
                            name="approvalRequired"
                            checked={formData.approvalRequired}
                            onChange={({ checked }) => updateFormData('approvalRequired', checked)}
                            helpText={i18n.t('Require approval before data can be used in analytics')}
                        />
                        
                        <CheckboxField
                            label={i18n.t('Notify completing user')}
                            name="notifyCompletingUser"
                            checked={formData.notifyCompletingUser}
                            onChange={({ checked }) => updateFormData('notifyCompletingUser', checked)}
                            helpText={i18n.t('Send notification to user when dataset is completed')}
                        />
                        
                        <CheckboxField
                            label={i18n.t('Skip offline')}
                            name="skipOffline"
                            checked={formData.skipOffline}
                            onChange={({ checked }) => updateFormData('skipOffline', checked)}
                            helpText={i18n.t('Do not download this dataset for offline data entry')}
                        />
                        
                        <CheckboxField
                            label={i18n.t('Mobile')}
                            name="mobile"
                            checked={formData.mobile}
                            onChange={({ checked }) => updateFormData('mobile', checked)}
                            helpText={i18n.t('Make this dataset available for mobile data entry')}
                        />
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this dataset.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {dataset ? i18n.t('Edit Dataset') : i18n.t('Create New Dataset')}
            </ModalTitle>
            
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{ 
                        minWidth: '200px', 
                        borderRight: '1px solid #e0e0e0', 
                        paddingRight: '16px' 
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{ 
                            margin: '0 0 24px 0', 
                            fontSize: '18px', 
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {dataset ? i18n.t('Update Dataset') : i18n.t('Create Dataset')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default DatasetFormModal