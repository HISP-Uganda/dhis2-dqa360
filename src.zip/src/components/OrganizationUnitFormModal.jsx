import React, { useState } from 'react'
import { 
    Modal, 
    ModalTitle, 
    ModalContent, 
    ModalActions, 
    Button, 
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const OrganizationUnitFormModal = ({ 
    isOpen, 
    onClose, 
    onSave, 
    organizationUnit = null, // For editing existing org unit
    availableParentOrgUnits = [],
    availableOrgUnitGroups = [],
    availableOrgUnitGroupSets = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: organizationUnit?.name || '',
        shortName: organizationUnit?.shortName || '',
        code: organizationUnit?.code || '',
        description: organizationUnit?.description || '',
        
        // Hierarchy
        parent: organizationUnit?.parent || null,
        level: organizationUnit?.level || 1,
        path: organizationUnit?.path || '',
        
        // Contact Information
        email: organizationUnit?.email || '',
        phoneNumber: organizationUnit?.phoneNumber || '',
        address: organizationUnit?.address || '',
        
        // Geographic Information
        coordinates: organizationUnit?.coordinates || '',
        featureType: organizationUnit?.featureType || 'NONE',
        
        // Dates
        openingDate: organizationUnit?.openingDate || '',
        closedDate: organizationUnit?.closedDate || '',
        
        // Groups and Sets
        organisationUnitGroups: organizationUnit?.organisationUnitGroups || [],
        
        // Data Collection
        leaf: organizationUnit?.leaf || false,
        
        // Access and Sharing
        publicAccess: organizationUnit?.publicAccess || 'r-------',
        
        // External Reference
        url: organizationUnit?.url || '',
        
        // Comments
        comment: organizationUnit?.comment || ''
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const featureTypes = [
        { value: 'NONE', label: i18n.t('None') },
        { value: 'MULTI_POLYGON', label: i18n.t('Multi-polygon') },
        { value: 'POLYGON', label: i18n.t('Polygon') },
        { value: 'POINT', label: i18n.t('Point') },
        { value: 'SYMBOL', label: i18n.t('Symbol') }
    ]

    const orgUnitLevels = [
        { value: 1, label: i18n.t('Level 1 (Country/National)') },
        { value: 2, label: i18n.t('Level 2 (Region/Province)') },
        { value: 3, label: i18n.t('Level 3 (District/Zone)') },
        { value: 4, label: i18n.t('Level 4 (Facility/Community)') },
        { value: 5, label: i18n.t('Level 5 (Sub-facility)') },
        { value: 6, label: i18n.t('Level 6 (Ward/Village)') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'hierarchy', label: i18n.t('Hierarchy') },
        { id: 'contact', label: i18n.t('Contact Information') },
        { id: 'geographic', label: i18n.t('Geographic Data') },
        { id: 'groups', label: i18n.t('Groups & Sets') },
        { id: 'dates', label: i18n.t('Dates') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}
        
        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }
        
        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }
        
        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }
        
        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }
        
        if (!formData.level || formData.level < 1 || formData.level > 6) {
            newErrors.level = i18n.t('Level must be between 1 and 6')
        }
        
        if (formData.email && !isValidEmail(formData.email)) {
            newErrors.email = i18n.t('Please enter a valid email address')
        }
        
        if (formData.openingDate && formData.closedDate && 
            new Date(formData.openingDate) > new Date(formData.closedDate)) {
            newErrors.closedDate = i18n.t('Closed date must be after opening date')
        }
        
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return emailRegex.test(email)
    }

    const handleSave = () => {
        if (validateForm()) {
            const orgUnitData = {
                ...formData,
                id: organizationUnit?.id || `ou_${Date.now()}`,
                created: organizationUnit?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                // Generate path based on parent and level
                path: formData.parent ? 
                    `${availableParentOrgUnits.find(p => p.id === formData.parent)?.path || ''}/${formData.id || `ou_${Date.now()}`}` :
                    `/${formData.id || `ou_${Date.now()}`}`
            }
            
            onSave(orgUnitData)
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the organization unit')}
                        />
                        
                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                        
                        <TextAreaField
                            label={i18n.t('Comment')}
                            name="comment"
                            value={formData.comment}
                            onChange={({ value }) => updateFormData('comment', value)}
                            rows={3}
                            helpText={i18n.t('Additional comments or notes')}
                        />
                    </div>
                )

            case 'hierarchy':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Parent organisation unit')}
                            selected={formData.parent || ''}
                            onChange={({ selected }) => updateFormData('parent', selected || null)}
                            helpText={i18n.t('Parent organisation unit in the hierarchy')}
                            clearable
                        >
                            {availableParentOrgUnits.map(parent => (
                                <SingleSelectOption 
                                    key={parent.id} 
                                    value={parent.id} 
                                    label={`${parent.name} (Level ${parent.level})`} 
                                />
                            ))}
                        </SingleSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Level')}
                            selected={formData.level}
                            onChange={({ selected }) => updateFormData('level', parseInt(selected))}
                            error={!!errors.level}
                            validationText={errors.level}
                            helpText={i18n.t('Hierarchical level of this organisation unit')}
                            required
                        >
                            {orgUnitLevels.map(level => (
                                <SingleSelectOption 
                                    key={level.value} 
                                    value={level.value.toString()} 
                                    label={level.label} 
                                />
                            ))}
                        </SingleSelectField>
                        
                        <CheckboxField
                            label={i18n.t('Leaf node')}
                            name="leaf"
                            checked={formData.leaf}
                            onChange={({ checked }) => updateFormData('leaf', checked)}
                            helpText={i18n.t('This organisation unit has no children (lowest level for data collection)')}
                        />
                        
                        <NoticeBox title={i18n.t('Hierarchy Information')}>
                            {formData.parent ? 
                                i18n.t('This unit will be a child of the selected parent organisation unit') :
                                i18n.t('This will be a root level organisation unit with no parent')
                            }
                        </NoticeBox>
                    </div>
                )

            case 'contact':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Email')}
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={({ value }) => updateFormData('email', value)}
                            error={!!errors.email}
                            validationText={errors.email}
                            helpText={i18n.t('Contact email address')}
                        />
                        
                        <InputField
                            label={i18n.t('Phone number')}
                            name="phoneNumber"
                            value={formData.phoneNumber}
                            onChange={({ value }) => updateFormData('phoneNumber', value)}
                            helpText={i18n.t('Contact phone number')}
                        />
                        
                        <TextAreaField
                            label={i18n.t('Address')}
                            name="address"
                            value={formData.address}
                            onChange={({ value }) => updateFormData('address', value)}
                            rows={3}
                            helpText={i18n.t('Physical address')}
                        />
                    </div>
                )

            case 'geographic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Feature type')}
                            selected={formData.featureType}
                            onChange={({ selected }) => updateFormData('featureType', selected)}
                            helpText={i18n.t('Type of geographic feature')}
                        >
                            {featureTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <TextAreaField
                            label={i18n.t('Coordinates')}
                            name="coordinates"
                            value={formData.coordinates}
                            onChange={({ value }) => updateFormData('coordinates', value)}
                            rows={4}
                            helpText={i18n.t('Geographic coordinates (GeoJSON format for polygons, lat,lng for points)')}
                        />
                        
                        <NoticeBox title={i18n.t('Geographic Data')}>
                            {formData.featureType === 'POINT' && i18n.t('For points, use format: [longitude, latitude]')}
                            {formData.featureType === 'POLYGON' && i18n.t('For polygons, use GeoJSON coordinate arrays')}
                            {formData.featureType === 'NONE' && i18n.t('No geographic data will be stored')}
                        </NoticeBox>
                    </div>
                )

            case 'groups':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Organisation unit groups')}
                            selected={formData.organisationUnitGroups}
                            onChange={({ selected }) => updateFormData('organisationUnitGroups', selected)}
                            helpText={i18n.t('Groups to categorize this organisation unit')}
                        >
                            {availableOrgUnitGroups.map(group => (
                                <MultiSelectOption 
                                    key={group.id} 
                                    value={group.id} 
                                    label={group.name} 
                                />
                            ))}
                        </MultiSelectField>
                        
                        {formData.organisationUnitGroups.length > 0 && (
                            <NoticeBox title={i18n.t('Selected Groups')}>
                                {i18n.t('{{count}} groups selected', { count: formData.organisationUnitGroups.length })}
                            </NoticeBox>
                        )}
                        
                        <NoticeBox title={i18n.t('Organisation Unit Groups')}>
                            {i18n.t('Groups help categorize organisation units by type (e.g., Hospital, Clinic), ownership (Public, Private), or other criteria.')}
                        </NoticeBox>
                    </div>
                )

            case 'dates':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Opening date')}
                            name="openingDate"
                            type="date"
                            value={formData.openingDate}
                            onChange={({ value }) => updateFormData('openingDate', value)}
                            helpText={i18n.t('Date when this organisation unit started operating')}
                        />
                        
                        <InputField
                            label={i18n.t('Closed date')}
                            name="closedDate"
                            type="date"
                            value={formData.closedDate}
                            onChange={({ value }) => updateFormData('closedDate', value)}
                            error={!!errors.closedDate}
                            validationText={errors.closedDate}
                            helpText={i18n.t('Date when this organisation unit stopped operating (if applicable)')}
                        />
                        
                        <NoticeBox title={i18n.t('Date Information')}>
                            {formData.openingDate && !formData.closedDate && 
                                i18n.t('This organisation unit is currently active')
                            }
                            {formData.closedDate && 
                                i18n.t('This organisation unit is closed and not available for data entry')
                            }
                        </NoticeBox>
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this organisation unit.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {organizationUnit ? i18n.t('Edit Organisation Unit') : i18n.t('Create New Organisation Unit')}
            </ModalTitle>
            
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{ 
                        minWidth: '200px', 
                        borderRight: '1px solid #e0e0e0', 
                        paddingRight: '16px' 
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{ 
                            margin: '0 0 24px 0', 
                            fontSize: '18px', 
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {organizationUnit ? i18n.t('Update Organisation Unit') : i18n.t('Create Organisation Unit')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default OrganizationUnitFormModal