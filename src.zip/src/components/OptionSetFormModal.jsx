import React, { useState } from 'react'
import { 
    Modal, 
    ModalTitle, 
    ModalContent, 
    ModalActions, 
    Button, 
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const OptionSetFormModal = ({ 
    isOpen, 
    onClose, 
    onSave, 
    optionSet = null // For editing existing option set
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: optionSet?.name || '',
        shortName: optionSet?.shortName || '',
        code: optionSet?.code || '',
        description: optionSet?.description || '',
        
        // Value Type
        valueType: optionSet?.valueType || 'TEXT',
        
        // Options
        options: optionSet?.options || [],
        
        // Access and Sharing
        publicAccess: optionSet?.publicAccess || 'r-------',
        
        // External Reference
        url: optionSet?.url || ''
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})
    const [newOption, setNewOption] = useState({
        name: '',
        code: '',
        sortOrder: 1
    })

    const valueTypes = [
        { value: 'TEXT', label: i18n.t('Text') },
        { value: 'INTEGER', label: i18n.t('Integer') },
        { value: 'NUMBER', label: i18n.t('Number') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'options', label: i18n.t('Options') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}
        
        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }
        
        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }
        
        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }
        
        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }
        
        if (!formData.valueType) {
            newErrors.valueType = i18n.t('Value type is required')
        }
        
        if (formData.options.length === 0) {
            newErrors.options = i18n.t('At least one option is required')
        }
        
        // Check for duplicate option codes
        const optionCodes = formData.options.map(opt => opt.code).filter(Boolean)
        const duplicateCodes = optionCodes.filter((code, index) => optionCodes.indexOf(code) !== index)
        if (duplicateCodes.length > 0) {
            newErrors.options = i18n.t('Option codes must be unique')
        }
        
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: optionSet?.id || `os_${Date.now()}`,
                created: optionSet?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const addOption = () => {
        if (!newOption.name.trim()) return
        
        const option = {
            id: `opt_${Date.now()}`,
            name: newOption.name.trim(),
            code: newOption.code.trim() || newOption.name.trim().toUpperCase().replace(/\s+/g, '_'),
            sortOrder: newOption.sortOrder,
            created: new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        }
        
        updateFormData('options', [...formData.options, option])
        setNewOption({ name: '', code: '', sortOrder: formData.options.length + 2 })
        
        // Clear options error when user adds an option
        if (errors.options) {
            setErrors(prev => ({ ...prev, options: null }))
        }
    }

    const removeOption = (optionId) => {
        updateFormData('options', formData.options.filter(opt => opt.id !== optionId))
    }

    const updateOption = (optionId, field, value) => {
        updateFormData('options', formData.options.map(opt => 
            opt.id === optionId ? { ...opt, [field]: value } : opt
        ))
    }

    const moveOption = (optionId, direction) => {
        const currentIndex = formData.options.findIndex(opt => opt.id === optionId)
        if (currentIndex === -1) return
        
        const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1
        if (newIndex < 0 || newIndex >= formData.options.length) return
        
        const newOptions = [...formData.options]
        const [movedOption] = newOptions.splice(currentIndex, 1)
        newOptions.splice(newIndex, 0, movedOption)
        
        // Update sort orders
        newOptions.forEach((opt, index) => {
            opt.sortOrder = index + 1
        })
        
        updateFormData('options', newOptions)
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        
                        <SingleSelectField
                            label={i18n.t('Value type')}
                            selected={formData.valueType}
                            onChange={({ selected }) => updateFormData('valueType', selected)}
                            error={!!errors.valueType}
                            validationText={errors.valueType}
                            helpText={i18n.t('The type of values this option set will contain')}
                            required
                        >
                            {valueTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the option set')}
                        />
                        
                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                    </div>
                )

            case 'options':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        {/* Add New Option */}
                        <div style={{ 
                            padding: '16px', 
                            backgroundColor: '#f8f9fa', 
                            borderRadius: '4px',
                            border: '1px solid #e9ecef'
                        }}>
                            <h4 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600' }}>
                                {i18n.t('Add New Option')}
                            </h4>
                            
                            <div style={{ display: 'flex', gap: '12px', alignItems: 'end' }}>
                                <div style={{ flex: 2 }}>
                                    <InputField
                                        label={i18n.t('Option name')}
                                        name="newOptionName"
                                        value={newOption.name}
                                        onChange={({ value }) => setNewOption(prev => ({ ...prev, name: value }))}
                                        placeholder={i18n.t('Enter option name')}
                                    />
                                </div>
                                
                                <div style={{ flex: 1 }}>
                                    <InputField
                                        label={i18n.t('Code')}
                                        name="newOptionCode"
                                        value={newOption.code}
                                        onChange={({ value }) => setNewOption(prev => ({ ...prev, code: value }))}
                                        placeholder={i18n.t('Auto-generated')}
                                    />
                                </div>
                                
                                <Button 
                                    primary 
                                    onClick={addOption}
                                    disabled={!newOption.name.trim()}
                                >
                                    {i18n.t('Add')}
                                </Button>
                            </div>
                        </div>
                        
                        {errors.options && (
                            <div style={{ 
                                padding: '12px', 
                                backgroundColor: '#f8d7da', 
                                borderRadius: '4px', 
                                border: '1px solid #f5c6cb',
                                color: '#721c24',
                                fontSize: '14px'
                            }}>
                                {errors.options}
                            </div>
                        )}
                        
                        {/* Options List */}
                        {formData.options.length > 0 && (
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Options')} ({formData.options.length})
                                </h4>
                                
                                <div style={{ border: '1px solid #e9ecef', borderRadius: '4px' }}>
                                    <DataTable>
                                        <DataTableHead>
                                            <DataTableRow>
                                                <DataTableColumnHeader>{i18n.t('Order')}</DataTableColumnHeader>
                                                <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                                                <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                                                <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                                            </DataTableRow>
                                        </DataTableHead>
                                        <DataTableBody>
                                            {formData.options.map((option, index) => (
                                                <DataTableRow key={option.id}>
                                                    <DataTableCell>
                                                        <div style={{ display: 'flex', gap: '4px' }}>
                                                            <Button 
                                                                small 
                                                                secondary 
                                                                onClick={() => moveOption(option.id, 'up')}
                                                                disabled={index === 0}
                                                            >
                                                                ↑
                                                            </Button>
                                                            <Button 
                                                                small 
                                                                secondary 
                                                                onClick={() => moveOption(option.id, 'down')}
                                                                disabled={index === formData.options.length - 1}
                                                            >
                                                                ↓
                                                            </Button>
                                                        </div>
                                                    </DataTableCell>
                                                    <DataTableCell>
                                                        <InputField
                                                            dense
                                                            value={option.name}
                                                            onChange={({ value }) => updateOption(option.id, 'name', value)}
                                                        />
                                                    </DataTableCell>
                                                    <DataTableCell>
                                                        <InputField
                                                            dense
                                                            value={option.code}
                                                            onChange={({ value }) => updateOption(option.id, 'code', value)}
                                                        />
                                                    </DataTableCell>
                                                    <DataTableCell>
                                                        <Button 
                                                            small 
                                                            destructive 
                                                            onClick={() => removeOption(option.id)}
                                                        >
                                                            {i18n.t('Delete')}
                                                        </Button>
                                                    </DataTableCell>
                                                </DataTableRow>
                                            ))}
                                        </DataTableBody>
                                    </DataTable>
                                </div>
                            </div>
                        )}
                        
                        {formData.options.length === 0 && (
                            <NoticeBox>
                                {i18n.t('No options added yet. Add at least one option to create a valid option set.')}
                            </NoticeBox>
                        )}
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this option set.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {optionSet ? i18n.t('Edit Option Set') : i18n.t('Create New Option Set')}
            </ModalTitle>
            
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{ 
                        minWidth: '200px', 
                        borderRight: '1px solid #e0e0e0', 
                        paddingRight: '16px' 
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{ 
                            margin: '0 0 24px 0', 
                            fontSize: '18px', 
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {optionSet ? i18n.t('Update Option Set') : i18n.t('Create Option Set')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default OptionSetFormModal