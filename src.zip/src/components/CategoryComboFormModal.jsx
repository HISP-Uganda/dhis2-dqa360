import React, { useState, useEffect } from 'react'
import {
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    Button,
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const CategoryComboFormModal = ({
    isOpen,
    onClose,
    onSave,
    categoryCombo = null, // For editing existing category combo
    availableCategories = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: categoryCombo?.name || '',
        shortName: categoryCombo?.shortName || '',
        code: categoryCombo?.code || '',
        description: categoryCombo?.description || '',

        // Categories
        categories: categoryCombo?.categories || [],

        // Data Dimension
        dataDimensionType: categoryCombo?.dataDimensionType || 'DISAGGREGATION',
        skipTotal: categoryCombo?.skipTotal || false,

        // Access and Sharing
        publicAccess: categoryCombo?.publicAccess || 'r-------',

        // External Reference
        url: categoryCombo?.url || ''
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})
    const [categoryOptionCombos, setCategoryOptionCombos] = useState([])

    const dataDimensionTypes = [
        { value: 'DISAGGREGATION', label: i18n.t('Disaggregation') },
        { value: 'ATTRIBUTE', label: i18n.t('Attribute') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'categories', label: i18n.t('Categories') },
        { id: 'combinations', label: i18n.t('Option Combinations') },
        { id: 'settings', label: i18n.t('Settings') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    // Generate category option combinations when categories change
    useEffect(() => {
        if (formData.categories.length > 0) {
            generateCategoryOptionCombos()
        } else {
            setCategoryOptionCombos([])
        }
    }, [formData.categories, availableCategories])

    const generateCategoryOptionCombos = () => {
        const selectedCategories = formData.categories.map(catId =>
            availableCategories.find(cat => cat.id === catId)
        ).filter(Boolean)

        if (selectedCategories.length === 0) {
            setCategoryOptionCombos([])
            return
        }

        // Get all category options for each category
        const categoryOptionsArrays = selectedCategories.map(category =>
            category.categoryOptions || []
        )

        // Generate all combinations
        const combinations = generateCombinations(categoryOptionsArrays)

        const combos = combinations.map((combo, index) => ({
            id: `coc_${Date.now()}_${index}`,
            name: combo.map(opt => opt.name).join(', '),
            shortName: combo.map(opt => opt.shortName).join(', '),
            categoryOptions: combo.map(opt => opt.id),
            created: new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        }))

        setCategoryOptionCombos(combos)
    }

    const generateCombinations = (arrays) => {
        if (arrays.length === 0) return []
        if (arrays.length === 1) return arrays[0].map(item => [item])

        const result = []
        const restCombinations = generateCombinations(arrays.slice(1))

        for (const item of arrays[0]) {
            for (const restCombo of restCombinations) {
                result.push([item, ...restCombo])
            }
        }

        return result
    }

    const validateForm = () => {
        const newErrors = {}

        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }

        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }

        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }

        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }

        if (formData.categories.length === 0) {
            newErrors.categories = i18n.t('At least one category is required')
        }

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: categoryCombo?.id || `cc_${Date.now()}`,
                categoryOptionCombos: categoryOptionCombos,
                created: categoryCombo?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />

                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />

                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />

                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the category combination')}
                        />

                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                    </div>
                )

            case 'categories':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Categories')}
                            selected={formData.categories}
                            onChange={({ selected }) => updateFormData('categories', selected)}
                            error={!!errors.categories}
                            validationText={errors.categories}
                            helpText={i18n.t('Select categories to combine for data disaggregation')}
                        >
                            {availableCategories.map(category => (
                                <MultiSelectOption
                                    key={category.id}
                                    value={category.id}
                                    label={`${category.name} (${category.categoryOptions?.length || 0} options)`}
                                />
                            ))}
                        </MultiSelectField>

                        {formData.categories.length > 0 && (
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Categories')} ({formData.categories.length})
                                </h4>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    {formData.categories.map(categoryId => {
                                        const category = availableCategories.find(cat => cat.id === categoryId)
                                        return category ? (
                                            <div key={categoryId} style={{
                                                padding: '12px 16px',
                                                backgroundColor: '#f8f9fa',
                                                borderRadius: '4px',
                                                border: '1px solid #e9ecef',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div>
                                                    <div style={{ fontWeight: '500' }}>{category.name}</div>
                                                    <div style={{ fontSize: '12px', color: '#6c757d' }}>
                                                        {category.categoryOptions?.length || 0} {i18n.t('options')}
                                                    </div>
                                                </div>
                                                <Button
                                                    small
                                                    secondary
                                                    onClick={() => {
                                                        updateFormData('categories',
                                                            formData.categories.filter(id => id !== categoryId)
                                                        )
                                                    }}
                                                >
                                                    {i18n.t('Remove')}
                                                </Button>
                                            </div>
                                        ) : null
                                    })}
                                </div>
                            </div>
                        )}

                        <NoticeBox title={i18n.t('Category Combination Information')}>
                            {formData.categories.length === 0 &&
                                i18n.t('No categories selected. A category combination must have at least one category.')
                            }
                            {formData.categories.length === 1 &&
                                i18n.t('This combination has 1 category. Data will be disaggregated by this single dimension.')
                            }
                            {formData.categories.length > 1 &&
                                i18n.t('This combination has {{count}} categories. Data will be disaggregated by all combinations of these dimensions.', { count: formData.categories.length })
                            }
                        </NoticeBox>
                    </div>
                )

            case 'combinations':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <NoticeBox title={i18n.t('Category Option Combinations')}>
                            {categoryOptionCombos.length === 0 ?
                                i18n.t('No combinations generated. Select categories first to see the resulting option combinations.') :
                                i18n.t('{{count}} category option combinations will be generated from the selected categories.', { count: categoryOptionCombos.length })
                            }
                        </NoticeBox>

                        {categoryOptionCombos.length > 0 && (
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Generated Category Option Combinations')}
                                </h4>

                                <div style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #e9ecef', borderRadius: '4px' }}>
                                    <DataTable>
                                        <DataTableHead>
                                            <DataTableRow>
                                                <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                                                <DataTableColumnHeader>{i18n.t('Short Name')}</DataTableColumnHeader>
                                                <DataTableColumnHeader>{i18n.t('Options')}</DataTableColumnHeader>
                                            </DataTableRow>
                                        </DataTableHead>
                                        <DataTableBody>
                                            {categoryOptionCombos.slice(0, 50).map(combo => (
                                                <DataTableRow key={combo.id}>
                                                    <DataTableCell>{combo.name}</DataTableCell>
                                                    <DataTableCell>{combo.shortName}</DataTableCell>
                                                    <DataTableCell>
                                                        <div style={{ fontSize: '12px', color: '#6c757d' }}>
                                                            {combo.categoryOptions.length} {i18n.t('options')}
                                                        </div>
                                                    </DataTableCell>
                                                </DataTableRow>
                                            ))}
                                        </DataTableBody>
                                    </DataTable>
                                </div>

                                {categoryOptionCombos.length > 50 && (
                                    <div style={{ fontSize: '14px', color: '#6c757d', textAlign: 'center', padding: '8px' }}>
                                        {i18n.t('Showing first 50 of {{total}} combinations', { total: categoryOptionCombos.length })}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )

            case 'settings':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Data dimension type')}
                            selected={formData.dataDimensionType}
                            onChange={({ selected }) => updateFormData('dataDimensionType', selected)}
                            helpText={i18n.t('Type of data dimension')}
                        >
                            {dataDimensionTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>

                        <CheckboxField
                            label={i18n.t('Skip total')}
                            name="skipTotal"
                            checked={formData.skipTotal}
                            onChange={({ checked }) => updateFormData('skipTotal', checked)}
                            helpText={i18n.t('Skip generation of total values for this category combination')}
                        />

                        <NoticeBox title={i18n.t('Settings Information')}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <div>
                                    <strong>{i18n.t('Data Dimension Type')}:</strong> {' '}
                                    {formData.dataDimensionType === 'DISAGGREGATION' ?
                                        i18n.t('Used for disaggregating data values') :
                                        i18n.t('Used as an attribute for data elements or datasets')
                                    }
                                </div>
                                <div>
                                    <strong>{i18n.t('Skip Total')}:</strong> {' '}
                                    {formData.skipTotal ?
                                        i18n.t('Total values will not be generated') :
                                        i18n.t('Total values will be generated automatically')
                                    }
                                </div>
                            </div>
                        </NoticeBox>
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />

                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this category combination.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {categoryCombo ? i18n.t('Edit Category Combination') : i18n.t('Create New Category Combination')}
            </ModalTitle>

            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{
                        minWidth: '200px',
                        borderRight: '1px solid #e0e0e0',
                        paddingRight: '16px'
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>

                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{
                            margin: '0 0 24px 0',
                            fontSize: '18px',
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>

                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>

            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {categoryCombo ? i18n.t('Update Category Combination') : i18n.t('Create Category Combination')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default CategoryComboFormModal;
