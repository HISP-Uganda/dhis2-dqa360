import React, { useState } from 'react'
import {
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    Button,
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const AttributeFormModal = ({
    isOpen,
    onClose,
    onSave,
    attribute = null, // For editing existing attribute
    availableOptionSets = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: attribute?.name || '',
        shortName: attribute?.shortName || '',
        code: attribute?.code || '',
        description: attribute?.description || '',

        // Value and Domain
        valueType: attribute?.valueType || 'TEXT',

        // Options
        optionSet: attribute?.optionSet || null,

        // Assignment
        dataElementAttribute: attribute?.dataElementAttribute || false,
        dataSetAttribute: attribute?.dataSetAttribute || false,
        organisationUnitAttribute: attribute?.organisationUnitAttribute || false,
        userAttribute: attribute?.userAttribute || false,
        categoryOptionAttribute: attribute?.categoryOptionAttribute || false,
        categoryAttribute: attribute?.categoryAttribute || false,
        categoryComboAttribute: attribute?.categoryComboAttribute || false,
        categoryOptionComboAttribute: attribute?.categoryOptionComboAttribute || false,
        indicatorAttribute: attribute?.indicatorAttribute || false,
        programAttribute: attribute?.programAttribute || false,
        programStageAttribute: attribute?.programStageAttribute || false,
        trackedEntityTypeAttribute: attribute?.trackedEntityTypeAttribute || false,
        trackedEntityAttributeAttribute: attribute?.trackedEntityAttributeAttribute || false,

        // Constraints
        mandatory: attribute?.mandatory || false,
        unique: attribute?.unique || false,

        // Access and Sharing
        publicAccess: attribute?.publicAccess || 'r-------',

        // External Reference
        url: attribute?.url || ''
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const valueTypes = [
        { value: 'TEXT', label: i18n.t('Text') },
        { value: 'LONG_TEXT', label: i18n.t('Long text') },
        { value: 'LETTER', label: i18n.t('Letter') },
        { value: 'PHONE_NUMBER', label: i18n.t('Phone number') },
        { value: 'EMAIL', label: i18n.t('Email') },
        { value: 'BOOLEAN', label: i18n.t('Yes/No') },
        { value: 'TRUE_ONLY', label: i18n.t('Yes only') },
        { value: 'DATE', label: i18n.t('Date') },
        { value: 'DATETIME', label: i18n.t('Date & time') },
        { value: 'TIME', label: i18n.t('Time') },
        { value: 'NUMBER', label: i18n.t('Number') },
        { value: 'UNIT_INTERVAL', label: i18n.t('Unit interval') },
        { value: 'PERCENTAGE', label: i18n.t('Percentage') },
        { value: 'INTEGER', label: i18n.t('Integer') },
        { value: 'INTEGER_POSITIVE', label: i18n.t('Positive integer') },
        { value: 'INTEGER_NEGATIVE', label: i18n.t('Negative integer') },
        { value: 'INTEGER_ZERO_OR_POSITIVE', label: i18n.t('Zero or positive integer') },
        { value: 'COORDINATE', label: i18n.t('Coordinate') },
        { value: 'URL', label: i18n.t('URL') },
        { value: 'FILE_RESOURCE', label: i18n.t('File') },
        { value: 'IMAGE', label: i18n.t('Image') }
    ]

    const assignmentOptions = [
        { key: 'dataElementAttribute', label: i18n.t('Data Element') },
        { key: 'dataSetAttribute', label: i18n.t('Data Set') },
        { key: 'organisationUnitAttribute', label: i18n.t('Organisation Unit') },
        { key: 'userAttribute', label: i18n.t('User') },
        { key: 'categoryOptionAttribute', label: i18n.t('Category Option') },
        { key: 'categoryAttribute', label: i18n.t('Category') },
        { key: 'categoryComboAttribute', label: i18n.t('Category Combination') },
        { key: 'categoryOptionComboAttribute', label: i18n.t('Category Option Combination') },
        { key: 'indicatorAttribute', label: i18n.t('Indicator') },
        { key: 'programAttribute', label: i18n.t('Program') },
        { key: 'programStageAttribute', label: i18n.t('Program Stage') },
        { key: 'trackedEntityTypeAttribute', label: i18n.t('Tracked Entity Type') },
        { key: 'trackedEntityAttributeAttribute', label: i18n.t('Tracked Entity Attribute') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'value', label: i18n.t('Value Type') },
        { id: 'assignment', label: i18n.t('Assignment') },
        { id: 'constraints', label: i18n.t('Constraints') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}

        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }

        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }

        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }

        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }

        if (!formData.valueType) {
            newErrors.valueType = i18n.t('Value type is required')
        }

        // Check if at least one assignment is selected
        const hasAssignment = assignmentOptions.some(option => formData[option.key])
        if (!hasAssignment) {
            newErrors.assignment = i18n.t('At least one assignment type must be selected')
        }

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: attribute?.id || `attr_${Date.now()}`,
                created: attribute?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />

                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />

                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />

                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the attribute')}
                        />

                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                    </div>
                )

            case 'value':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Value type')}
                            selected={formData.valueType}
                            onChange={({ selected }) => updateFormData('valueType', selected)}
                            error={!!errors.valueType}
                            validationText={errors.valueType}
                            helpText={i18n.t('The type of data this attribute will store')}
                            required
                        >
                            {valueTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>

                        <SingleSelectField
                            label={i18n.t('Option set')}
                            selected={formData.optionSet || ''}
                            onChange={({ selected }) => updateFormData('optionSet', selected || null)}
                            helpText={i18n.t('Predefined set of options for this attribute')}
                            clearable
                        >
                            {availableOptionSets.map(optionSet => (
                                <SingleSelectOption
                                    key={optionSet.id}
                                    value={optionSet.id}
                                    label={optionSet.name}
                                />
                            ))}
                        </SingleSelectField>

                        <NoticeBox title={i18n.t('Value Type Information')}>
                            {formData.valueType === 'INTEGER' && i18n.t('Integer values only (whole numbers)')}
                            {formData.valueType === 'NUMBER' && i18n.t('Decimal numbers allowed')}
                            {formData.valueType === 'TEXT' && i18n.t('Text values up to 50,000 characters')}
                            {formData.valueType === 'BOOLEAN' && i18n.t('Yes/No values')}
                            {formData.valueType === 'DATE' && i18n.t('Date values in YYYY-MM-DD format')}
                            {formData.valueType === 'EMAIL' && i18n.t('Valid email addresses only')}
                            {formData.valueType === 'PHONE_NUMBER' && i18n.t('Phone number format validation')}
                            {formData.valueType === 'URL' && i18n.t('Valid URL format required')}
                        </NoticeBox>
                    </div>
                )

            case 'assignment':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <div>
                            <h4 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600' }}>
                                {i18n.t('Assign to metadata types')}
                            </h4>
                            <div style={{ fontSize: '14px', color: '#6c757d', marginBottom: '16px' }}>
                                {i18n.t('Select which metadata types this attribute can be assigned to')}
                            </div>
                        </div>

                        {errors.assignment && (
                            <div style={{
                                padding: '12px',
                                backgroundColor: '#f8d7da',
                                borderRadius: '4px',
                                border: '1px solid #f5c6cb',
                                color: '#721c24',
                                fontSize: '14px'
                            }}>
                                {errors.assignment}
                            </div>
                        )}

                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                            {assignmentOptions.map(option => (
                                <CheckboxField
                                    key={option.key}
                                    label={option.label}
                                    name={option.key}
                                    checked={formData[option.key]}
                                    onChange={({ checked }) => {
                                        updateFormData(option.key, checked)
                                        // Clear assignment error when user selects something
                                        if (checked && errors.assignment) {
                                            setErrors(prev => ({ ...prev, assignment: null }))
                                        }
                                    }}
                                />
                            ))}
                        </div>

                        <NoticeBox title={i18n.t('Assignment Information')}>
                            {i18n.t('This attribute will be available for assignment to the selected metadata types. Users can then add custom values for this attribute to instances of those metadata types.')}
                        </NoticeBox>
                    </div>
                )

            case 'constraints':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <CheckboxField
                            label={i18n.t('Mandatory')}
                            name="mandatory"
                            checked={formData.mandatory}
                            onChange={({ checked }) => updateFormData('mandatory', checked)}
                            helpText={i18n.t('This attribute must have a value when assigned to metadata')}
                        />

                        <CheckboxField
                            label={i18n.t('Unique')}
                            name="unique"
                            checked={formData.unique}
                            onChange={({ checked }) => updateFormData('unique', checked)}
                            helpText={i18n.t('Values for this attribute must be unique across all instances')}
                        />

                        <NoticeBox title={i18n.t('Constraint Information')}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                <div>
                                    <strong>{i18n.t('Mandatory')}:</strong> {' '}
                                    {formData.mandatory ?
                                        i18n.t('Users must provide a value for this attribute') :
                                        i18n.t('This attribute is optional')
                                    }
                                </div>
                                <div>
                                    <strong>{i18n.t('Unique')}:</strong> {' '}
                                    {formData.unique ?
                                        i18n.t('Each value must be unique across the system') :
                                        i18n.t('Duplicate values are allowed')
                                    }
                                </div>
                            </div>
                        </NoticeBox>
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />

                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this attribute.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {attribute ? i18n.t('Edit Attribute') : i18n.t('Create New Attribute')}
            </ModalTitle>

            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{
                        minWidth: '200px',
                        borderRight: '1px solid #e0e0e0',
                        paddingRight: '16px'
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>

                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{
                            margin: '0 0 24px 0',
                            fontSize: '18px',
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>

                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>

            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {attribute ? i18n.t('Update Attribute') : i18n.t('Create Attribute')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default AttributeFormModal;