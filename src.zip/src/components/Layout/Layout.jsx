import React from 'react'
import { Box } from '@dhis2/ui'
import { TopNavigation } from './TopNavigation'
import { Header } from './Header'
import styled from 'styled-components'

const LayoutContainer = styled.div`
    display: flex;
    flex-direction: column;
    height: 100vh;
    background-color: #f8f9fa;
    position: relative;
`

const DHIS2HeaderContainer = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1200;
    height: 48px;
    
    @media (max-width: 768px) {
        height: 44px;
    }
`

const MainContent = styled.div`
    flex: 1;
    overflow-y: auto;
    padding-top: 67px; /* Reduced padding to bring content closer to topbar */
    padding-bottom: 30px; /* Add bottom margin */
    padding-left: 20px; /* Add left padding for content spacing */
    padding-right: 20px; /* Add right padding for content spacing */
    width: 100%;
    height: 100vh;
    position: relative;
    
    @media (max-width: 768px) {
        padding-top: 67px; /* Same padding for mobile */
        padding-left: 20px; /* Maintain padding on mobile */
        padding-right: 20px; /* Maintain padding on mobile */
    }
`

export const Layout = ({ children }) => {
    return (
        <LayoutContainer>
            <DHIS2HeaderContainer>
                <Header />
            </DHIS2HeaderContainer>
            <TopNavigation />
            <MainContent>
                {children}
            </MainContent>
        </LayoutContainer>
    )
}