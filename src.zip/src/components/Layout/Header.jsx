import React from 'react'
import { useDataQuery } from '@dhis2/app-runtime'
import { HeaderBar, IconApps24 } from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const query = {
    me: {
        resource: 'me',
        params: {
            fields: 'displayName,email,authorities'
        }
    }
}

export const Header = () => {
    const { data, loading, error } = useDataQuery(query)

    if (loading) return null
    if (error) return null

    return (
        <HeaderBar
            appName={i18n.t('DQA360')}
            profile={{
                name: data?.me?.displayName || '',
                email: data?.me?.email || '',
                avatar: <IconApps24 />
            }}
        />
    )
}