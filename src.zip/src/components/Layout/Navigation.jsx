import React from 'react'
import { Menu, MenuItem } from '@dhis2/ui'
import { useNavigate, useLocation } from 'react-router-dom'
import i18n from '@dhis2/d2-i18n'

export const Navigation = () => {
    const navigate = useNavigate()
    const location = useLocation()

    const menuItems = [
        { path: '/', label: i18n.t('Dashboard'), key: 'dashboard' },
        { path: '/assessments', label: i18n.t('Assessments'), key: 'assessments' },
        { path: '/metadata', label: i18n.t('Metadata'), key: 'metadata' },
        { path: '/data-entry', label: i18n.t('Data Entry'), key: 'data-entry' },
        { path: '/discrepancies', label: i18n.t('Discrepancies'), key: 'discrepancies' },
        { path: '/corrections', label: i18n.t('Corrections'), key: 'corrections' },
        { path: '/reports', label: i18n.t('Reports'), key: 'reports' },
        { path: '/notifications', label: i18n.t('Notifications'), key: 'notifications' },
        { path: '/admin', label: i18n.t('Administration'), key: 'admin' }
    ]

    return (
        <Menu>
            {menuItems.map(item => (
                <MenuItem
                    key={item.key}
                    label={item.label}
                    active={location.pathname === item.path}
                    onClick={() => navigate(item.path)}
                />
            ))}
        </Menu>
    )
}