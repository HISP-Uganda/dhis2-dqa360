import React, { useState } from 'react'
import {
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    Button,
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const CategoryFormModal = ({
    isOpen,
    onClose,
    onSave,
    category = null, // For editing existing category
    availableCategoryOptions = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: category?.name || '',
        shortName: category?.shortName || '',
        code: category?.code || '',
        description: category?.description || '',

        // Category Options
        categoryOptions: category?.categoryOptions || [],

        // Data Dimension
        dataDimension: category?.dataDimension !== undefined ? category.dataDimension : true,
        dataDimensionType: category?.dataDimensionType || 'DISAGGREGATION',

        // Access and Sharing
        publicAccess: category?.publicAccess || 'r-------',

        // External Reference
        url: category?.url || ''
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const dataDimensionTypes = [
        { value: 'DISAGGREGATION', label: i18n.t('Disaggregation') },
        { value: 'ATTRIBUTE', label: i18n.t('Attribute') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'options', label: i18n.t('Category Options') },
        { id: 'dimension', label: i18n.t('Data Dimension') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}

        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }

        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }

        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }

        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }

        if (formData.categoryOptions.length === 0) {
            newErrors.categoryOptions = i18n.t('At least one category option is required')
        }

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: category?.id || `cat_${Date.now()}`,
                created: category?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the category')}
                        />
                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                    </div>
                )
            case 'options':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Category options')}
                            selected={formData.categoryOptions}
                            onChange={({ selected }) => updateFormData('categoryOptions', selected)}
                            error={!!errors.categoryOptions}
                            validationText={errors.categoryOptions}
                            helpText={i18n.t('Select category options to include in this category')}
                        >
                            {availableCategoryOptions.map(option => (
                                <MultiSelectOption
                                    key={option.id}
                                    value={option.id}
                                    label={`${option.name} (${option.shortName})`}
                                />
                            ))}
                        </MultiSelectField>
                        {formData.categoryOptions.length > 0 && (
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Category Options')} ({formData.categoryOptions.length})
                                </h4>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    {formData.categoryOptions.map(optionId => {
                                        const option = availableCategoryOptions.find(opt => opt.id === optionId)
                                        return option ? (
                                            <div key={optionId} style={{
                                                padding: '8px 12px',
                                                backgroundColor: '#f8f9fa',
                                                borderRadius: '4px',
                                                border: '1px solid #e9ecef',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div>
                                                    <div style={{ fontWeight: '500' }}>{option.name}</div>
                                                    <div style={{ fontSize: '12px', color: '#6c757d' }}>{option.shortName}</div>
                                                </div>
                                                <Button
                                                    small
                                                    secondary
                                                    onClick={() => {
                                                        updateFormData('categoryOptions',
                                                            formData.categoryOptions.filter(id => id !== optionId)
                                                        )
                                                    }}
                                                >
                                                    {i18n.t('Remove')}
                                                </Button>
                                            </div>
                                        ) : null
                                    })}
                                </div>
                            </div>
                        )}
                        <NoticeBox title={i18n.t('Category Options')}>
                            {formData.categoryOptions.length === 0 &&
                                i18n.t('No category options selected. A category must have at least one option.')
                            }
                            {formData.categoryOptions.length === 1 &&
                                i18n.t('This category has 1 option. Consider adding more options for meaningful disaggregation.')}
                            {formData.categoryOptions.length > 1 &&
                                i18n.t('This category has {{count}} options for data disaggregation.', { count: formData.categoryOptions.length })}
                        </NoticeBox>
                    </div>
                )
            case 'dimension':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <CheckboxField
                            label={i18n.t('Data dimension')}
                            name="dataDimension"
                            checked={formData.dataDimension}
                            onChange={({ checked }) => updateFormData('dataDimension', checked)}
                            helpText={i18n.t('Whether this category should be available as a data dimension in analytics')}
                        />
                        {formData.dataDimension && (
                            <SingleSelectField
                                label={i18n.t('Data dimension type')}
                                selected={formData.dataDimensionType}
                                onChange={({ selected }) => updateFormData('dataDimensionType', selected)}
                                helpText={i18n.t('Type of data dimension')}
                            >
                                {dataDimensionTypes.map(type => (
                                    <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                                ))}
                            </SingleSelectField>
                        )}
                        <NoticeBox title={i18n.t('Data Dimension Information')}>
                            {formData.dataDimension ? (
                                <div>
                                    <div style={{ marginBottom: '8px' }}>
                                        ✅ {i18n.t('This category will be available in analytics as a data dimension')}
                                    </div>
                                    <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                        {formData.dataDimensionType === 'DISAGGREGATION' &&
                                            i18n.t('Used for disaggregating data values (e.g., by age, sex, location)')
                                        }
                                        {formData.dataDimensionType === 'ATTRIBUTE' &&
                                            i18n.t('Used as an attribute for data elements or datasets')
                                        }
                                    </div>
                                </div>
                            ) : (
                                <div>
                                    ❌ {i18n.t('This category will not be available in analytics')}
                                </div>
                            )}
                        </NoticeBox>
                    </div>
                )
            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this category.')}
                        </NoticeBox>
                    </div>
                )
            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {category ? i18n.t('Edit Category') : i18n.t('Create New Category')}
            </ModalTitle>
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{
                        minWidth: '200px',
                        borderRight: '1px solid #e0e0e0',
                        paddingRight: '16px'
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{
                            margin: '0 0 24px 0',
                            fontSize: '18px',
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {category ? i18n.t('Update Category') : i18n.t('Create Category')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default CategoryFormModal