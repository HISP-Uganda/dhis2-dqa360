import React, { useState } from 'react'
import { 
    Modal, 
    ModalTitle, 
    ModalContent, 
    ModalActions, 
    Button, 
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    CheckboxField,
    Field,
    Box,
    Divider,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const DataElementFormModal = ({ 
    isOpen, 
    onClose, 
    onSave, 
    dataElement = null, // For editing existing data element
    availableDataElementGroups = [],
    availableOptionSets = [],
    availableCategoryCombos = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: dataElement?.name || '',
        shortName: dataElement?.shortName || '',
        code: dataElement?.code || '',
        description: dataElement?.description || '',
        formName: dataElement?.formName || '',
        
        // Value and Domain
        valueType: dataElement?.valueType || 'INTEGER',
        domainType: dataElement?.domainType || 'AGGREGATE',
        aggregationType: dataElement?.aggregationType || 'SUM',
        
        // Categories and Options
        categoryCombo: dataElement?.categoryCombo || 'default',
        optionSet: dataElement?.optionSet || null,
        commentOptionSet: dataElement?.commentOptionSet || null,
        
        // Groups and Sets
        dataElementGroups: dataElement?.dataElementGroups || [],
        
        // Validation and Constraints
        zeroIsSignificant: dataElement?.zeroIsSignificant || false,
        
        // URL and External Reference
        url: dataElement?.url || '',
        
        // Legends and Styling
        legendSets: dataElement?.legendSets || [],
        
        // Access and Sharing
        publicAccess: dataElement?.publicAccess || 'r-------',
        
        // Audit and Tracking
        fieldMask: dataElement?.fieldMask || null
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const valueTypes = [
        { value: 'TEXT', label: i18n.t('Text') },
        { value: 'LONG_TEXT', label: i18n.t('Long text') },
        { value: 'LETTER', label: i18n.t('Letter') },
        { value: 'PHONE_NUMBER', label: i18n.t('Phone number') },
        { value: 'EMAIL', label: i18n.t('Email') },
        { value: 'BOOLEAN', label: i18n.t('Yes/No') },
        { value: 'TRUE_ONLY', label: i18n.t('Yes only') },
        { value: 'DATE', label: i18n.t('Date') },
        { value: 'DATETIME', label: i18n.t('Date & time') },
        { value: 'TIME', label: i18n.t('Time') },
        { value: 'NUMBER', label: i18n.t('Number') },
        { value: 'UNIT_INTERVAL', label: i18n.t('Unit interval') },
        { value: 'PERCENTAGE', label: i18n.t('Percentage') },
        { value: 'INTEGER', label: i18n.t('Integer') },
        { value: 'INTEGER_POSITIVE', label: i18n.t('Positive integer') },
        { value: 'INTEGER_NEGATIVE', label: i18n.t('Negative integer') },
        { value: 'INTEGER_ZERO_OR_POSITIVE', label: i18n.t('Zero or positive integer') },
        { value: 'COORDINATE', label: i18n.t('Coordinate') },
        { value: 'URL', label: i18n.t('URL') },
        { value: 'FILE_RESOURCE', label: i18n.t('File') },
        { value: 'IMAGE', label: i18n.t('Image') }
    ]

    const domainTypes = [
        { value: 'AGGREGATE', label: i18n.t('Aggregate') },
        { value: 'TRACKER', label: i18n.t('Tracker') }
    ]

    const aggregationTypes = [
        { value: 'SUM', label: i18n.t('Sum') },
        { value: 'AVERAGE', label: i18n.t('Average') },
        { value: 'AVERAGE_SUM_ORG_UNIT', label: i18n.t('Average (sum in org unit hierarchy)') },
        { value: 'COUNT', label: i18n.t('Count') },
        { value: 'STDDEV', label: i18n.t('Standard deviation') },
        { value: 'VARIANCE', label: i18n.t('Variance') },
        { value: 'MIN', label: i18n.t('Min') },
        { value: 'MAX', label: i18n.t('Max') },
        { value: 'NONE', label: i18n.t('None') },
        { value: 'CUSTOM', label: i18n.t('Custom') },
        { value: 'DEFAULT', label: i18n.t('Default') }
    ]

    const categoryCombos = [
        { value: 'default', label: i18n.t('Default') },
        { value: 'age_sex', label: i18n.t('Age and Sex') },
        { value: 'dqa_sources', label: i18n.t('DQA Data Sources (Register, Summary, Reported, Corrected)') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'domain', label: i18n.t('Value & Domain') },
        { id: 'categories', label: i18n.t('Categories & Options') },
        { id: 'groups', label: i18n.t('Groups & Sets') },
        { id: 'validation', label: i18n.t('Validation') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}
        
        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }
        
        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }
        
        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }
        
        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }
        
        if (!formData.valueType) {
            newErrors.valueType = i18n.t('Value type is required')
        }
        
        if (!formData.domainType) {
            newErrors.domainType = i18n.t('Domain type is required')
        }
        
        if (!formData.aggregationType) {
            newErrors.aggregationType = i18n.t('Aggregation type is required')
        }
        
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: dataElement?.id || `de_${Date.now()}`,
                created: dataElement?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        // Clear error when user starts typing
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        
                        <InputField
                            label={i18n.t('Form name')}
                            name="formName"
                            value={formData.formName}
                            onChange={({ value }) => updateFormData('formName', value)}
                            helpText={i18n.t('Name to display in data entry forms')}
                        />
                        
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the data element')}
                        />
                        
                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                    </div>
                )

            case 'domain':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Domain type')}
                            selected={formData.domainType}
                            onChange={({ selected }) => updateFormData('domainType', selected)}
                            error={!!errors.domainType}
                            validationText={errors.domainType}
                            helpText={i18n.t('Whether this data element is for aggregate or tracker data')}
                            required
                        >
                            {domainTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Value type')}
                            selected={formData.valueType}
                            onChange={({ selected }) => updateFormData('valueType', selected)}
                            error={!!errors.valueType}
                            validationText={errors.valueType}
                            helpText={i18n.t('The type of data this element will store')}
                            required
                        >
                            {valueTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Aggregation type')}
                            selected={formData.aggregationType}
                            onChange={({ selected }) => updateFormData('aggregationType', selected)}
                            error={!!errors.aggregationType}
                            validationText={errors.aggregationType}
                            helpText={i18n.t('How values should be aggregated in analytics')}
                            required
                        >
                            {aggregationTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                        
                        <NoticeBox title={i18n.t('Value Type Information')}>
                            {formData.valueType === 'INTEGER' && i18n.t('Integer values only (whole numbers)')}
                            {formData.valueType === 'NUMBER' && i18n.t('Decimal numbers allowed')}
                            {formData.valueType === 'TEXT' && i18n.t('Text values up to 50,000 characters')}
                            {formData.valueType === 'BOOLEAN' && i18n.t('Yes/No values')}
                            {formData.valueType === 'DATE' && i18n.t('Date values in YYYY-MM-DD format')}
                        </NoticeBox>
                    </div>
                )

            case 'categories':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <SingleSelectField
                            label={i18n.t('Category combination')}
                            selected={formData.categoryCombo}
                            onChange={({ selected }) => updateFormData('categoryCombo', selected)}
                            helpText={i18n.t('Category combination for data disaggregation')}
                        >
                            {categoryCombos.map(combo => (
                                <SingleSelectOption key={combo.value} value={combo.value} label={combo.label} />
                            ))}
                        </SingleSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Option set')}
                            selected={formData.optionSet || ''}
                            onChange={({ selected }) => updateFormData('optionSet', selected || null)}
                            helpText={i18n.t('Predefined set of options for this data element')}
                            clearable
                        >
                            {availableOptionSets.map(optionSet => (
                                <SingleSelectOption 
                                    key={optionSet.id} 
                                    value={optionSet.id} 
                                    label={optionSet.name} 
                                />
                            ))}
                        </SingleSelectField>
                        
                        <SingleSelectField
                            label={i18n.t('Comment option set')}
                            selected={formData.commentOptionSet || ''}
                            onChange={({ selected }) => updateFormData('commentOptionSet', selected || null)}
                            helpText={i18n.t('Predefined comments for this data element')}
                            clearable
                        >
                            {availableOptionSets.map(optionSet => (
                                <SingleSelectOption 
                                    key={optionSet.id} 
                                    value={optionSet.id} 
                                    label={optionSet.name} 
                                />
                            ))}
                        </SingleSelectField>
                        
                        <NoticeBox title={i18n.t('Category Information')}>
                            {formData.categoryCombo === 'default' && i18n.t('No disaggregation - single value per period and org unit')}
                            {formData.categoryCombo === 'age_sex' && i18n.t('Disaggregated by age groups and sex')}
                            {formData.categoryCombo === 'dqa_sources' && i18n.t('Disaggregated by data sources: Register, Summary, Reported, Corrected')}
                        </NoticeBox>
                    </div>
                )

            case 'groups':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <MultiSelectField
                            label={i18n.t('Data element groups')}
                            selected={formData.dataElementGroups}
                            onChange={({ selected }) => updateFormData('dataElementGroups', selected)}
                            helpText={i18n.t('Groups to organize and categorize data elements')}
                        >
                            {availableDataElementGroups.map(group => (
                                <MultiSelectOption 
                                    key={group.id} 
                                    value={group.id} 
                                    label={group.name} 
                                />
                            ))}
                        </MultiSelectField>
                        
                        {formData.dataElementGroups.length > 0 && (
                            <NoticeBox title={i18n.t('Selected Groups')}>
                                {i18n.t('{{count}} groups selected', { count: formData.dataElementGroups.length })}
                            </NoticeBox>
                        )}
                        
                        <NoticeBox title={i18n.t('Data Element Groups')}>
                            {i18n.t('Groups help organize data elements by theme, program, or other criteria. They are used in analytics and reporting.')}
                        </NoticeBox>
                    </div>
                )

            case 'validation':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <CheckboxField
                            label={i18n.t('Zero is significant')}
                            name="zeroIsSignificant"
                            checked={formData.zeroIsSignificant}
                            onChange={({ checked }) => updateFormData('zeroIsSignificant', checked)}
                            helpText={i18n.t('Whether zero should be stored as a data value')}
                        />
                        
                        <InputField
                            label={i18n.t('Field mask')}
                            name="fieldMask"
                            value={formData.fieldMask || ''}
                            onChange={({ value }) => updateFormData('fieldMask', value || null)}
                            helpText={i18n.t('Input mask for data entry (e.g., "####-##-##" for dates)')}
                        />
                        
                        <NoticeBox title={i18n.t('Validation Rules')}>
                            {i18n.t('Additional validation rules can be configured separately to ensure data quality and consistency.')}
                        </NoticeBox>
                    </div>
                )

            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this data element.')}
                        </NoticeBox>
                    </div>
                )

            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {dataElement ? i18n.t('Edit Data Element') : i18n.t('Create New Data Element')}
            </ModalTitle>
            
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{ 
                        minWidth: '200px', 
                        borderRight: '1px solid #e0e0e0', 
                        paddingRight: '16px' 
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{ 
                            margin: '0 0 24px 0', 
                            fontSize: '18px', 
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {dataElement ? i18n.t('Update Data Element') : i18n.t('Create Data Element')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default DataElementFormModal