import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Layout } from '../Layout/Layout'
import { Dashboard } from '../../pages/Dashboard/Dashboard'
import { Assessments } from '../../pages/Assessments/Assessments'
import { DataEntry } from '../../pages/DataEntry/DataEntry'
import { Discrepancies } from '../../pages/Discrepancies/Discrepancies'
import { Corrections } from '../../pages/Corrections/Corrections'
import { Reports } from '../../pages/Reports/Reports'
import { Notifications } from '../../pages/Notifications/Notifications'
import { Administration } from '../../pages/Administration/Administration'
import { Metadata } from '../../pages/Metadata/Metadata'
import { ManageAssessments } from '../../pages/ManageAssessments/ManageAssessments'
import { CreateAssessmentPage } from '../../pages/ManageAssessments/CreateAssessmentPage'
import { TestMultiSelect } from '../../pages/TestMultiSelect'
import DataStoreTest from '../DataStoreTest'
// import DataStoreTest from '../DataStoreTest'

export const AppRouter = () => {
    return (
        <Router>
            <Layout>
                <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/assessments" element={<ManageAssessments />} />
                    <Route path="/manage-assessments" element={<ManageAssessments />} />
                    <Route path="/manage-assessments/create" element={<CreateAssessmentPage />} />
                    <Route path="/test-multiselect" element={<TestMultiSelect />} />
                    <Route path="/test-datastore" element={<DataStoreTest />} />
                    <Route path="/test-datastore" element={<DataStoreTest />} />
                    <Route path="/data-entry" element={<DataEntry />} />
                    <Route path="/discrepancies" element={<Discrepancies />} />
                    <Route path="/corrections" element={<Corrections />} />
                    <Route path="/reports" element={<Reports />} />
                    <Route path="/notifications" element={<Notifications />} />
                    <Route path="/admin" element={<Administration />} />
                    {/* Legacy routes for backward compatibility */}
                    <Route path="/metadata" element={<ManageAssessments />} />
                </Routes>
            </Layout>
        </Router>
    )
}