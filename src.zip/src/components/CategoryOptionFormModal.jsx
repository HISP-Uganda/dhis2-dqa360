import React, { useState } from 'react'
import {
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    Button,
    ButtonStrip,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    CheckboxField,
    NoticeBox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

const CategoryOptionFormModal = ({
    isOpen,
    onClose,
    onSave,
    categoryOption = null, // For editing existing category option
    availableCategoryOptionGroups = []
}) => {
    const [formData, setFormData] = useState({
        // Basic Information
        name: categoryOption?.name || '',
        shortName: categoryOption?.shortName || '',
        code: categoryOption?.code || '',
        description: categoryOption?.description || '',

        // Dates
        startDate: categoryOption?.startDate || '',
        endDate: categoryOption?.endDate || '',

        // Groups
        categoryOptionGroups: categoryOption?.categoryOptionGroups || [],

        // Organization Units
        organisationUnits: categoryOption?.organisationUnits || [],

        // Access and Sharing
        publicAccess: categoryOption?.publicAccess || 'r-------',

        // Style and Display
        style: categoryOption?.style || {
            color: '#000000',
            icon: null
        },

        // External Reference
        url: categoryOption?.url || '',

        // Dimension Item Type
        dimensionItemType: categoryOption?.dimensionItemType || 'DATA_ELEMENT'
    })

    const [activeTab, setActiveTab] = useState('basic')
    const [errors, setErrors] = useState({})

    const dimensionItemTypes = [
        { value: 'DATA_ELEMENT', label: i18n.t('Data Element') },
        { value: 'DATA_ELEMENT_OPERAND', label: i18n.t('Data Element Operand') },
        { value: 'INDICATOR', label: i18n.t('Indicator') },
        { value: 'REPORTING_RATE', label: i18n.t('Reporting Rate') },
        { value: 'PROGRAM_DATA_ELEMENT', label: i18n.t('Program Data Element') },
        { value: 'PROGRAM_ATTRIBUTE', label: i18n.t('Program Attribute') },
        { value: 'PROGRAM_INDICATOR', label: i18n.t('Program Indicator') }
    ]

    const tabs = [
        { id: 'basic', label: i18n.t('Basic Information') },
        { id: 'dates', label: i18n.t('Dates') },
        { id: 'groups', label: i18n.t('Groups') },
        { id: 'style', label: i18n.t('Style & Display') },
        { id: 'access', label: i18n.t('Access & Sharing') }
    ]

    const validateForm = () => {
        const newErrors = {}
        if (!formData.name.trim()) {
            newErrors.name = i18n.t('Name is required')
        }
        if (!formData.shortName.trim()) {
            newErrors.shortName = i18n.t('Short name is required')
        }
        if (formData.shortName.length > 50) {
            newErrors.shortName = i18n.t('Short name must be 50 characters or less')
        }
        if (formData.code && formData.code.length > 50) {
            newErrors.code = i18n.t('Code must be 50 characters or less')
        }
        if (formData.startDate && formData.endDate &&
            new Date(formData.startDate) > new Date(formData.endDate)) {
            newErrors.endDate = i18n.t('End date must be after start date')
        }
        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSave = () => {
        if (validateForm()) {
            onSave({
                ...formData,
                id: categoryOption?.id || `co_${Date.now()}`,
                created: categoryOption?.created || new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            })
            onClose()
        }
    }

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: null }))
        }
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'basic':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Name')}
                            name="name"
                            value={formData.name}
                            onChange={({ value }) => updateFormData('name', value)}
                            error={!!errors.name}
                            validationText={errors.name}
                            required
                        />
                        <InputField
                            label={i18n.t('Short name')}
                            name="shortName"
                            value={formData.shortName}
                            onChange={({ value }) => updateFormData('shortName', value)}
                            error={!!errors.shortName}
                            validationText={errors.shortName}
                            helpText={i18n.t('Maximum 50 characters')}
                            required
                        />
                        <InputField
                            label={i18n.t('Code')}
                            name="code"
                            value={formData.code}
                            onChange={({ value }) => updateFormData('code', value)}
                            error={!!errors.code}
                            validationText={errors.code}
                            helpText={i18n.t('Optional unique identifier')}
                        />
                        <TextAreaField
                            label={i18n.t('Description')}
                            name="description"
                            value={formData.description}
                            onChange={({ value }) => updateFormData('description', value)}
                            rows={4}
                            helpText={i18n.t('Detailed description of the category option')}
                        />
                        <InputField
                            label={i18n.t('URL')}
                            name="url"
                            value={formData.url}
                            onChange={({ value }) => updateFormData('url', value)}
                            helpText={i18n.t('Link to additional information')}
                        />
                        <SingleSelectField
                            label={i18n.t('Dimension item type')}
                            selected={formData.dimensionItemType}
                            onChange={({ selected }) => updateFormData('dimensionItemType', selected)}
                            helpText={i18n.t('Type of dimension item this category option represents')}
                        >
                            {dimensionItemTypes.map(type => (
                                <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                            ))}
                        </SingleSelectField>
                    </div>
                )
            case 'dates':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Start date')}
                            name="startDate"
                            type="date"
                            value={formData.startDate}
                            onChange={({ value }) => updateFormData('startDate', value)}
                            helpText={i18n.t('Date when this category option becomes valid')}
                        />
                        <InputField
                            label={i18n.t('End date')}
                            name="endDate"
                            type="date"
                            value={formData.endDate}
                            onChange={({ value }) => updateFormData('endDate', value)}
                            error={!!errors.endDate}
                            validationText={errors.endDate}
                            helpText={i18n.t('Date when this category option expires (optional)')}
                        />
                        <NoticeBox title={i18n.t('Date Information')}>
                            {formData.startDate && !formData.endDate &&
                                i18n.t('This category option is valid from {{date}} onwards', { date: formData.startDate })
                            }
                            {formData.startDate && formData.endDate &&
                                i18n.t('This category option is valid from {{start}} to {{end}}', {
                                    start: formData.startDate,
                                    end: formData.endDate
                                })
                            }
                            {!formData.startDate && !formData.endDate &&
                                i18n.t('This category option has no date restrictions')
                            }
                        </NoticeBox>
                    </div>
                )
            case 'groups':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <NoticeBox title={i18n.t('Category Option Groups')}>
                            {i18n.t('Groups help organize category options by theme or purpose. They are used for analytics and reporting.')}
                        </NoticeBox>
                        {availableCategoryOptionGroups.length > 0 ? (
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Available Groups')}
                                </h4>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    {availableCategoryOptionGroups.map(group => (
                                        <CheckboxField
                                            key={group.id}
                                            label={group.name}
                                            name={`group_${group.id}`}
                                            checked={formData.categoryOptionGroups.includes(group.id)}
                                            onChange={({ checked }) => {
                                                if (checked) {
                                                    updateFormData('categoryOptionGroups', [...formData.categoryOptionGroups, group.id])
                                                } else {
                                                    updateFormData('categoryOptionGroups', formData.categoryOptionGroups.filter(id => id !== group.id))
                                                }
                                            }}
                                        />
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <NoticeBox>
                                {i18n.t('No category option groups available. Create groups first to organize your category options.')}
                            </NoticeBox>
                        )}
                        {formData.categoryOptionGroups.length > 0 && (
                            <NoticeBox title={i18n.t('Selected Groups')}>
                                {i18n.t('{{count}} groups selected', { count: formData.categoryOptionGroups.length })}
                            </NoticeBox>
                        )}
                    </div>
                )
            case 'style':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Color')}
                            name="color"
                            type="color"
                            value={formData.style.color}
                            onChange={({ value }) => updateFormData('style', { ...formData.style, color: value })}
                            helpText={i18n.t('Color for visual representation in charts and maps')}
                        />
                        <InputField
                            label={i18n.t('Icon')}
                            name="icon"
                            value={formData.style.icon || ''}
                            onChange={({ value }) => updateFormData('style', { ...formData.style, icon: value || null })}
                            helpText={i18n.t('Icon name for visual representation (optional)')}
                        />
                        <NoticeBox title={i18n.t('Style Preview')}>
                            <div style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '12px',
                                padding: '12px',
                                backgroundColor: '#f8f9fa',
                                borderRadius: '4px'
                            }}>
                                <div style={{
                                    width: '20px',
                                    height: '20px',
                                    backgroundColor: formData.style.color,
                                    borderRadius: '3px',
                                    border: '1px solid #ddd'
                                }}></div>
                                <span style={{ fontWeight: '500' }}>{formData.name || i18n.t('Category Option Name')}</span>
                                {formData.style.icon && <span>📊</span>}
                            </div>
                        </NoticeBox>
                    </div>
                )
            case 'access':
                return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <InputField
                            label={i18n.t('Public access')}
                            name="publicAccess"
                            value={formData.publicAccess}
                            onChange={({ value }) => updateFormData('publicAccess', value)}
                            helpText={i18n.t('Public access permissions (e.g., r------- for read-only)')}
                        />
                        <NoticeBox title={i18n.t('Access Control')}>
                            {i18n.t('Configure user groups and sharing settings to control who can view and edit this category option.')}
                        </NoticeBox>
                    </div>
                )
            default:
                return null
        }
    }

    if (!isOpen) return null

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>
                {categoryOption ? i18n.t('Edit Category Option') : i18n.t('Create New Category Option')}
            </ModalTitle>
            <ModalContent>
                <div style={{ display: 'flex', gap: '24px', minHeight: '500px' }}>
                    {/* Tab Navigation */}
                    <div style={{
                        minWidth: '200px',
                        borderRight: '1px solid #e0e0e0',
                        paddingRight: '16px'
                    }}>
                        {tabs.map(tab => (
                            <div
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                style={{
                                    padding: '12px 16px',
                                    cursor: 'pointer',
                                    borderRadius: '4px',
                                    marginBottom: '4px',
                                    backgroundColor: activeTab === tab.id ? '#e3f2fd' : 'transparent',
                                    color: activeTab === tab.id ? '#1976d2' : '#666',
                                    fontWeight: activeTab === tab.id ? '600' : '400',
                                    fontSize: '14px'
                                }}
                            >
                                {tab.label}
                            </div>
                        ))}
                    </div>
                    {/* Tab Content */}
                    <div style={{ flex: 1, paddingLeft: '16px' }}>
                        <h3 style={{
                            margin: '0 0 24px 0',
                            fontSize: '18px',
                            fontWeight: '600',
                            color: '#333'
                        }}>
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </h3>
                        {renderTabContent()}
                    </div>
                </div>
            </ModalContent>
            <ModalActions>
                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary onClick={handleSave}>
                        {categoryOption ? i18n.t('Update Category Option') : i18n.t('Create Category Option')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default CategoryOptionFormModal