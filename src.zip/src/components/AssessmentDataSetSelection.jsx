import React, { useState, useEffect } from 'react'
import {
    Box,
    Button,
    ButtonStrip,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    CircularLoader,
    NoticeBox,
    Card,
    InputField,
    SingleSelectField,
    SingleSelectOption,
    Tag,
    Checkbox,
    Pagination
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

export const AssessmentDataSetSelection = ({ 
    dhis2Config, 
    onDataSetSelected, 
    selectedDataSet,
    onDataSetsSelected, // New prop for multiple selection
    selectedDataSets = [], // New prop for multiple selection
    onDataElementsSelected,
    selectedDataElements = [],
    mode = 'datasets', // 'datasets' or 'dataelements'
    multiSelect = false // New prop to enable multi-select mode
}) => {
    const [loading, setLoading] = useState(false)
    const [dataSets, setDataSets] = useState([])
    const [dataElements, setDataElements] = useState([])
    const [searchTerm, setSearchTerm] = useState('')
    const [error, setError] = useState(null)
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage] = useState(25)

    // Fetch datasets from DHIS2
    const fetchDataSets = async () => {
        if (!dhis2Config?.configured) return

        setLoading(true)
        setError(null)
        
        try {
            const response = await fetch(`${dhis2Config.baseUrl}/api/dataSets.json?fields=id,displayName,name,periodType,dataSetElements[dataElement[id,displayName,valueType,domainType,categoryCombo[id,displayName,categories[id,displayName]]]]&paging=false`, {
                headers: {
                    'Authorization': `Basic ${btoa(`${dhis2Config.username}:${dhis2Config.password}`)}`,
                    'Content-Type': 'application/json'
                }
            })

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`)
            }

            const data = await response.json()
            setDataSets(data.dataSets || [])
        } catch (err) {
            console.error('Error fetching datasets:', err)
            setError(err.message)
        } finally {
            setLoading(false)
        }
    }

    // Extract data elements from selected dataset(s)
    useEffect(() => {
        if (multiSelect && selectedDataSets.length > 0) {
            // Combine data elements from all selected datasets
            const elementsMap = new Map()
            selectedDataSets.forEach(dataSet => {
                if (dataSet.dataSetElements) {
                    dataSet.dataSetElements.forEach(dse => {
                        const element = dse.dataElement
                        if (!elementsMap.has(element.id)) {
                            elementsMap.set(element.id, {
                                ...element,
                                sourceDataSets: [{ id: dataSet.id, displayName: dataSet.displayName }]
                            })
                        } else {
                            // Add this dataset as another source
                            const existing = elementsMap.get(element.id)
                            existing.sourceDataSets.push({ id: dataSet.id, displayName: dataSet.displayName })
                        }
                    })
                }
            })
            setDataElements(Array.from(elementsMap.values()))
        } else if (!multiSelect && selectedDataSet && selectedDataSet.dataSetElements) {
            const elements = selectedDataSet.dataSetElements.map(dse => ({
                ...dse.dataElement,
                sourceDataSets: [{ id: selectedDataSet.id, displayName: selectedDataSet.displayName }]
            }))
            setDataElements(elements)
        } else {
            setDataElements([])
        }
    }, [selectedDataSet, selectedDataSets, multiSelect])

    // Load datasets when component mounts or config changes
    useEffect(() => {
        fetchDataSets()
    }, [dhis2Config])

    // Filter datasets based on search term
    const filteredDataSets = dataSets.filter(ds => 
        ds.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ds.name.toLowerCase().includes(searchTerm.toLowerCase())
    )

    // Filter data elements based on search term
    const filteredDataElements = dataElements.filter(de => 
        de.displayName.toLowerCase().includes(searchTerm.toLowerCase())
    )

    // Pagination calculations for datasets
    const totalDataSets = filteredDataSets.length
    const totalDataSetPages = Math.ceil(totalDataSets / itemsPerPage)
    const dataSetStartIndex = (currentPage - 1) * itemsPerPage
    const dataSetEndIndex = dataSetStartIndex + itemsPerPage
    const paginatedDataSets = filteredDataSets.slice(dataSetStartIndex, dataSetEndIndex)

    // Pagination calculations for data elements
    const totalDataElements = filteredDataElements.length
    const totalDataElementPages = Math.ceil(totalDataElements / itemsPerPage)
    const dataElementStartIndex = (currentPage - 1) * itemsPerPage
    const dataElementEndIndex = dataElementStartIndex + itemsPerPage
    const paginatedDataElements = filteredDataElements.slice(dataElementStartIndex, dataElementEndIndex)

    // Reset to first page when search term changes
    useEffect(() => {
        setCurrentPage(1)
    }, [searchTerm])

    // Handle dataset selection (single mode)
    const handleDataSetSelect = (dataSet) => {
        onDataSetSelected(dataSet)
    }

    // Handle dataset selection (multi mode)
    const handleDataSetToggle = (dataSet) => {
        if (!multiSelect) {
            handleDataSetSelect(dataSet)
            return
        }

        const isSelected = selectedDataSets.some(ds => ds.id === dataSet.id)
        let newSelection

        if (isSelected) {
            newSelection = selectedDataSets.filter(ds => ds.id !== dataSet.id)
        } else {
            newSelection = [...selectedDataSets, dataSet]
        }

        onDataSetsSelected(newSelection)
    }

    // Select all datasets (multi mode)
    const handleSelectAllDataSets = () => {
        if (!multiSelect) return

        if (selectedDataSets.length === filteredDataSets.length) {
            onDataSetsSelected([])
        } else {
            onDataSetsSelected([...filteredDataSets])
        }
    }

    // Handle data element selection
    const handleDataElementToggle = (dataElement) => {
        const isSelected = selectedDataElements.some(de => de.id === dataElement.id)
        let newSelection
        
        if (isSelected) {
            newSelection = selectedDataElements.filter(de => de.id !== dataElement.id)
        } else {
            newSelection = [...selectedDataElements, dataElement]
        }
        
        onDataElementsSelected(newSelection)
    }

    // Select all data elements
    const handleSelectAll = () => {
        if (selectedDataElements.length === dataElements.length) {
            onDataElementsSelected([])
        } else {
            onDataElementsSelected([...dataElements])
        }
    }

    if (!dhis2Config?.configured) {
        return (
            <NoticeBox warning title={i18n.t('DHIS2 Connection Required')}>
                {i18n.t('Please configure your DHIS2 connection first before selecting datasets.')}
            </NoticeBox>
        )
    }

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" style={{ minHeight: '200px' }}>
                <CircularLoader />
            </Box>
        )
    }

    if (error) {
        return (
            <NoticeBox error title={i18n.t('Error Loading Data')}>
                {error}
                <Box marginTop="16px">
                    <Button onClick={fetchDataSets}>
                        {i18n.t('Retry')}
                    </Button>
                </Box>
            </NoticeBox>
        )
    }

    if (mode === 'datasets') {
        return (
            <Box>
                <Card style={{ padding: '24px', marginBottom: '24px' }}>
                    <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', fontWeight: '600' }}>
                        {i18n.t('Select Dataset')}
                    </h3>
                    <p style={{ margin: '0 0 24px 0', color: '#6c757d' }}>
                        {i18n.t('Choose the dataset that contains the data elements you want to assess for data quality.')}
                    </p>

                    <InputField
                        label={i18n.t('Search Datasets')}
                        value={searchTerm}
                        onChange={({ value }) => setSearchTerm(value)}
                        placeholder={i18n.t('Search by dataset name...')}
                        style={{ marginBottom: '24px' }}
                    />

                    {/* Selection Summary */}
                    {multiSelect ? (
                        selectedDataSets.length > 0 && (
                            <Box style={{ marginBottom: '24px' }}>
                                <Box display="flex" justifyContent="space-between" alignItems="center" style={{ marginBottom: '12px' }}>
                                    <Tag positive>
                                        {selectedDataSets.length} {i18n.t('datasets selected')}
                                    </Tag>
                                    <Button
                                        small
                                        secondary
                                        onClick={handleSelectAllDataSets}
                                    >
                                        {selectedDataSets.length === filteredDataSets.length ? i18n.t('Deselect All') : i18n.t('Select All')}
                                    </Button>
                                </Box>
                                <Box display="flex" flexWrap="wrap" gap="4px">
                                    {selectedDataSets.map(ds => (
                                        <Tag key={ds.id} positive small>
                                            {ds.displayName}
                                        </Tag>
                                    ))}
                                </Box>
                            </Box>
                        )
                    ) : (
                        selectedDataSet && (
                            <Box style={{ marginBottom: '24px' }}>
                                <Tag positive>
                                    {i18n.t('Selected')}: {selectedDataSet.displayName}
                                </Tag>
                            </Box>
                        )
                    )}
                </Card>

                <Card style={{ padding: '24px' }}>
                    <DataTable>
                        <DataTableHead>
                            <DataTableRow>
                                {multiSelect && (
                                    <DataTableColumnHeader width="60px">
                                        <Checkbox
                                            checked={selectedDataSets.length === filteredDataSets.length && filteredDataSets.length > 0}
                                            indeterminate={selectedDataSets.length > 0 && selectedDataSets.length < filteredDataSets.length}
                                            onChange={handleSelectAllDataSets}
                                        />
                                    </DataTableColumnHeader>
                                )}
                                <DataTableColumnHeader>{i18n.t('Dataset Name')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Period Type')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Data Elements')}</DataTableColumnHeader>
                                {!multiSelect && <DataTableColumnHeader>{i18n.t('Action')}</DataTableColumnHeader>}
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableBody>
                            {paginatedDataSets.map(dataSet => {
                                const isSelected = multiSelect 
                                    ? selectedDataSets.some(ds => ds.id === dataSet.id)
                                    : selectedDataSet?.id === dataSet.id
                                
                                return (
                                    <DataTableRow 
                                        key={dataSet.id}
                                        style={{ 
                                            backgroundColor: isSelected ? '#e3f2fd' : 'transparent',
                                            borderLeft: isSelected ? '4px solid #1976d2' : '4px solid transparent'
                                        }}
                                    >
                                        {multiSelect && (
                                            <DataTableCell>
                                                <Checkbox
                                                    checked={isSelected}
                                                    onChange={() => handleDataSetToggle(dataSet)}
                                                />
                                            </DataTableCell>
                                        )}
                                        <DataTableCell>
                                            <Box display="flex" alignItems="center" gap="8px">
                                                <span style={{ fontWeight: isSelected ? '600' : '400' }}>
                                                    {dataSet.displayName}
                                                </span>
                                                {isSelected && (
                                                    <Tag positive small>
                                                        {i18n.t('Selected')}
                                                    </Tag>
                                                )}
                                            </Box>
                                        </DataTableCell>
                                        <DataTableCell>
                                            <Tag neutral>{dataSet.periodType}</Tag>
                                        </DataTableCell>
                                        <DataTableCell>{dataSet.dataSetElements?.length || 0}</DataTableCell>
                                        {!multiSelect && (
                                            <DataTableCell>
                                                <Button
                                                    small
                                                    primary={selectedDataSet?.id === dataSet.id}
                                                    secondary={selectedDataSet?.id !== dataSet.id}
                                                    onClick={() => handleDataSetSelect(dataSet)}
                                                >
                                                    {selectedDataSet?.id === dataSet.id ? i18n.t('Selected') : i18n.t('Select')}
                                                </Button>
                                            </DataTableCell>
                                        )}
                                    </DataTableRow>
                                )
                            })}
                        </DataTableBody>
                    </DataTable>

                    {/* Pagination Controls for Datasets */}
                    {totalDataSetPages > 1 && (
                        <Box padding="16px" display="flex" justifyContent="space-between" alignItems="center" borderTop="1px solid #e8eaed">
                            <Box fontSize="14px" color="#666">
                                {i18n.t('Showing {{start}}-{{end}} of {{total}} datasets', {
                                    start: dataSetStartIndex + 1,
                                    end: Math.min(dataSetEndIndex, totalDataSets),
                                    total: totalDataSets
                                })}
                            </Box>
                            <Pagination
                                page={currentPage}
                                pageCount={totalDataSetPages}
                                pageSize={itemsPerPage}
                                total={totalDataSets}
                                onPageChange={setCurrentPage}
                                hidePageSizeSelect
                            />
                        </Box>
                    )}

                    {filteredDataSets.length === 0 && (
                        <Box textAlign="center" padding="32px">
                            <p style={{ color: '#6c757d' }}>
                                {searchTerm ? i18n.t('No datasets found matching your search.') : i18n.t('No datasets available.')}
                            </p>
                        </Box>
                    )}
                </Card>
            </Box>
        )
    }

    if (mode === 'dataelements') {
        const hasSelectedDatasets = multiSelect ? selectedDataSets.length > 0 : selectedDataSet
        
        if (!hasSelectedDatasets) {
            return (
                <NoticeBox warning title={i18n.t('Dataset Required')}>
                    {multiSelect 
                        ? i18n.t('Please select at least one dataset first before choosing data elements.')
                        : i18n.t('Please select a dataset first before choosing data elements.')
                    }
                </NoticeBox>
            )
        }

        return (
            <Box>
                <Card style={{ padding: '24px', marginBottom: '24px' }}>
                    <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', fontWeight: '600' }}>
                        {i18n.t('Select Data Elements')}
                    </h3>
                    <p style={{ margin: '0 0 16px 0', color: '#6c757d' }}>
                        {multiSelect 
                            ? i18n.t('Choose the specific data elements from the selected datasets that you want to include in your data quality assessment.')
                            : i18n.t('Choose the specific data elements from') + ' ' + selectedDataSet.displayName + ' ' + i18n.t('that you want to include in your data quality assessment.')
                        }
                    </p>

                    {/* Show selected datasets summary */}
                    {multiSelect && selectedDataSets.length > 0 && (
                        <Box style={{ marginBottom: '16px' }}>
                            <div style={{ fontSize: '14px', fontWeight: '500', marginBottom: '8px', color: '#495057' }}>
                                {i18n.t('Selected Datasets')}:
                            </div>
                            <Box display="flex" flexWrap="wrap" gap="4px">
                                {selectedDataSets.map(ds => (
                                    <Tag key={ds.id} neutral small>
                                        {ds.displayName}
                                    </Tag>
                                ))}
                            </Box>
                        </Box>
                    )}

                    <Box display="flex" justifyContent="space-between" alignItems="center" style={{ marginBottom: '24px' }}>
                        <Tag neutral>
                            {selectedDataElements.length} {i18n.t('of')} {dataElements.length} {i18n.t('selected')}
                        </Tag>
                        <Button
                            small
                            secondary
                            onClick={handleSelectAll}
                        >
                            {selectedDataElements.length === dataElements.length ? i18n.t('Deselect All') : i18n.t('Select All')}
                        </Button>
                    </Box>

                    <InputField
                        label={i18n.t('Search Data Elements')}
                        value={searchTerm}
                        onChange={({ value }) => setSearchTerm(value)}
                        placeholder={i18n.t('Search by data element name...')}
                        style={{ marginBottom: '24px' }}
                    />
                </Card>

                <Card style={{ padding: '24px' }}>
                    <DataTable>
                        <DataTableHead>
                            <DataTableRow>
                                <DataTableColumnHeader width="60px">{i18n.t('Select')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Data Element Name')}</DataTableColumnHeader>
                                <DataTableColumnHeader width="120px">{i18n.t('Value Type')}</DataTableColumnHeader>
                                <DataTableColumnHeader width="120px">{i18n.t('Domain Type')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Category Combo')}</DataTableColumnHeader>
                                {multiSelect && <DataTableColumnHeader>{i18n.t('Source Datasets')}</DataTableColumnHeader>}
                                <DataTableColumnHeader width="200px">{i18n.t('ID')}</DataTableColumnHeader>
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableBody>
                            {paginatedDataElements.map(dataElement => (
                                <DataTableRow key={dataElement.id}>
                                    <DataTableCell>
                                        <Checkbox
                                            checked={selectedDataElements.some(de => de.id === dataElement.id)}
                                            onChange={() => handleDataElementToggle(dataElement)}
                                        />
                                    </DataTableCell>
                                    <DataTableCell>
                                        <Box>
                                            <strong style={{ fontSize: '14px', color: '#2c3e50' }}>
                                                {dataElement.displayName}
                                            </strong>
                                        </Box>
                                    </DataTableCell>
                                    <DataTableCell>
                                        <Tag 
                                            neutral={dataElement.valueType !== 'NUMBER'}
                                            positive={dataElement.valueType === 'NUMBER'}
                                            style={{ fontSize: '11px' }}
                                        >
                                            {dataElement.valueType || 'TEXT'}
                                        </Tag>
                                    </DataTableCell>
                                    <DataTableCell>
                                        <Tag 
                                            neutral={dataElement.domainType !== 'AGGREGATE'}
                                            positive={dataElement.domainType === 'AGGREGATE'}
                                            style={{ fontSize: '11px' }}
                                        >
                                            {dataElement.domainType || 'AGGREGATE'}
                                        </Tag>
                                    </DataTableCell>
                                    <DataTableCell>
                                        <Box>
                                            <div style={{ fontSize: '13px', color: '#495057', fontWeight: '500' }}>
                                                {dataElement.categoryCombo?.displayName || 'Default'}
                                            </div>
                                            {dataElement.categoryCombo?.categories && dataElement.categoryCombo.categories.length > 0 && (
                                                <div style={{ fontSize: '11px', color: '#6c757d', marginTop: '2px' }}>
                                                    {dataElement.categoryCombo.categories.map(cat => cat.displayName).join(', ')}
                                                </div>
                                            )}
                                        </Box>
                                    </DataTableCell>
                                    {multiSelect && (
                                        <DataTableCell>
                                            <Box display="flex" flexDirection="column" gap="2px">
                                                {dataElement.sourceDataSets?.map((ds, index) => (
                                                    <Tag key={ds.id} neutral small>
                                                        {ds.displayName}
                                                    </Tag>
                                                ))}
                                                {dataElement.sourceDataSets?.length > 1 && (
                                                    <span style={{ fontSize: '11px', color: '#666' }}>
                                                        Used in {dataElement.sourceDataSets.length} datasets
                                                    </span>
                                                )}
                                            </Box>
                                        </DataTableCell>
                                    )}
                                    <DataTableCell style={{ fontFamily: 'monospace', fontSize: '11px', color: '#6c757d' }}>
                                        {dataElement.id}
                                    </DataTableCell>
                                </DataTableRow>
                            ))}
                        </DataTableBody>
                    </DataTable>

                    {/* Pagination Controls for Data Elements */}
                    {totalDataElementPages > 1 && (
                        <Box padding="16px" display="flex" justifyContent="space-between" alignItems="center" borderTop="1px solid #e8eaed">
                            <Box fontSize="14px" color="#666">
                                {i18n.t('Showing {{start}}-{{end}} of {{total}} data elements', {
                                    start: dataElementStartIndex + 1,
                                    end: Math.min(dataElementEndIndex, totalDataElements),
                                    total: totalDataElements
                                })}
                            </Box>
                            <Pagination
                                page={currentPage}
                                pageCount={totalDataElementPages}
                                pageSize={itemsPerPage}
                                total={totalDataElements}
                                onPageChange={setCurrentPage}
                                hidePageSizeSelect
                            />
                        </Box>
                    )}

                    {filteredDataElements.length === 0 && (
                        <Box textAlign="center" padding="32px">
                            <p style={{ color: '#6c757d' }}>
                                {searchTerm ? i18n.t('No data elements found matching your search.') : i18n.t('No data elements available in this dataset.')}
                            </p>
                        </Box>
                    )}
                </Card>
            </Box>
        )
    }

    return null
}