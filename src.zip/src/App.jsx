import React from 'react'
import i18n from '@dhis2/d2-i18n'
import { AppRouter } from './components/Router/AppRouter'
// './locales' will be populated after running start or build scripts
import './locales'

const MyApp = () => {
    return <AppRouter />
}

export default MyApp
