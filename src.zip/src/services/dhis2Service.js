import { useDataEngine } from '@dhis2/app-runtime'

// DHIS2 API service functions
export const dhis2Service = {
    // Fetch organization units (facilities)
    getOrganisationUnits: async (engine, level = 4) => {
        const query = {
            organisationUnits: {
                resource: 'organisationUnits',
                params: {
                    fields: 'id,displayName,code,level,parent[id,displayName]',
                    paging: false,
                    filter: `level:eq:${level}`
                }
            }
        }
        return engine.query(query)
    },

    // Fetch data sets
    getDataSets: async (engine) => {
        const query = {
            dataSets: {
                resource: 'dataSets',
                params: {
                    fields: 'id,displayName,code,dataSetElements[dataElement[id,displayName,code]]',
                    paging: false
                }
            }
        }
        return engine.query(query)
    },

    // Fetch data values for comparison
    getDataValues: async (engine, { dataSet, orgUnit, period }) => {
        const query = {
            dataValues: {
                resource: 'dataValueSets',
                params: {
                    dataSet,
                    orgUnit,
                    period
                }
            }
        }
        return engine.query(query)
    },

    // Submit data values to DHIS2
    submitDataValues: async (engine, dataValues) => {
        const mutation = {
            resource: 'dataValueSets',
            type: 'create',
            data: {
                dataValues
            }
        }
        return engine.mutate(mutation)
    },

    // Get current user info
    getCurrentUser: async (engine) => {
        const query = {
            me: {
                resource: 'me',
                params: {
                    fields: 'id,displayName,email,authorities,organisationUnits[id,displayName]'
                }
            }
        }
        return engine.query(query)
    },

    // Get periods
    getPeriods: async (engine, periodType = 'Quarterly') => {
        const query = {
            periods: {
                resource: 'periods',
                params: {
                    fields: 'id,displayName,startDate,endDate',
                    filter: `periodType:eq:${periodType}`,
                    paging: false
                }
            }
        }
        return engine.query(query)
    },

    // Create assessment template dataset on local DHIS2
    createAssessmentDataSet: async (engine, dataSetConfig) => {
        const mutation = {
            resource: 'dataSets',
            type: 'create',
            data: dataSetConfig
        }
        return engine.mutate(mutation)
    },

    // Create data elements for assessment
    createDataElements: async (engine, dataElements) => {
        const mutation = {
            resource: 'dataElements',
            type: 'create',
            data: {
                dataElements
            }
        }
        return engine.mutate(mutation)
    },

    // Create category combinations for assessment
    createCategoryCombinations: async (engine, categoryCombos) => {
        const mutation = {
            resource: 'categoryCombos',
            type: 'create',
            data: {
                categoryCombos
            }
        }
        return engine.mutate(mutation)
    },

    // Get existing data elements to avoid duplicates
    getExistingDataElements: async (engine, codes) => {
        const query = {
            dataElements: {
                resource: 'dataElements',
                params: {
                    fields: 'id,code,displayName',
                    filter: codes.map(code => `code:eq:${code}`).join(','),
                    paging: false
                }
            }
        }
        return engine.query(query)
    },

    // DHIS2 Data Store: Assessments CRUD
    getAssessments: async (engine) => {
        const query = {
            assessments: {
                resource: 'dataStore/dqa360/assessments',
                params: { paging: false }
            }
        }
        try {
            const res = await engine.query(query)
            return res.assessments || []
        } catch (e) {
            if (e.details?.httpStatusCode === 404) return []
            throw e
        }
    },
    saveAssessment: async (engine, assessment) => {
        const mutation = {
            resource: 'dataStore/dqa360/assessments',
            type: 'update',
            data: assessment,
            id: assessment.id
        }
        return engine.mutate(mutation)
    },
    createAssessment: async (engine, assessment) => {
        const mutation = {
            resource: 'dataStore/dqa360/assessments',
            type: 'create',
            data: assessment,
            id: assessment.id
        }
        return engine.mutate(mutation)
    },
    deleteAssessment: async (engine, id) => {
        const mutation = {
            resource: `dataStore/dqa360/assessments/${id}`,
            type: 'delete'
        }
        return engine.mutate(mutation)
    },
}

// Custom hook for DHIS2 service
export const useDhis2Service = () => {
    const engine = useDataEngine()
    
    return {
        getOrganisationUnits: (level) => dhis2Service.getOrganisationUnits(engine, level),
        getDataSets: () => dhis2Service.getDataSets(engine),
        getDataValues: (params) => dhis2Service.getDataValues(engine, params),
        submitDataValues: (dataValues) => dhis2Service.submitDataValues(engine, dataValues),
        getCurrentUser: () => dhis2Service.getCurrentUser(engine),
        getPeriods: (periodType) => dhis2Service.getPeriods(engine, periodType),
        createAssessmentDataSet: (dataSetConfig) => dhis2Service.createAssessmentDataSet(engine, dataSetConfig),
        createDataElements: (dataElements) => dhis2Service.createDataElements(engine, dataElements),
        createCategoryCombinations: (categoryCombos) => dhis2Service.createCategoryCombinations(engine, categoryCombos),
        getExistingDataElements: (codes) => dhis2Service.getExistingDataElements(engine, codes),
        getAssessments: () => dhis2Service.getAssessments(engine),
        saveAssessment: (assessment) => dhis2Service.saveAssessment(engine, assessment),
        createAssessment: (assessment) => dhis2Service.createAssessment(engine, assessment),
        deleteAssessment: (id) => dhis2Service.deleteAssessment(engine, id)
    }
}