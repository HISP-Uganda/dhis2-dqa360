import { useDataEngine } from '@dhis2/app-runtime'

/**
 * Service for managing metadata in DHIS2 dataStore
 * Handles all metadata types: Category Options, Categories, Category Combinations,
 * Attributes, Option Sets, Data Elements, Data Sets, Organisation Units
 */

const NAMESPACE = 'dqa360-metadata'

// DataStore keys for different metadata types
const KEYS = {
    CATEGORY_OPTIONS: 'categoryOptions',
    CATEGORIES: 'categories', 
    CATEGORY_COMBOS: 'categoryCombos',
    ATTRIBUTES: 'attributes',
    OPTION_SETS: 'optionSets',
    DATA_ELEMENTS: 'dataElements',
    DATA_SETS: 'dataSets',
    ORGANISATION_UNITS: 'organisationUnits',
    ASSESSMENTS: 'assessments',
    METADATA_VERSION: 'metadataVersion'
}

// Queries for dataStore operations
const queries = {
    // Get all metadata
    getAllMetadata: {
        categoryOptions: {
            resource: `dataStore/${NAMESPACE}/${KEYS.CATEGORY_OPTIONS}`,
            params: {}
        },
        categories: {
            resource: `dataStore/${NAMESPACE}/${KEYS.CATEGORIES}`,
            params: {}
        },
        categoryCombos: {
            resource: `dataStore/${NAMESPACE}/${KEYS.CATEGORY_COMBOS}`,
            params: {}
        },
        attributes: {
            resource: `dataStore/${NAMESPACE}/${KEYS.ATTRIBUTES}`,
            params: {}
        },
        optionSets: {
            resource: `dataStore/${NAMESPACE}/${KEYS.OPTION_SETS}`,
            params: {}
        },
        dataElements: {
            resource: `dataStore/${NAMESPACE}/${KEYS.DATA_ELEMENTS}`,
            params: {}
        },
        dataSets: {
            resource: `dataStore/${NAMESPACE}/${KEYS.DATA_SETS}`,
            params: {}
        },
        organisationUnits: {
            resource: `dataStore/${NAMESPACE}/${KEYS.ORGANISATION_UNITS}`,
            params: {}
        },
        assessments: {
            resource: `dataStore/${NAMESPACE}/${KEYS.ASSESSMENTS}`,
            params: {}
        }
    },

    // Get single metadata type
    getMetadataType: (type) => ({
        data: {
            resource: `dataStore/${NAMESPACE}/${type}`,
            params: {}
        }
    }),

    // Save metadata type
    saveMetadataType: (type, data) => ({
        resource: `dataStore/${NAMESPACE}/${type}`,
        type: 'create',
        data: data
    }),

    // Update metadata type
    updateMetadataType: (type, data) => ({
        resource: `dataStore/${NAMESPACE}/${type}`,
        type: 'update', 
        data: data
    }),

    // Delete metadata type
    deleteMetadataType: (type) => ({
        resource: `dataStore/${NAMESPACE}/${type}`,
        type: 'delete'
    }),

    // Check if namespace exists
    checkNamespace: {
        keys: {
            resource: `dataStore/${NAMESPACE}`,
            params: {}
        }
    },

    // Create namespace
    createNamespace: {
        resource: `dataStore/${NAMESPACE}/${KEYS.METADATA_VERSION}`,
        type: 'create',
        data: {
            version: '1.0.0',
            created: new Date().toISOString(),
            description: 'DQA360 Metadata Storage'
        }
    }
}

/**
 * Custom hook for metadata dataStore operations
 */
export const useMetadataDataStore = () => {
    const engine = useDataEngine()

    /**
     * Initialize the dataStore namespace and default structure
     */
    const initializeDataStore = async () => {
        try {
            // Check if namespace exists
            await engine.query(queries.checkNamespace)
        } catch (error) {
            if (error.details?.httpStatusCode === 404) {
                // Namespace doesn't exist, create it with default structure
                console.log('Creating DQA360 metadata namespace...')
                
                const defaultStructure = {
                    [KEYS.CATEGORY_OPTIONS]: [],
                    [KEYS.CATEGORIES]: [],
                    [KEYS.CATEGORY_COMBOS]: [],
                    [KEYS.ATTRIBUTES]: [],
                    [KEYS.OPTION_SETS]: [],
                    [KEYS.DATA_ELEMENTS]: [],
                    [KEYS.DATA_SETS]: [],
                    [KEYS.ORGANISATION_UNITS]: [],
                    [KEYS.ASSESSMENTS]: [],
                    [KEYS.METADATA_VERSION]: {
                        version: '1.0.0',
                        created: new Date().toISOString(),
                        description: 'DQA360 Metadata Storage'
                    }
                }

                // Create all keys
                for (const [key, data] of Object.entries(defaultStructure)) {
                    try {
                        await engine.mutate({
                            resource: `dataStore/${NAMESPACE}/${key}`,
                            type: 'create',
                            data: data
                        })
                    } catch (createError) {
                        console.warn(`Failed to create ${key}:`, createError)
                    }
                }
                
                console.log('DQA360 metadata namespace created successfully')
            } else {
                console.error('Error checking namespace:', error)
                throw error
            }
        }
    }

    /**
     * Load all metadata from dataStore
     */
    const loadAllMetadata = async () => {
        try {
            await initializeDataStore()
            
            const results = {}
            
            // Load each metadata type
            for (const key of Object.values(KEYS)) {
                if (key === KEYS.METADATA_VERSION) continue
                
                try {
                    const result = await engine.query({
                        data: {
                            resource: `dataStore/${NAMESPACE}/${key}`,
                            params: {}
                        }
                    })
                    results[key] = result.data || []
                } catch (error) {
                    console.warn(`Failed to load ${key}:`, error)
                    results[key] = []
                }
            }
            
            return results
        } catch (error) {
            console.error('Error loading metadata:', error)
            throw error
        }
    }

    /**
     * Load specific metadata type
     */
    const loadMetadataType = async (type) => {
        try {
            await initializeDataStore()
            
            const result = await engine.query({
                data: {
                    resource: `dataStore/${NAMESPACE}/${type}`,
                    params: {}
                }
            })
            
            return result.data || []
        } catch (error) {
            if (error.details?.httpStatusCode === 404) {
                return []
            }
            console.error(`Error loading ${type}:`, error)
            throw error
        }
    }

    /**
     * Save metadata type
     */
    const saveMetadataType = async (type, data) => {
        try {
            await initializeDataStore()
            
            await engine.mutate({
                resource: `dataStore/${NAMESPACE}/${type}`,
                type: 'update',
                data: data
            })
            
            console.log(`${type} saved successfully`)
            return true
        } catch (error) {
            console.error(`Error saving ${type}:`, error)
            throw error
        }
    }

    /**
     * Save single metadata item
     */
    const saveMetadataItem = async (type, item) => {
        try {
            const currentData = await loadMetadataType(type)
            const existingIndex = currentData.findIndex(existing => existing.id === item.id)
            
            let updatedData
            if (existingIndex >= 0) {
                // Update existing item
                updatedData = [...currentData]
                updatedData[existingIndex] = { ...item, lastUpdated: new Date().toISOString() }
            } else {
                // Add new item
                updatedData = [...currentData, { ...item, created: new Date().toISOString() }]
            }
            
            await saveMetadataType(type, updatedData)
            return updatedData
        } catch (error) {
            console.error(`Error saving ${type} item:`, error)
            throw error
        }
    }

    /**
     * Delete metadata item
     */
    const deleteMetadataItem = async (type, itemId) => {
        try {
            const currentData = await loadMetadataType(type)
            const updatedData = currentData.filter(item => item.id !== itemId)
            
            await saveMetadataType(type, updatedData)
            return updatedData
        } catch (error) {
            console.error(`Error deleting ${type} item:`, error)
            throw error
        }
    }

    /**
     * Save complete assessment with all metadata
     */
    const saveAssessment = async (assessment) => {
        try {
            const assessments = await loadMetadataType(KEYS.ASSESSMENTS)
            const existingIndex = assessments.findIndex(existing => existing.id === assessment.id)
            
            let updatedAssessments
            if (existingIndex >= 0) {
                updatedAssessments = [...assessments]
                updatedAssessments[existingIndex] = { ...assessment, lastUpdated: new Date().toISOString() }
            } else {
                updatedAssessments = [...assessments, { ...assessment, created: new Date().toISOString() }]
            }
            
            await saveMetadataType(KEYS.ASSESSMENTS, updatedAssessments)
            return updatedAssessments
        } catch (error) {
            console.error('Error saving assessment:', error)
            throw error
        }
    }

    /**
     * Create default DQA metadata
     */
    const createDefaultDQAMetadata = async () => {
        try {
            // Default category options
            const defaultCategoryOptions = [
                {
                    id: 'co_register_dqa',
                    name: 'Register',
                    shortName: 'Register',
                    code: 'REG',
                    description: 'Data from facility registers',
                    dimensionItemType: 'DATA_ELEMENT',
                    created: new Date().toISOString(),
                    lastUpdated: new Date().toISOString()
                },
                {
                    id: 'co_summary_dqa',
                    name: 'Summary',
                    shortName: 'Summary', 
                    code: 'SUM',
                    description: 'Aggregated summary data',
                    dimensionItemType: 'DATA_ELEMENT',
                    created: new Date().toISOString(),
                    lastUpdated: new Date().toISOString()
                },
                {
                    id: 'co_reported_dqa',
                    name: 'Reported',
                    shortName: 'Reported',
                    code: 'REP',
                    description: 'Officially reported data',
                    dimensionItemType: 'DATA_ELEMENT',
                    created: new Date().toISOString(),
                    lastUpdated: new Date().toISOString()
                },
                {
                    id: 'co_corrected_dqa',
                    name: 'Corrected',
                    shortName: 'Corrected',
                    code: 'COR',
                    description: 'Corrected data values',
                    dimensionItemType: 'DATA_ELEMENT',
                    created: new Date().toISOString(),
                    lastUpdated: new Date().toISOString()
                }
            ]

            // Default category
            const defaultCategory = {
                id: 'cat_dqa_sources',
                name: 'DQA Data Sources',
                shortName: 'DQA Sources',
                code: 'DQA_SRC',
                description: 'Data quality assessment data sources',
                categoryOptions: defaultCategoryOptions.map(co => co.id),
                dataDimension: true,
                dataDimensionType: 'DISAGGREGATION',
                created: new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            }

            // Default category combination
            const defaultCategoryCombo = {
                id: 'cc_dqa_default',
                name: 'DQA Default Category Combination',
                shortName: 'DQA Default',
                code: 'DQA_DEF',
                description: 'Default category combination for DQA assessments',
                categories: [defaultCategory.id],
                dataDimensionType: 'DISAGGREGATION',
                skipTotal: false,
                created: new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            }

            // Default option set
            const defaultOptionSet = {
                id: 'os_facility_types_dqa',
                name: 'Facility Types',
                shortName: 'Facility Types',
                code: 'FAC_TYPES',
                description: 'Types of health facilities',
                valueType: 'TEXT',
                options: [
                    { id: 'opt_hospital', name: 'Hospital', code: 'HOSPITAL', sortOrder: 1 },
                    { id: 'opt_health_center', name: 'Health Center', code: 'HEALTH_CENTER', sortOrder: 2 },
                    { id: 'opt_clinic', name: 'Clinic', code: 'CLINIC', sortOrder: 3 },
                    { id: 'opt_dispensary', name: 'Dispensary', code: 'DISPENSARY', sortOrder: 4 }
                ],
                created: new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            }

            // Default attribute
            const defaultAttribute = {
                id: 'attr_facility_type_dqa',
                name: 'Facility Type',
                shortName: 'Facility Type',
                code: 'FAC_TYPE',
                description: 'Type of health facility',
                valueType: 'TEXT',
                optionSet: defaultOptionSet.id,
                organisationUnitAttribute: true,
                mandatory: false,
                unique: false,
                created: new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            }

            // Save all default metadata
            await saveMetadataType(KEYS.CATEGORY_OPTIONS, defaultCategoryOptions)
            await saveMetadataType(KEYS.CATEGORIES, [defaultCategory])
            await saveMetadataType(KEYS.CATEGORY_COMBOS, [defaultCategoryCombo])
            await saveMetadataType(KEYS.OPTION_SETS, [defaultOptionSet])
            await saveMetadataType(KEYS.ATTRIBUTES, [defaultAttribute])

            console.log('Default DQA metadata created successfully')
            
            return {
                categoryOptions: defaultCategoryOptions,
                categories: [defaultCategory],
                categoryCombos: [defaultCategoryCombo],
                optionSets: [defaultOptionSet],
                attributes: [defaultAttribute]
            }
        } catch (error) {
            console.error('Error creating default DQA metadata:', error)
            throw error
        }
    }

    return {
        initializeDataStore,
        loadAllMetadata,
        loadMetadataType,
        saveMetadataType,
        saveMetadataItem,
        deleteMetadataItem,
        saveAssessment,
        createDefaultDQAMetadata,
        KEYS
    }
}

export { KEYS as METADATA_KEYS }