import React, { useState, useEffect } from 'react'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Tab,
    TabBar,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    NoticeBox,
    InputField,
    SingleSelectField,
    SingleSelectOption,
    Tag,
    CircularLoader
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { useMetadataDataStore, METADATA_KEYS } from '../../services/metadataDataStoreService'
import CategoryOptionFormModal from '../../components/CategoryOptionFormModal'
import CategoryFormModal from '../../components/CategoryFormModal'
import CategoryComboFormModal from '../../components/CategoryComboFormModal'
import AttributeFormModal from '../../components/AttributeFormModal'
import OptionSetFormModal from '../../components/OptionSetFormModal'
import DatasetFormModal from '../../components/DatasetFormModal'
import DataElementFormModal from '../../components/DataElementFormModal'
import OrganizationUnitFormModal from '../../components/OrganizationUnitFormModal'

export const MetadataManagementPage = () => {
    const [activeTab, setActiveTab] = useState('categoryOptions')
    const [searchTerm, setSearchTerm] = useState('')
    const [filterType, setFilterType] = useState('all')
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)
    
    // DataStore service
    const {
        loadAllMetadata,
        saveMetadataItem,
        deleteMetadataItem,
        createDefaultDQAMetadata,
        KEYS
    } = useMetadataDataStore()

    // Modal states
    const [categoryOptionModalOpen, setCategoryOptionModalOpen] = useState(false)
    const [categoryModalOpen, setCategoryModalOpen] = useState(false)
    const [categoryComboModalOpen, setCategoryComboModalOpen] = useState(false)
    const [attributeModalOpen, setAttributeModalOpen] = useState(false)
    const [optionSetModalOpen, setOptionSetModalOpen] = useState(false)
    const [datasetModalOpen, setDatasetModalOpen] = useState(false)
    const [dataElementModalOpen, setDataElementModalOpen] = useState(false)
    const [orgUnitModalOpen, setOrgUnitModalOpen] = useState(false)

    // Editing states
    const [editingItem, setEditingItem] = useState(null)

    // Data states - loaded from dataStore
    const [categoryOptions, setCategoryOptions] = useState([])
    const [categories, setCategories] = useState([])
    const [categoryCombos, setCategoryCombos] = useState([])
    const [attributes, setAttributes] = useState([])
    const [optionSets, setOptionSets] = useState([])
    const [datasets, setDatasets] = useState([])
    const [dataElements, setDataElements] = useState([])
    const [orgUnits, setOrgUnits] = useState([])

    const tabs = [
        { id: 'categoryOptions', label: i18n.t('Category Options'), count: categoryOptions.length },
        { id: 'categories', label: i18n.t('Categories'), count: categories.length },
        { id: 'categoryCombos', label: i18n.t('Category Combinations'), count: categoryCombos.length },
        { id: 'optionSets', label: i18n.t('Option Sets'), count: optionSets.length },
        { id: 'attributes', label: i18n.t('Attributes'), count: attributes.length },
        { id: 'datasets', label: i18n.t('Data Sets'), count: datasets.length },
        { id: 'dataElements', label: i18n.t('Data Elements'), count: dataElements.length },
        { id: 'orgUnits', label: i18n.t('Organisation Units'), count: orgUnits.length }
    ]

    // Load metadata on component mount
    useEffect(() => {
        const loadMetadata = async () => {
            try {
                setLoading(true)
                const metadata = await loadAllMetadata()
                
                setCategoryOptions(metadata[KEYS.CATEGORY_OPTIONS] || [])
                setCategories(metadata[KEYS.CATEGORIES] || [])
                setCategoryCombos(metadata[KEYS.CATEGORY_COMBOS] || [])
                setAttributes(metadata[KEYS.ATTRIBUTES] || [])
                setOptionSets(metadata[KEYS.OPTION_SETS] || [])
                setDatasets(metadata[KEYS.DATA_SETS] || [])
                setDataElements(metadata[KEYS.DATA_ELEMENTS] || [])
                setOrgUnits(metadata[KEYS.ORGANISATION_UNITS] || [])
                
                console.log('Metadata loaded successfully')
            } catch (error) {
                console.error('Error loading metadata:', error)
            } finally {
                setLoading(false)
            }
        }
        
        loadMetadata()
    }, [])

    // Generic handlers with dataStore integration
    const handleSave = async (type, item) => {
        try {
            setSaving(true)
            
            // Map component types to dataStore keys
            const typeKeyMap = {
                categoryOptions: KEYS.CATEGORY_OPTIONS,
                categories: KEYS.CATEGORIES,
                categoryCombos: KEYS.CATEGORY_COMBOS,
                attributes: KEYS.ATTRIBUTES,
                optionSets: KEYS.OPTION_SETS,
                datasets: KEYS.DATA_SETS,
                dataElements: KEYS.DATA_ELEMENTS,
                orgUnits: KEYS.ORGANISATION_UNITS
            }
            
            const dataStoreKey = typeKeyMap[type]
            if (!dataStoreKey) {
                console.error('Unknown metadata type:', type)
                return
            }
            
            // Save to dataStore
            const updatedData = await saveMetadataItem(dataStoreKey, item)
            
            // Update local state
            const setters = {
                categoryOptions: setCategoryOptions,
                categories: setCategories,
                categoryCombos: setCategoryCombos,
                attributes: setAttributes,
                optionSets: setOptionSets,
                datasets: setDatasets,
                dataElements: setDataElements,
                orgUnits: setOrgUnits
            }
            
            const setter = setters[type]
            if (setter) {
                setter(updatedData)
            }
            
            setEditingItem(null)
            console.log(`${type} saved successfully`)
        } catch (error) {
            console.error(`Error saving ${type}:`, error)
        } finally {
            setSaving(false)
        }
    }

    const handleEdit = (type, item) => {
        setEditingItem(item)
        const modalSetters = {
            categoryOptions: setCategoryOptionModalOpen,
            categories: setCategoryModalOpen,
            categoryCombos: setCategoryComboModalOpen,
            attributes: setAttributeModalOpen,
            optionSets: setOptionSetModalOpen,
            datasets: setDatasetModalOpen,
            dataElements: setDataElementModalOpen,
            orgUnits: setOrgUnitModalOpen
        }
        
        const setter = modalSetters[type]
        if (setter) setter(true)
    }

    const handleDelete = async (type, itemId) => {
        try {
            setSaving(true)
            
            // Map component types to dataStore keys
            const typeKeyMap = {
                categoryOptions: KEYS.CATEGORY_OPTIONS,
                categories: KEYS.CATEGORIES,
                categoryCombos: KEYS.CATEGORY_COMBOS,
                attributes: KEYS.ATTRIBUTES,
                optionSets: KEYS.OPTION_SETS,
                datasets: KEYS.DATA_SETS,
                dataElements: KEYS.DATA_ELEMENTS,
                orgUnits: KEYS.ORGANISATION_UNITS
            }
            
            const dataStoreKey = typeKeyMap[type]
            if (!dataStoreKey) {
                console.error('Unknown metadata type:', type)
                return
            }
            
            // Delete from dataStore
            const updatedData = await deleteMetadataItem(dataStoreKey, itemId)
            
            // Update local state
            const setters = {
                categoryOptions: setCategoryOptions,
                categories: setCategories,
                categoryCombos: setCategoryCombos,
                attributes: setAttributes,
                optionSets: setOptionSets,
                datasets: setDatasets,
                dataElements: setDataElements,
                orgUnits: setOrgUnits
            }
            
            const setter = setters[type]
            if (setter) {
                setter(updatedData)
            }
            
            console.log(`${type} deleted successfully`)
        } catch (error) {
            console.error(`Error deleting ${type}:`, error)
        } finally {
            setSaving(false)
        }
    }

    const openCreateModal = (type) => {
        setEditingItem(null)
        const modalSetters = {
            categoryOptions: setCategoryOptionModalOpen,
            categories: setCategoryModalOpen,
            categoryCombos: setCategoryComboModalOpen,
            attributes: setAttributeModalOpen,
            optionSets: setOptionSetModalOpen,
            datasets: setDatasetModalOpen,
            dataElements: setDataElementModalOpen,
            orgUnits: setOrgUnitModalOpen
        }
        
        const setter = modalSetters[type]
        if (setter) setter(true)
    }

    const closeModal = (type) => {
        const modalSetters = {
            categoryOptions: setCategoryOptionModalOpen,
            categories: setCategoryModalOpen,
            categoryCombos: setCategoryComboModalOpen,
            attributes: setAttributeModalOpen,
            optionSets: setOptionSetModalOpen,
            datasets: setDatasetModalOpen,
            dataElements: setDataElementModalOpen,
            orgUnits: setOrgUnitModalOpen
        }
        
        const setter = modalSetters[type]
        if (setter) setter(false)
        setEditingItem(null)
    }

    const getCurrentData = () => {
        const dataMap = {
            categoryOptions,
            categories,
            categoryCombos,
            attributes,
            optionSets,
            datasets,
            dataElements,
            orgUnits
        }
        return dataMap[activeTab] || []
    }

    const getFilteredData = () => {
        const data = getCurrentData()
        if (!searchTerm) return data
        
        return data.filter(item => 
            item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.shortName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.code?.toLowerCase().includes(searchTerm.toLowerCase())
        )
    }

    const renderDataTable = () => {
        const data = getFilteredData()
        
        if (data.length === 0) {
            return (
                <NoticeBox>
                    {searchTerm ? 
                        i18n.t('No items found matching "{{term}}"', { term: searchTerm }) :
                        i18n.t('No {{type}} created yet. Click "Create New" to get started.', { 
                            type: tabs.find(tab => tab.id === activeTab)?.label 
                        })
                    }
                </NoticeBox>
            )
        }

        return (
            <DataTable>
                <DataTableHead>
                    <DataTableRow>
                        <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                        <DataTableColumnHeader>{i18n.t('Short Name')}</DataTableColumnHeader>
                        <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                        <DataTableColumnHeader>{i18n.t('Type/Info')}</DataTableColumnHeader>
                        <DataTableColumnHeader>{i18n.t('Created')}</DataTableColumnHeader>
                        <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                    </DataTableRow>
                </DataTableHead>
                <DataTableBody>
                    {data.map(item => (
                        <DataTableRow key={item.id}>
                            <DataTableCell>
                                <div style={{ fontWeight: '500' }}>{item.name}</div>
                                {item.description && (
                                    <div style={{ fontSize: '12px', color: '#6c757d', marginTop: '2px' }}>
                                        {item.description}
                                    </div>
                                )}
                            </DataTableCell>
                            <DataTableCell>{item.shortName}</DataTableCell>
                            <DataTableCell>
                                {item.code && <Tag neutral>{item.code}</Tag>}
                            </DataTableCell>
                            <DataTableCell>
                                {activeTab === 'categoryOptions' && (
                                    <Tag positive>{i18n.t('Category Option')}</Tag>
                                )}
                                {activeTab === 'categories' && (
                                    <Tag>{i18n.t('{{count}} options', { count: item.categoryOptions?.length || 0 })}</Tag>
                                )}
                                {activeTab === 'categoryCombos' && (
                                    <Tag>{i18n.t('{{count}} categories', { count: item.categories?.length || 0 })}</Tag>
                                )}
                                {activeTab === 'attributes' && (
                                    <Tag neutral>{item.valueType}</Tag>
                                )}
                                {activeTab === 'optionSets' && (
                                    <Tag>{i18n.t('{{count}} options', { count: item.options?.length || 0 })}</Tag>
                                )}
                                {activeTab === 'datasets' && (
                                    <Tag positive>{item.periodType || 'Monthly'}</Tag>
                                )}
                                {activeTab === 'dataElements' && (
                                    <Tag neutral>{item.valueType || 'INTEGER'}</Tag>
                                )}
                                {activeTab === 'orgUnits' && (
                                    <Tag>{i18n.t('Level {{level}}', { level: item.level || 4 })}</Tag>
                                )}
                            </DataTableCell>
                            <DataTableCell>
                                <div style={{ fontSize: '12px', color: '#6c757d' }}>
                                    {new Date(item.created).toLocaleDateString()}
                                </div>
                            </DataTableCell>
                            <DataTableCell>
                                <ButtonStrip>
                                    <Button 
                                        small 
                                        secondary 
                                        onClick={() => handleEdit(activeTab, item)}
                                    >
                                        {i18n.t('Edit')}
                                    </Button>
                                    <Button 
                                        small 
                                        destructive 
                                        onClick={() => handleDelete(activeTab, item.id)}
                                    >
                                        {i18n.t('Delete')}
                                    </Button>
                                </ButtonStrip>
                            </DataTableCell>
                        </DataTableRow>
                    ))}
                </DataTableBody>
            </DataTable>
        )
    }

    const handleCreateDefaultDQAMetadata = async () => {
        try {
            setSaving(true)
            
            // Use the dataStore service to create default metadata
            const defaultMetadata = await createDefaultDQAMetadata()
            
            // Update local state with the created metadata
            setCategoryOptions(defaultMetadata.categoryOptions)
            setCategories(defaultMetadata.categories)
            setCategoryCombos(defaultMetadata.categoryCombos)
            setOptionSets(defaultMetadata.optionSets)
            setAttributes(defaultMetadata.attributes)
            
            console.log('Default DQA metadata created successfully')
        } catch (error) {
            console.error('Error creating default DQA metadata:', error)
        } finally {
            setSaving(false)
        }
    }

    return (
        <Box padding="24px">
            <Card>
                {/* Header */}
                <div style={{ 
                    padding: '24px 24px 0 24px',
                    borderBottom: '1px solid #e8eaed',
                    marginBottom: '0'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                        <h1 style={{ margin: 0, fontSize: '24px', fontWeight: '600', color: '#2c3e50' }}>
                            {i18n.t('Metadata Management')}
                        </h1>
                        <ButtonStrip>
                            <Button 
                                secondary 
                                onClick={handleCreateDefaultDQAMetadata}
                                loading={saving}
                                disabled={saving}
                            >
                                {i18n.t('Create Default DQA Metadata')}
                            </Button>
                            <Button 
                                primary 
                                onClick={() => openCreateModal(activeTab)}
                                disabled={saving}
                            >
                                {i18n.t('Create New {{type}}', { 
                                    type: tabs.find(tab => tab.id === activeTab)?.label.slice(0, -1) || 'Item'
                                })}
                            </Button>
                        </ButtonStrip>
                    </div>

                    {/* Tab Navigation */}
                    <TabBar>
                        {tabs.map(tab => (
                            <Tab 
                                key={tab.id}
                                selected={activeTab === tab.id}
                                onClick={() => setActiveTab(tab.id)}
                            >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    {tab.label}
                                    <Tag small neutral>{tab.count}</Tag>
                                </div>
                            </Tab>
                        ))}
                    </TabBar>
                </div>

                {/* Filters */}
                <div style={{ 
                    padding: '16px 24px',
                    borderBottom: '1px solid #e8eaed',
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'center'
                }}>
                    <div style={{ flex: 1, maxWidth: '400px' }}>
                        <InputField
                            placeholder={i18n.t('Search by name, short name, or code...')}
                            value={searchTerm}
                            onChange={({ value }) => setSearchTerm(value)}
                        />
                    </div>
                    
                    <div style={{ minWidth: '200px' }}>
                        <SingleSelectField
                            selected={filterType}
                            onChange={({ selected }) => setFilterType(selected)}
                        >
                            <SingleSelectOption value="all" label={i18n.t('All items')} />
                            <SingleSelectOption value="recent" label={i18n.t('Recently created')} />
                            <SingleSelectOption value="modified" label={i18n.t('Recently modified')} />
                        </SingleSelectField>
                    </div>
                </div>

                {/* Content */}
                <div style={{ padding: '24px' }}>
                    {loading ? (
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '200px' }}>
                            <CircularLoader />
                        </div>
                    ) : (
                        renderDataTable()
                    )}
                </div>
            </Card>

            {/* Modals */}
            <CategoryOptionFormModal
                isOpen={categoryOptionModalOpen}
                onClose={() => closeModal('categoryOptions')}
                onSave={(item) => handleSave('categoryOptions', item)}
                categoryOption={editingItem}
                availableCategoryOptionGroups={[]}
            />

            <CategoryFormModal
                isOpen={categoryModalOpen}
                onClose={() => closeModal('categories')}
                onSave={(item) => handleSave('categories', item)}
                category={editingItem}
                availableCategoryOptions={categoryOptions}
            />

            <CategoryComboFormModal
                isOpen={categoryComboModalOpen}
                onClose={() => closeModal('categoryCombos')}
                onSave={(item) => handleSave('categoryCombos', item)}
                categoryCombo={editingItem}
                availableCategories={categories}
            />

            <AttributeFormModal
                isOpen={attributeModalOpen}
                onClose={() => closeModal('attributes')}
                onSave={(item) => handleSave('attributes', item)}
                attribute={editingItem}
                availableOptionSets={optionSets}
            />

            <OptionSetFormModal
                isOpen={optionSetModalOpen}
                onClose={() => closeModal('optionSets')}
                onSave={(item) => handleSave('optionSets', item)}
                optionSet={editingItem}
            />

            <DatasetFormModal
                isOpen={datasetModalOpen}
                onClose={() => closeModal('datasets')}
                onSave={(item) => handleSave('datasets', item)}
                dataset={editingItem}
                availableDataElements={dataElements}
                availableOrgUnits={orgUnits}
                availableCategoryOptions={categoryOptions}
                availableIndicators={[]}
            />

            <DataElementFormModal
                isOpen={dataElementModalOpen}
                onClose={() => closeModal('dataElements')}
                onSave={(item) => handleSave('dataElements', item)}
                dataElement={editingItem}
                availableDataElementGroups={[]}
                availableOptionSets={optionSets}
                availableCategoryCombos={categoryCombos}
            />

            <OrganizationUnitFormModal
                isOpen={orgUnitModalOpen}
                onClose={() => closeModal('orgUnits')}
                onSave={(item) => handleSave('orgUnits', item)}
                organizationUnit={editingItem}
                availableParentOrgUnits={orgUnits}
                availableOrgUnitGroups={[]}
                availableOrgUnitGroupSets={[]}
            />
        </Box>
    )
}

export default MetadataManagementPage
