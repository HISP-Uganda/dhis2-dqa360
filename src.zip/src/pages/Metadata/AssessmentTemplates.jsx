import React, { useState, useEffect } from 'react'
import { useDataMutation, useDataQuery } from '@dhis2/app-runtime'
import { useDhis2Service } from '../../services/dhis2Service'
import {
    Box,
    Button,
    ButtonStrip,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    NoticeBox,
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    InputField,
    TextAreaField,
    SingleSelect,
    SingleSelectOption,
    MultiSelect,
    MultiSelectOption,
    Tag,
    Checkbox,
    Card,
    CircularLoader,
    AlertBar,
    Divider
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

// Queries for local DHIS2 metadata
const localOrgUnitsQuery = {
    organisationUnits: {
        resource: 'organisationUnits',
        params: {
            fields: 'id,displayName,code,level,path',
            pageSize: 1000
        }
    }
}

const localDataElementsQuery = {
    dataElements: {
        resource: 'dataElements',
        params: {
            fields: 'id,displayName,code,valueType,domainType',
            pageSize: 1000
        }
    }
}

const localDataSetsQuery = {
    dataSets: {
        resource: 'dataSets',
        params: {
            fields: 'id,displayName,name,code',
            pageSize: 1000
        }
    }
}

const defaultCategoryComboQuery = {
    categoryCombos: {
        resource: 'categoryCombos',
        params: {
            fields: 'id,displayName,name',
            filter: 'name:eq:default',
            pageSize: 10
        }
    }
}

// Mutations for creating DHIS2 metadata
const createDataElementMutation = {
    resource: 'dataElements',
    type: 'create',
    data: ({ dataElement }) => dataElement
}

const createDataSetMutation = {
    resource: 'dataSets',
    type: 'create',
    data: ({ dataSet }) => dataSet
}

export const AssessmentTemplates = ({ dhis2Config, dataSets = [], selectedDataSet, selectedDataElements, selectedOrgUnits, onEditConfiguration }) => {
    // Data queries for local DHIS2
    const { data: localOrgUnits, loading: loadingOrgUnits } = useDataQuery(localOrgUnitsQuery)
    const { data: localDataElements, loading: loadingDataElements } = useDataQuery(localDataElementsQuery)
    const { data: localDataSets, loading: loadingDataSets } = useDataQuery(localDataSetsQuery)
    const { data: categoryCombos, loading: loadingCategoryCombos } = useDataQuery(defaultCategoryComboQuery)
    
    // Mutations
    const [createDataSet, { loading: creatingDataSet }] = useDataMutation(createDataSetMutation)
    const [createDataElement, { loading: creatingDataElement }] = useDataMutation(createDataElementMutation)
    
    const [showCreateModal, setShowCreateModal] = useState(false)
    const [creationProgress, setCreationProgress] = useState({
        show: false,
        current: 0,
        total: 4,
        currentTool: '',
        completed: []
    })

    // Assessment Tool Types
    const assessmentTools = [
        {
            id: 'primary',
            name: i18n.t('Primary Tools (Register)'),
            description: i18n.t('Data collection from registers - assessment team counts from source documents'),
            suffix: '_PRIMARY',
            color: 'blue',
            icon: '📋'
        },
        {
            id: 'summary',
            name: i18n.t('Summary Tools'),
            description: i18n.t('Data from facility compiled summary reports'),
            suffix: '_SUMMARY',
            color: 'green',
            icon: '📊'
        },
        {
            id: 'dhis2',
            name: i18n.t('DHIS2 Submitted Data'),
            description: i18n.t('Data from national DHIS2 instance (requires configuration)'),
            suffix: '_DHIS2',
            color: 'purple',
            icon: '🌐'
        },
        {
            id: 'correction',
            name: i18n.t('Correction Form'),
            description: i18n.t('Empty form for data submission when discrepancies are found'),
            suffix: '_CORRECTION',
            color: 'orange',
            icon: '✏️'
        }
    ]

    // Helper function to find or create data elements
    const ensureDataElementsExist = async (externalDataElements) => {
        // Handle nested DHIS2 API response structure
        const localDataElementsList = localDataElements?.dataElements?.dataElements || localDataElements?.dataElements || []
        
        // Validate that localDataElementsList is an array
        if (!Array.isArray(localDataElementsList)) {
            console.warn('Local data elements is not an array:', localDataElements)
            throw new Error(i18n.t('Failed to load local data elements. Please refresh and try again.'))
        }
        
        if (!Array.isArray(externalDataElements)) {
            console.warn('External data elements is not an array:', externalDataElements)
            throw new Error(i18n.t('Invalid external data elements provided'))
        }
        
        const createdDataElements = []
        
        for (const extDE of externalDataElements) {
            console.log('Processing external data element:', extDE)
            
            // Check if data element already exists locally (by code)
            const originalCode = extDE.dataElement?.code || extDE.code
            const possibleCodes = []
            
            if (originalCode) {
                possibleCodes.push(`${originalCode}_ASSESSMENT`)
                possibleCodes.push(originalCode)
            }
            
            // Also check by display name similarity for existing assessment data elements
            const displayName = extDE.dataElement?.displayName || extDE.displayName
            if (displayName) {
                // Look for existing assessment data elements with similar names
                const assessmentPattern = displayName.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()
                possibleCodes.push(`${assessmentPattern}_ASSESSMENT`)
            }
            
            console.log('Looking for local data element with codes:', possibleCodes)
            
            const existingDE = localDataElementsList.find(localDE => 
                possibleCodes.includes(localDE.code)
            )
            
            console.log('Found existing data element:', existingDE)
            
            if (existingDE) {
                // Check if we already added this data element to avoid duplicates
                const alreadyAdded = createdDataElements.find(de => de.id === existingDE.id)
                if (!alreadyAdded) {
                    createdDataElements.push(existingDE)
                    console.log('Added existing data element:', existingDE.id, existingDE.displayName)
                } else {
                    console.log('Data element already added, skipping:', existingDE.id)
                }
            } else {
                // Create new data element
                const displayName = extDE.dataElement?.displayName || extDE.displayName || 'Unknown'
                
                // Generate a safe code from the display name if no code is available
                const originalCode = extDE.dataElement?.code || extDE.code
                let safeCode
                
                if (originalCode) {
                    safeCode = `${originalCode}_ASSESSMENT`
                } else {
                    // Generate code from display name
                    safeCode = displayName
                        .replace(/[^a-zA-Z0-9]/g, '_') // Replace non-alphanumeric with underscore
                        .replace(/_+/g, '_') // Replace multiple underscores with single
                        .replace(/^_|_$/g, '') // Remove leading/trailing underscores
                        .toUpperCase()
                        .substring(0, 20) + '_ASSESSMENT' // Limit length
                }
                
                console.log('Generated code for data element:', safeCode)
                
                // Check if code already exists in local data elements
                const codeExists = localDataElementsList.find(de => de.code === safeCode)
                if (codeExists) {
                    // Add timestamp to make code unique
                    safeCode = `${safeCode}_${Date.now().toString().slice(-6)}`
                    console.log('Code already exists, using unique code:', safeCode)
                }
                
                const newDataElement = {
                    name: `${displayName} (Assessment)`,
                    shortName: displayName.substring(0, 25),
                    code: safeCode,
                    valueType: extDE.dataElement?.valueType || extDE.valueType || 'INTEGER',
                    domainType: 'AGGREGATE',
                    aggregationType: 'SUM',
                    categoryCombo: { id: getDefaultCategoryComboId() }
                }
                
                try {
                    console.log('Creating data element:', newDataElement)
                    const result = await createDataElement({ dataElement: newDataElement })
                    console.log('Data element creation result:', result)
                    createdDataElements.push({
                        id: result.response.uid,
                        ...newDataElement
                    })
                } catch (error) {
                    console.error('Error creating data element:', error)
                    console.error('Data element that failed:', newDataElement)
                    console.error('Full error details:', error.details || error.message || error)
                    
                    // Handle specific error types
                    if (error.status === 409 || error.httpStatusCode === 409) {
                        console.log('409 Conflict detected for data element, checking for existing...')
                        // Try to find the existing data element with this code/name
                        const existingByCode = localDataElementsList.find(de => de.code === newDataElement.code)
                        const existingByName = localDataElementsList.find(de => de.name === newDataElement.name)
                        
                        if (existingByCode || existingByName) {
                            console.log('Found existing data element after conflict, using it:', existingByCode || existingByName)
                            createdDataElements.push(existingByCode || existingByName)
                        } else {
                            // Generate a more unique code and try again
                            const timestamp = Date.now().toString()
                            const uniqueCode = `${safeCode}_${timestamp.slice(-8)}`
                            const uniqueName = `${newDataElement.name} ${timestamp.slice(-6)}`
                            
                            console.log('Retrying with unique identifiers:', { code: uniqueCode, name: uniqueName })
                            
                            try {
                                const retryDataElement = { ...newDataElement, code: uniqueCode, name: uniqueName }
                                const retryResult = await createDataElement({ dataElement: retryDataElement })
                                console.log('Retry successful:', retryResult)
                                createdDataElements.push({
                                    id: retryResult.response.uid,
                                    ...retryDataElement
                                })
                            } catch (retryError) {
                                console.error('Retry also failed:', retryError)
                                
                                // If retry also fails with 409, try to find any existing data element with similar pattern
                                if (retryError.status === 409 || retryError.httpStatusCode === 409) {
                                    const similarDE = localDataElementsList.find(de => 
                                        de.code?.includes(originalCode) || 
                                        de.displayName?.includes(displayName.substring(0, 20))
                                    )
                                    if (similarDE) {
                                        console.log('Using similar existing data element:', similarDE)
                                        createdDataElements.push(similarDE)
                                    } else {
                                        throw new Error(`Failed to create data element "${newDataElement.name}" - conflicts persist even after retry`)
                                    }
                                } else {
                                    throw new Error(`Failed to create data element "${newDataElement.name}" even after retry: ${retryError.details?.message || retryError.message || retryError}`)
                                }
                            }
                        }
                    } else if (error.status === 405 || error.httpStatusCode === 405) {
                        console.error('405 Method Not Allowed for data element creation - check user permissions')
                        throw new Error(`Permission denied: Cannot create data elements. Check user permissions for data element creation.`)
                    } else if (error.status === 400 || error.httpStatusCode === 400) {
                        console.error('400 Bad Request for data element:', error.details || error.message)
                        throw new Error(`Invalid data element structure for "${newDataElement.name}": ${error.details?.message || error.message || 'Unknown validation error'}`)
                    } else {
                        throw new Error(`Failed to create data element "${newDataElement.name}": ${error.details?.message || error.message || error}`)
                    }
                }
            }
        }
        
        return createdDataElements
    }
    
    // Helper function to map organisation units
    const mapOrganisationUnits = (externalOrgUnits) => {
        // Handle nested DHIS2 API response structure
        const localOrgUnitsList = localOrgUnits?.organisationUnits?.organisationUnits || localOrgUnits?.organisationUnits || []
        
        // Validate that localOrgUnitsList is an array
        if (!Array.isArray(localOrgUnitsList)) {
            console.warn('Local organisation units is not an array:', localOrgUnits)
            throw new Error(i18n.t('Failed to load local organisation units. Please refresh and try again.'))
        }
        
        if (!Array.isArray(externalOrgUnits)) {
            console.warn('External organisation units is not an array:', externalOrgUnits)
            throw new Error(i18n.t('Invalid external organisation units provided'))
        }
        
        const mappedOrgUnits = []
        
        for (const extOU of externalOrgUnits) {
            // Try to find matching org unit by name or code
            const matchingOU = localOrgUnitsList.find(localOU => 
                localOU.displayName === extOU.displayName ||
                localOU.code === extOU.code ||
                localOU.displayName.toLowerCase().includes(extOU.displayName.toLowerCase())
            )
            
            if (matchingOU) {
                mappedOrgUnits.push(matchingOU)
            } else {
                // Use the first available org unit as fallback (or create logic here)
                if (localOrgUnitsList.length > 0) {
                    mappedOrgUnits.push(localOrgUnitsList[0])
                }
            }
        }
        
        return mappedOrgUnits
    }
    
    // Helper function to get default category combo ID
    const getDefaultCategoryComboId = () => {
        // Handle different possible data structures - DHIS2 API returns nested structure
        const categoryCombosList = categoryCombos?.categoryCombos?.categoryCombos || categoryCombos?.categoryCombos || []
        
        if (!Array.isArray(categoryCombosList)) {
            console.warn('Category combos data is not an array:', categoryCombos)
            return 'bjDvmb4bfuf' // Fallback to common default ID
        }
        
        const defaultCombo = categoryCombosList.find(cc => 
            cc?.name?.toLowerCase().includes('default') ||
            cc?.displayName?.toLowerCase().includes('default')
        )
        
        return defaultCombo?.id || 'bjDvmb4bfuf' // Fallback to common default ID
    }

    // Helper function to check if dataset already exists
    const checkDataSetExists = (name, code) => {
        const localDataSetsList = localDataSets?.dataSets?.dataSets || localDataSets?.dataSets || []
        
        if (!Array.isArray(localDataSetsList)) {
            console.warn('Local datasets is not an array:', localDataSets)
            return null
        }
        
        // Check by exact name or code match
        const existingDataSet = localDataSetsList.find(ds => 
            ds.name === name || 
            ds.code === code ||
            ds.displayName === name
        )
        
        return existingDataSet || null
    }

    // Helper function to generate intelligent short names
    const generateIntelligentShortName = (fullName, toolSuffix, maxLength = 50, includeTimestamp = true) => {
        // Remove common words and abbreviate intelligently
        const commonWords = ['Report', 'Monthly', 'Annual', 'Quarterly', 'Weekly', 'Daily', 'Data', 'Form', 'Register', 'Summary', 'the', 'and', 'of', 'for', 'in', 'on', 'at', 'to', 'with']
        const abbreviations = {
            'Monthly': 'M',
            'Quarterly': 'Q', 
            'Annual': 'A',
            'Weekly': 'W',
            'Daily': 'D',
            'Report': 'Rpt',
            'Summary': 'Sum',
            'Register': 'Reg',
            'Outpatient': 'OPD',
            'Inpatient': 'IPD',
            'Emergency': 'Emerg',
            'Department': 'Dept',
            'Management': 'Mgmt',
            'Information': 'Info',
            'System': 'Sys',
            'Health': 'Hlth',
            'Medical': 'Med',
            'Clinical': 'Clin',
            'Laboratory': 'Lab',
            'Pharmacy': 'Pharm',
            'Maternal': 'Mat',
            'Child': 'Ch',
            'Family': 'Fam',
            'Planning': 'Plan',
            'Immunization': 'Immun',
            'Vaccination': 'Vacc',
            'Prevention': 'Prev',
            'Treatment': 'Treat',
            'Diagnosis': 'Diag',
            'Assessment': 'Assess'
        }
        
        // Clean and split the name
        let words = fullName
            .replace(/[^\w\s-]/g, ' ') // Replace special chars with spaces
            .replace(/\s+/g, ' ') // Replace multiple spaces with single
            .trim()
            .split(' ')
            .filter(word => word.length > 0)
        
        // Apply abbreviations and remove common words
        words = words.map(word => {
            const upperWord = word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
            return abbreviations[upperWord] || word
        }).filter(word => !commonWords.includes(word.toLowerCase()) || word.length <= 3)
        
        // Convert tool suffix to readable format
        const toolName = toolSuffix.replace('_', ' ').trim()
        const toolAbbrev = {
            'PRIMARY': 'Pri',
            'SUMMARY': 'Sum', 
            'DHIS2': 'D2',
            'CORRECTION': 'Corr'
        }[toolName] || toolName.substring(0, 3)
        
        // Build short name progressively
        let shortName = ''
        const timestamp = includeTimestamp ? Date.now().toString().slice(-4) : ''
        const timestampSpace = includeTimestamp ? timestamp.length + 1 : 0 // +1 for space
        let remainingLength = maxLength - toolAbbrev.length - 1 - timestampSpace // Reserve space for tool suffix and timestamp
        
        // Add words until we run out of space
        for (const word of words) {
            const nextAddition = shortName ? ` ${word}` : word
            if ((shortName + nextAddition).length <= remainingLength) {
                shortName += nextAddition
            } else if (remainingLength > 3) {
                // Try to add abbreviated version
                const abbrev = word.substring(0, Math.min(3, remainingLength - (shortName ? 1 : 0)))
                if (shortName) {
                    shortName += ` ${abbrev}`
                } else {
                    shortName = abbrev
                }
                break
            } else {
                break
            }
        }
        
        // Add tool suffix and timestamp
        if (includeTimestamp && timestamp) {
            shortName = `${shortName} ${toolAbbrev} ${timestamp}`.substring(0, maxLength)
        } else {
            shortName = `${shortName} ${toolAbbrev}`.substring(0, maxLength)
        }
        
        const finalShortName = shortName.trim()
        
        // Validation
        if (finalShortName.length > maxLength) {
            console.warn(`Generated short name exceeds max length: "${finalShortName}" (${finalShortName.length} > ${maxLength})`)
            return finalShortName.substring(0, maxLength).trim()
        }
        
        if (finalShortName.length === 0) {
            console.warn(`Generated empty short name for: "${fullName}" + "${toolSuffix}"`)
            return `Dataset ${toolAbbrev}`.substring(0, maxLength)
        }
        
        return finalShortName
    }

    // Helper function to check if short name already exists
    const checkShortNameExists = (shortName) => {
        const localDataSetsList = localDataSets?.dataSets?.dataSets || localDataSets?.dataSets || []
        
        if (!Array.isArray(localDataSetsList)) {
            return false
        }
        
        return localDataSetsList.some(ds => ds.shortName === shortName)
    }

    // Helper function to generate unique dataset identifiers with intelligent short names
    const generateUniqueDataSetIdentifiers = (baseName, baseCode, toolSuffix) => {
        const timestamp = Date.now().toString()
        const randomSuffix = Math.random().toString(36).substr(2, 4).toUpperCase()
        
        // Generate intelligent short name
        let baseShortName = generateIntelligentShortName(baseName, toolSuffix, 50)
        console.log(`Generated intelligent short name for "${baseName}" + "${toolSuffix}": "${baseShortName}" (${baseShortName.length} chars)`)
        
        // Generate multiple variations to try
        const variations = [
            {
                name: `${baseName}${toolSuffix}`,
                code: `${baseCode}${toolSuffix}`,
                shortName: baseShortName
            },
            {
                name: `${baseName}${toolSuffix}_${timestamp.slice(-6)}`,
                code: `${baseCode}${toolSuffix}_${timestamp.slice(-6)}`,
                shortName: `${baseShortName} ${timestamp.slice(-4)}`.substring(0, 50)
            },
            {
                name: `${baseName}${toolSuffix}_${randomSuffix}`,
                code: `${baseCode}${toolSuffix}_${randomSuffix}`,
                shortName: `${baseShortName} ${randomSuffix}`.substring(0, 50)
            }
        ]
        
        // Find the first variation that doesn't exist (check name, code, AND shortName)
        for (const variation of variations) {
            const existingByNameOrCode = checkDataSetExists(variation.name, variation.code)
            const existingByShortName = checkShortNameExists(variation.shortName)
            
            if (!existingByNameOrCode && !existingByShortName) {
                console.log('Found unique identifiers:', variation)
                return variation
            }
        }
        
        // If all variations exist, create a more unique version
        const uniqueId = `${timestamp.slice(-6)}${randomSuffix}`
        const fallbackShortName = generateIntelligentShortName(baseName, `${toolSuffix}_${uniqueId}`, 50)
        
        const fallback = {
            name: `${baseName}${toolSuffix}_${uniqueId}`,
            code: `${baseCode}${toolSuffix}_${uniqueId}`,
            shortName: fallbackShortName
        }
        
        console.log('Using fallback unique identifiers:', fallback)
        return fallback
    }
    
    // Function to create dataset in DHIS2
    const createAssessmentDataSet = async (toolConfig, dataElements, orgUnits) => {
        console.log(`Creating dataset for ${toolConfig.name} with:`)
        console.log('Data Elements:', dataElements)
        console.log('Org Units:', orgUnits)
        
        const baseDataSetName = selectedDataSet?.displayName || 'Unknown Dataset'
        const baseDataSetCode = selectedDataSet?.id || 'unknown'
        
        // Check if dataset already exists first
        const existingDataSet = checkDataSetExists(
            `${baseDataSetName}${toolConfig.suffix}`,
            `${baseDataSetCode}${toolConfig.suffix}`
        )
        
        if (existingDataSet) {
            console.log(`Dataset already exists for ${toolConfig.name}:`, existingDataSet)
            return { 
                success: true, 
                dataSet: existingDataSet,
                existed: true
            }
        }
        
        // Generate unique identifiers to avoid conflicts
        const uniqueIdentifiers = generateUniqueDataSetIdentifiers(
            baseDataSetName,
            baseDataSetCode,
            toolConfig.suffix
        )
        
        // Validate data elements have IDs
        const validDataElements = dataElements.filter(de => de && de.id)
        if (validDataElements.length === 0) {
            throw new Error('No valid data elements with IDs found')
        }
        
        // Remove duplicate data elements by ID
        const uniqueDataElements = validDataElements.filter((de, index, self) => 
            index === self.findIndex(d => d.id === de.id)
        )
        
        console.log(`Original data elements: ${validDataElements.length}, Unique data elements: ${uniqueDataElements.length}`)
        console.log('Unique data element IDs:', uniqueDataElements.map(de => de.id))
        
        // Validate org units have IDs
        const validOrgUnits = orgUnits.filter(ou => ou && ou.id)
        if (validOrgUnits.length === 0) {
            throw new Error('No valid organisation units with IDs found')
        }
        
        console.log(`Valid data elements: ${uniqueDataElements.length}, Valid org units: ${validOrgUnits.length}`)
        
        // Create dataset object with validated structure
        const dataSet = {
            name: uniqueIdentifiers.name,
            shortName: uniqueIdentifiers.shortName,
            code: uniqueIdentifiers.code,
            periodType: selectedDataSet?.periodType || 'Monthly',
            dataSetElements: uniqueDataElements.map(de => ({
                dataElement: { id: de.id }
            })),
            organisationUnits: validOrgUnits.map(ou => ({ id: ou.id })),
            categoryCombo: { id: getDefaultCategoryComboId() },
            description: `${toolConfig.description} - Generated from ${selectedDataSet?.displayName || 'Unknown Dataset'}`,
            expiryDays: 0,
            openFuturePeriods: 0,
            timelyDays: 15,
            publicAccess: 'r-------',
            externalAccess: false
        }

        // Attempt to create the dataset with comprehensive error handling
        const maxRetries = 3
        let lastError = null
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                console.log(`Attempt ${attempt}/${maxRetries} - Creating dataset for ${toolConfig.name}:`, {
                    name: dataSet.name,
                    code: dataSet.code,
                    shortName: dataSet.shortName
                })
                
                const result = await createDataSet({ dataSet })
                console.log(`Dataset creation successful for ${toolConfig.name}:`, result)
                
                return { 
                    success: true, 
                    dataSet: { ...dataSet, id: result.response.uid },
                    attempt
                }
                
            } catch (error) {
                console.error(`Attempt ${attempt}/${maxRetries} failed for ${toolConfig.name}:`, error)
                lastError = error
                
                // Handle specific error types
                if (error.status === 409 || error.httpStatusCode === 409) {
                    console.log(`409 Conflict detected on attempt ${attempt}`)
                    console.log('Error details:', error.response?.errorReports || error.details || error.message)
                    
                    // Check if it's a shortName conflict specifically
                    const isShortNameConflict = error.response?.errorReports?.some(report => 
                        report.errorProperty === 'shortName' || 
                        report.message?.includes('shortName') ||
                        report.message?.includes('short name')
                    )
                    
                    if (isShortNameConflict) {
                        console.log('ShortName conflict detected, generating more unique short name...')
                        
                        // Generate a more unique short name with timestamp and random suffix
                        const timestamp = Date.now().toString()
                        const randomId = Math.random().toString(36).substr(2, 4).toUpperCase()
                        const uniqueSuffix = `${timestamp.slice(-4)}${randomId}`
                        
                        // Create new short name ensuring it's unique and under 50 chars
                        const baseShortName = generateIntelligentShortName(baseDataSetName, toolConfig.suffix, 40) // Leave room for unique suffix
                        dataSet.shortName = `${baseShortName} ${uniqueSuffix}`.substring(0, 50)
                        
                        // Also update name and code to be safe
                        dataSet.name = `${baseDataSetName}${toolConfig.suffix}_${uniqueSuffix}`
                        dataSet.code = `${baseDataSetCode}${toolConfig.suffix}_${uniqueSuffix}`
                        
                        console.log(`Updated identifiers for shortName conflict:`, {
                            name: dataSet.name,
                            code: dataSet.code,
                            shortName: dataSet.shortName
                        })
                    } else {
                        // General conflict, generate new unique identifiers for next attempt
                        const newIdentifiers = generateUniqueDataSetIdentifiers(
                            baseDataSetName,
                            baseDataSetCode,
                            `${toolConfig.suffix}_RETRY${attempt}`
                        )
                        
                        dataSet.name = newIdentifiers.name
                        dataSet.code = newIdentifiers.code
                        dataSet.shortName = newIdentifiers.shortName
                        
                        console.log(`Updated identifiers for general conflict:`, newIdentifiers)
                    }
                    
                } else if (error.status === 405 || error.httpStatusCode === 405) {
                    console.error(`405 Method Not Allowed - This might be a permissions issue or API endpoint problem`)
                    // Don't retry 405 errors as they're likely configuration issues
                    break
                    
                } else if (error.status === 400 || error.httpStatusCode === 400) {
                    console.error(`400 Bad Request - Invalid data structure:`, error.details || error.message)
                    // Try to fix common validation issues
                    if (attempt < maxRetries) {
                        // Remove potentially problematic fields
                        delete dataSet.publicAccess
                        delete dataSet.externalAccess
                        console.log(`Removed access fields for retry attempt ${attempt + 1}`)
                    }
                    
                } else {
                    console.error(`Unexpected error (${error.status || error.httpStatusCode}):`, error.details || error.message)
                }
                
                // If this is the last attempt, don't continue
                if (attempt === maxRetries) {
                    break
                }
                
                // Wait a bit before retrying
                await new Promise(resolve => setTimeout(resolve, 1000 * attempt))
            }
        }
        
        // All attempts failed
        console.error(`All ${maxRetries} attempts failed for ${toolConfig.name}`)
        
        // Provide specific error messages based on the last error
        let errorMessage = 'Unknown error occurred'
        if (lastError) {
            if (lastError.status === 409 || lastError.httpStatusCode === 409) {
                errorMessage = `Dataset with similar name/code already exists and couldn't generate unique identifiers after ${maxRetries} attempts`
            } else if (lastError.status === 405 || lastError.httpStatusCode === 405) {
                errorMessage = 'Method not allowed - check user permissions for dataset creation or API endpoint configuration'
            } else if (lastError.status === 400 || lastError.httpStatusCode === 400) {
                errorMessage = `Invalid dataset structure: ${lastError.details?.message || lastError.message || 'Unknown validation error'}`
            } else {
                errorMessage = lastError.details?.message || lastError.message || lastError.toString()
            }
        }
        
        return { 
            success: false, 
            error: errorMessage,
            fullError: lastError,
            attempts: maxRetries
        }
    }

    // Comprehensive validation function
    const validatePrerequisites = () => {
        console.log('=== Validating Prerequisites ===')
        
        // 1. Validate selected dataset
        if (!selectedDataSet) {
            throw new Error(i18n.t('No dataset selected'))
        }
        console.log('✅ Dataset selected:', selectedDataSet.displayName)

        // 2. Validate selected data elements
        if (!Array.isArray(selectedDataElements) || selectedDataElements.length === 0) {
            throw new Error(i18n.t('No data elements selected or invalid data elements'))
        }
        console.log('✅ Data elements selected:', selectedDataElements.length)

        // 3. Validate selected organisation units
        if (!Array.isArray(selectedOrgUnits) || selectedOrgUnits.length === 0) {
            throw new Error(i18n.t('No organisation units selected or invalid organisation units'))
        }
        console.log('✅ Organisation units selected:', selectedOrgUnits.length)

        // 4. Validate local metadata is loaded
        if (loadingOrgUnits || loadingDataElements || loadingDataSets || loadingCategoryCombos) {
            throw new Error(i18n.t('Local DHIS2 metadata is still loading. Please wait...'))
        }
        
        if (!localOrgUnits || !localDataElements || !localDataSets || !categoryCombos) {
            throw new Error(i18n.t('Local DHIS2 metadata not loaded. Please refresh the page.'))
        }
        console.log('✅ Local metadata loaded')

        // 5. Validate category combo availability
        const defaultCategoryComboId = getDefaultCategoryComboId()
        if (!defaultCategoryComboId) {
            throw new Error(i18n.t('Default category combination not found'))
        }
        console.log('✅ Default category combo available:', defaultCategoryComboId)

        // 6. Validate data element structure
        const invalidDataElements = selectedDataElements.filter(de => 
            !de || (!de.id && !de.code && !de.dataElement?.id && !de.dataElement?.code)
        )
        if (invalidDataElements.length > 0) {
            throw new Error(i18n.t('Some selected data elements are invalid or missing required fields'))
        }
        console.log('✅ Data elements structure validated')

        // 7. Validate organisation unit structure
        const invalidOrgUnits = selectedOrgUnits.filter(ou => 
            !ou || (!ou.id && !ou.displayName)
        )
        if (invalidOrgUnits.length > 0) {
            throw new Error(i18n.t('Some selected organisation units are invalid or missing required fields'))
        }
        console.log('✅ Organisation units structure validated')

        console.log('✅ All prerequisites validated successfully')
        return true
    }

    // Function to create all 4 assessment tools
    const handleCreateAssessmentTools = async () => {
        console.log('=== Starting Assessment Tool Creation ===')
        console.log('Selected Dataset:', selectedDataSet)
        console.log('Selected Data Elements:', selectedDataElements)
        console.log('Selected Org Units:', selectedOrgUnits)
        
        try {
            // Step 0: Comprehensive validation
            validatePrerequisites()
            console.log('✅ All validations passed, proceeding with creation...')
        } catch (validationError) {
            console.error('❌ Validation failed:', validationError.message)
            alert(validationError.message)
            return
        }

        setCreationProgress({
            show: true,
            current: 0,
            total: 5, // 1 for data elements + 4 for datasets
            currentTool: i18n.t('Preparing data elements...'),
            completed: []
        })

        try {
            // Step 1: Ensure data elements exist in local DHIS2
            setCreationProgress(prev => ({
                ...prev,
                current: 1,
                currentTool: i18n.t('Creating/mapping data elements...')
            }))

            console.log('Step 1: Processing data elements...')
            const localDataElementsForAssessment = await ensureDataElementsExist(selectedDataElements)
            console.log('Data elements processed:', localDataElementsForAssessment.length)
            
            // Step 2: Map organisation units
            console.log('Step 2: Processing organisation units...')
            const localOrgUnitsForAssessment = mapOrganisationUnits(selectedOrgUnits)
            console.log('Organisation units processed:', localOrgUnitsForAssessment.length)
            
            if (localOrgUnitsForAssessment.length === 0) {
                throw new Error(i18n.t('No matching organisation units found in local DHIS2'))
            }

            const results = []

            // Step 3: Create datasets
            for (let i = 0; i < assessmentTools.length; i++) {
                const tool = assessmentTools[i]
                
                setCreationProgress(prev => ({
                    ...prev,
                    current: i + 2,
                    currentTool: tool.name
                }))

                const result = await createAssessmentDataSet(tool, localDataElementsForAssessment, localOrgUnitsForAssessment)
                results.push({ tool, result })

                if (result.success) {
                    setCreationProgress(prev => ({
                        ...prev,
                        completed: [...prev.completed, tool.id]
                    }))
                }

                // Small delay between creations
                await new Promise(resolve => setTimeout(resolve, 500))
            }

            // Show completion
            setTimeout(() => {
                setCreationProgress(prev => ({ ...prev, show: false }))
                
                const successful = results.filter(r => r.result.success).length
                const failed = results.filter(r => !r.result.success).length
                
                if (successful === 4) {
                    alert(i18n.t('All 4 assessment tools created successfully!'))
                } else {
                    const failedTools = results.filter(r => !r.result.success)
                    const successfulTools = results.filter(r => r.result.success)
                    
                    let message = i18n.t('Assessment Tool Creation Results') + ':\n\n'
                    
                    if (successfulTools.length > 0) {
                        message += i18n.t('✅ Successfully Created ({{count}})', { count: successfulTools.length }) + ':\n'
                        successfulTools.forEach(st => {
                            const existed = st.result.existed ? ' (already existed)' : ''
                            message += `• ${st.tool.name}${existed}\n`
                        })
                        message += '\n'
                    }
                    
                    if (failedTools.length > 0) {
                        message += i18n.t('❌ Failed to Create ({{count}})', { count: failedTools.length }) + ':\n'
                        failedTools.forEach(ft => {
                            message += `• ${ft.tool.name}: ${ft.result.error}\n`
                        })
                    }
                    
                    alert(message)
                }
            }, 1000)

        } catch (error) {
            console.error('Error in assessment tool creation:', error)
            console.error('Error stack:', error.stack)
            setCreationProgress(prev => ({ ...prev, show: false }))
            
            // Show detailed error information
            const errorMessage = error.details?.message || error.message || error.toString()
            const errorDetails = error.details ? JSON.stringify(error.details, null, 2) : ''
            
            alert(i18n.t('Error creating assessment tools: {{error}}', { error: errorMessage }) + 
                  '\n\n' + i18n.t('Details: {{details}}', { details: errorDetails }))
        }
    }

    return (
        <Box>
            {/* DHIS2 Configuration Section */}
            <Box marginBottom="24px">
                <Card>
                    <Box padding="16px">
                        <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                            <h3 style={{ margin: 0 }}>{i18n.t('DHIS2 Configuration')}</h3>
                            <Button 
                                secondary 
                                small
                                onClick={onEditConfiguration}
                            >
                                {i18n.t('Edit Configuration')}
                            </Button>
                        </Box>
                        
                        {dhis2Config?.configured ? (
                            <Box>
                                <Box display="flex" alignItems="center" gap="8px" marginBottom="12px">
                                    <Tag color="green">✓ {i18n.t('Connected')}</Tag>
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {i18n.t('Connected as: {{username}}', { username: dhis2Config.username || 'Unknown' })}
                                    </span>
                                </Box>
                                
                                <Box display="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', fontSize: '14px' }}>
                                    <Box>
                                        <strong>{i18n.t('Server URL:')}</strong><br/>
                                        <span style={{ color: '#666', wordBreak: 'break-all' }}>
                                            {dhis2Config.baseUrl || 'Not specified'}
                                        </span>
                                    </Box>
                                    <Box>
                                        <strong>{i18n.t('System:')}</strong><br/>
                                        <span style={{ color: '#666' }}>
                                            {dhis2Config.systemInfo ? 
                                                i18n.t('{{name}} ({{version}})', { 
                                                    name: dhis2Config.systemInfo.systemName || 'DHIS2',
                                                    version: dhis2Config.systemInfo.version || 'Unknown'
                                                }) : 
                                                'System info not available'
                                            }
                                        </span>
                                    </Box>
                                </Box>
                            </Box>
                        ) : (
                            <Box>
                                <Box display="flex" alignItems="center" gap="8px" marginBottom="12px">
                                    <Tag color="orange">⚠ {i18n.t('Not Configured')}</Tag>
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {i18n.t('DHIS2 connection required for data fetching')}
                                    </span>
                                </Box>
                                <NoticeBox warning>
                                    {i18n.t('Please configure your DHIS2 connection in step 1 to enable data fetching for assessments.')}
                                </NoticeBox>
                            </Box>
                        )}
                    </Box>
                </Card>
            </Box>

            {/* Progress Modal */}
            {creationProgress.show && (
                <Modal onClose={() => {}}>
                    <ModalTitle>{i18n.t('Creating Assessment Tools')}</ModalTitle>
                    <ModalContent>
                        <Box display="flex" flexDirection="column" gap="16px" alignItems="center">
                            <CircularLoader />
                            <Box textAlign="center">
                                <h4>{i18n.t('Creating {{current}} of {{total}}', { 
                                    current: creationProgress.current, 
                                    total: creationProgress.total 
                                })}</h4>
                                <p>{creationProgress.currentTool}</p>
                            </Box>
                            <Box display="flex" gap="8px">
                                {assessmentTools.map(tool => (
                                    <Tag 
                                        key={tool.id}
                                        color={creationProgress.completed.includes(tool.id) ? 'green' : 'grey'}
                                    >
                                        {tool.icon} {creationProgress.completed.includes(tool.id) ? '✓' : '⏳'}
                                    </Tag>
                                ))}
                            </Box>
                        </Box>
                    </ModalContent>
                </Modal>
            )}

            {/* Loading State */}
            {(loadingOrgUnits || loadingDataElements || loadingCategoryCombos) && (
                <Box marginBottom="16px">
                    <AlertBar>
                        {i18n.t('Loading local DHIS2 metadata...')}
                    </AlertBar>
                </Box>
            )}

            {/* Debug Information */}
            {process.env.NODE_ENV === 'development' && (
                <Box marginBottom="16px" padding="12px" style={{ backgroundColor: '#f5f5f5', borderRadius: '4px', fontSize: '12px' }}>
                    <strong>Debug Info:</strong><br/>
                    <strong>Local Org Units:</strong><br/>
                    - Nested Array: {Array.isArray(localOrgUnits?.organisationUnits?.organisationUnits) ? 'Yes' : 'No'}<br/>
                    - Direct Array: {Array.isArray(localOrgUnits?.organisationUnits) ? 'Yes' : 'No'}<br/>
                    - Nested Length: {Array.isArray(localOrgUnits?.organisationUnits?.organisationUnits) ? localOrgUnits.organisationUnits.organisationUnits.length : 'N/A'}<br/>
                    - Direct Length: {Array.isArray(localOrgUnits?.organisationUnits) ? localOrgUnits.organisationUnits.length : 'N/A'}<br/>
                    <br/>
                    <strong>Local Data Elements:</strong><br/>
                    - Nested Array: {Array.isArray(localDataElements?.dataElements?.dataElements) ? 'Yes' : 'No'}<br/>
                    - Direct Array: {Array.isArray(localDataElements?.dataElements) ? 'Yes' : 'No'}<br/>
                    - Nested Length: {Array.isArray(localDataElements?.dataElements?.dataElements) ? localDataElements.dataElements.dataElements.length : 'N/A'}<br/>
                    - Direct Length: {Array.isArray(localDataElements?.dataElements) ? localDataElements.dataElements.length : 'N/A'}<br/>
                    <br/>
                    <strong>Category Combos:</strong><br/>
                    - Nested Array: {Array.isArray(categoryCombos?.categoryCombos?.categoryCombos) ? 'Yes' : 'No'}<br/>
                    - Direct Array: {Array.isArray(categoryCombos?.categoryCombos) ? 'Yes' : 'No'}<br/>
                    - Nested Length: {Array.isArray(categoryCombos?.categoryCombos?.categoryCombos) ? categoryCombos.categoryCombos.categoryCombos.length : 'N/A'}<br/>
                    - Direct Length: {Array.isArray(categoryCombos?.categoryCombos) ? categoryCombos.categoryCombos.length : 'N/A'}<br/>
                    - Default Category Combo: {(() => {
                        try {
                            return getDefaultCategoryComboId()
                        } catch (error) {
                            return `Error: ${error.message}`
                        }
                    })()}
                </Box>
            )}

            {/* Selected Dataset Context */}
            {selectedDataSet && selectedDataElements && selectedOrgUnits ? (
                <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#e8f5e8', borderRadius: '4px' }}>
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                        <Box>
                            <h4 style={{ margin: '0 0 8px 0', color: '#2e7d32' }}>
                                {i18n.t('Ready to create assessment tools for: {{name}}', { name: selectedDataSet.displayName })}
                            </h4>
                            <Box display="flex" gap="8px" alignItems="center" marginBottom="8px">
                                <Tag color="green">{selectedDataSet.periodType}</Tag>
                                <span style={{ color: '#666', fontSize: '14px' }}>
                                    {selectedDataElements.length} {i18n.t('data elements selected')}
                                </span>
                                <span style={{ color: '#666', fontSize: '14px' }}>•</span>
                                <span style={{ color: '#666', fontSize: '14px' }}>
                                    {selectedOrgUnits.length} {i18n.t('organisation units selected')}
                                </span>
                            </Box>
                            <Box display="flex" gap="4px" flexWrap="wrap">
                                {selectedDataElements.slice(0, 3).map(de => (
                                    <Tag key={de.id} color="blue" small>{de.displayName}</Tag>
                                ))}
                                {selectedDataElements.length > 3 && (
                                    <Tag color="grey" small>+{selectedDataElements.length - 3} more</Tag>
                                )}
                            </Box>
                        </Box>
                        <Button 
                            primary 
                            onClick={handleCreateAssessmentTools}
                            disabled={creatingDataSet || creatingDataElement || loadingOrgUnits || loadingDataElements || loadingCategoryCombos}
                        >
                            {(creatingDataSet || creatingDataElement) ? i18n.t('Creating...') : i18n.t('Create 4 Assessment Tools')}
                        </Button>
                    </Box>
                </Box>
            ) : (
                <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#fff3cd', borderRadius: '4px' }}>
                    <NoticeBox warning title={i18n.t('Prerequisites Required')}>
                        {i18n.t('Please complete the previous steps:')}
                        <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                            <li>{selectedDataSet ? '✓' : '○'} {i18n.t('Select a dataset')}</li>
                            <li>{selectedDataElements?.length > 0 ? '✓' : '○'} {i18n.t('Select data elements')}</li>
                            <li>{selectedOrgUnits?.length > 0 ? '✓' : '○'} {i18n.t('Select organisation units')}</li>
                        </ul>
                    </NoticeBox>
                </Box>
            )}

            {/* Assessment Tools Overview */}
            <Box marginBottom="24px">
                <h3>{i18n.t('Assessment Data Collection Tools')}</h3>
                <p style={{ color: '#666', marginBottom: '16px' }}>
                    {i18n.t('Four datasets will be created automatically for comprehensive data quality assessment:')}
                </p>
                
                <Box display="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
                    {assessmentTools.map(tool => (
                        <Card key={tool.id}>
                            <Box padding="16px">
                                <Box display="flex" alignItems="center" gap="8px" marginBottom="8px">
                                    <span style={{ fontSize: '24px' }}>{tool.icon}</span>
                                    <h4 style={{ margin: 0 }}>{tool.name}</h4>
                                </Box>
                                <p style={{ color: '#666', fontSize: '14px', margin: '0 0 12px 0' }}>
                                    {tool.description}
                                </p>
                                <Box display="flex" justifyContent="space-between" alignItems="center">
                                    <Tag color={tool.color}>{tool.suffix}</Tag>
                                    {tool.id === 'dhis2' && (
                                        <Tag color={dhis2Config?.configured ? "green" : "orange"} small>
                                            {dhis2Config?.configured ? i18n.t('Configured') : i18n.t('Config Required')}
                                        </Tag>
                                    )}
                                </Box>
                            </Box>
                        </Card>
                    ))}
                </Box>
            </Box>


        </Box>
    )
}