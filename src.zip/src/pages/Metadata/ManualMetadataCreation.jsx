import React, { useState, useEffect } from 'react'
import {
    Box,
    Button,
    ButtonStrip,
    Card,
    InputField,
    TextAreaField,
    SingleSelect,
    SingleSelectOption,
    MultiSelect,
    MultiSelectOption,
    Tag,
    NoticeBox,
    CircularLoader,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    TabBar,
    Tab,
    Divider,
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    IconAdd16,
    IconEdit16,
    IconDelete16
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

// Manual metadata creation component
const ManualMetadataCreation = ({ onMetadataCreated, onClose }) => {
    const [activeTab, setActiveTab] = useState('strategy')
    const [dataSeparationStrategy, setDataSeparationStrategy] = useState(null) // 'aoc' or 'separate_elements'
    const [datasets, setDatasets] = useState([])
    const [dataElements, setDataElements] = useState([])
    const [orgUnits, setOrgUnits] = useState([])
    const [categories, setCategories] = useState([])
    const [categoryOptions, setCategoryOptions] = useState([])
    const [categoryCombos, setCategoryCombos] = useState([])
    const [showDatasetModal, setShowDatasetModal] = useState(false)
    const [showDataElementModal, setShowDataElementModal] = useState(false)
    const [showOrgUnitModal, setShowOrgUnitModal] = useState(false)
    const [showCategoryModal, setShowCategoryModal] = useState(false)
    const [showNamingConventionModal, setShowNamingConventionModal] = useState(false)
    const [editingItem, setEditingItem] = useState(null)
    const [namingConventions, setNamingConventions] = useState({
        register: { prefix: '', suffix: ' - Register', pattern: '{name}{suffix}' },
        summary: { prefix: '', suffix: ' - Summary', pattern: '{name}{suffix}' },
        reported: { prefix: '', suffix: ' - Reported', pattern: '{name}{suffix}' },
        corrected: { prefix: '', suffix: ' - Corrected', pattern: '{name}{suffix}' }
    })

    // Generate a simple UID (for demo purposes - in production, you might want a more robust solution)
    const generateUID = () => {
        return Math.random().toString(36).substr(2, 11).padEnd(11, '0')
    }

    // Initialize DQA-specific categories when AOC strategy is selected
    useEffect(() => {
        if (dataSeparationStrategy === 'aoc') {
            initializeDQACategories()
        } else if (dataSeparationStrategy === 'separate_elements') {
            // Initialize common disaggregation categories for separate elements approach
            initializeDisaggregationCategories()
        }
    }, [dataSeparationStrategy])

    const initializeDQACategories = () => {
        // Create DQA Data Source category options
        const dqaSourceOptions = [
            { id: generateUID(), name: 'Register', code: 'REGISTER', displayName: 'Register Data' },
            { id: generateUID(), name: 'Summary', code: 'SUMMARY', displayName: 'Summary Data' },
            { id: generateUID(), name: 'Reported', code: 'REPORTED', displayName: 'Reported Data' },
            { id: generateUID(), name: 'Corrected', code: 'CORRECTED', displayName: 'Corrected Data' }
        ]

        // Create DQA Data Source ATTRIBUTE category (for dataset attributes)
        const dqaSourceCategory = {
            id: generateUID(),
            name: 'DQA Data Source',
            code: 'DQA_DATA_SOURCE',
            displayName: 'DQA Data Source',
            dataDimension: true,
            dataDimensionType: 'ATTRIBUTE', // This makes it an attribute category
            categoryOptions: dqaSourceOptions
        }

        // Create ATTRIBUTE category combination (for datasets)
        const dqaAttributeCombo = {
            id: generateUID(),
            name: 'DQA Data Source',
            code: 'DQA_DATA_SOURCE_ATTR_COMBO',
            displayName: 'DQA Data Source',
            dataDimensionType: 'ATTRIBUTE',
            categories: [dqaSourceCategory],
            categoryOptionCombos: dqaSourceOptions.map(option => ({
                id: generateUID(),
                name: option.name,
                code: `${option.code}_AOC`,
                displayName: option.displayName,
                categoryOptions: [option]
            }))
        }

        setCategoryOptions(dqaSourceOptions)
        setCategories([dqaSourceCategory])
        setCategoryCombos([dqaAttributeCombo])
    }

    const initializeDisaggregationCategories = () => {
        // Create common disaggregation categories for data elements
        
        // Age category
        const ageOptions = [
            { id: generateUID(), name: '<5 years', code: 'AGE_LT5', displayName: 'Under 5 years' },
            { id: generateUID(), name: '5-14 years', code: 'AGE_5_14', displayName: '5-14 years' },
            { id: generateUID(), name: '15-49 years', code: 'AGE_15_49', displayName: '15-49 years' },
            { id: generateUID(), name: '50+ years', code: 'AGE_50_PLUS', displayName: '50+ years' }
        ]

        const ageCategory = {
            id: generateUID(),
            name: 'Age',
            code: 'AGE',
            displayName: 'Age',
            dataDimension: true,
            dataDimensionType: 'DISAGGREGATION',
            categoryOptions: ageOptions
        }

        // Gender category
        const genderOptions = [
            { id: generateUID(), name: 'Male', code: 'MALE', displayName: 'Male' },
            { id: generateUID(), name: 'Female', code: 'FEMALE', displayName: 'Female' }
        ]

        const genderCategory = {
            id: generateUID(),
            name: 'Gender',
            code: 'GENDER',
            displayName: 'Gender',
            dataDimension: true,
            dataDimensionType: 'DISAGGREGATION',
            categoryOptions: genderOptions
        }

        // Create category combinations
        const ageCombo = {
            id: generateUID(),
            name: 'Age',
            code: 'AGE_COMBO',
            displayName: 'Age',
            dataDimensionType: 'DISAGGREGATION',
            categories: [ageCategory],
            categoryOptionCombos: ageOptions.map(option => ({
                id: generateUID(),
                name: option.name,
                code: option.code,
                displayName: option.displayName,
                categoryOptions: [option]
            }))
        }

        const genderCombo = {
            id: generateUID(),
            name: 'Gender',
            code: 'GENDER_COMBO',
            displayName: 'Gender',
            dataDimensionType: 'DISAGGREGATION',
            categories: [genderCategory],
            categoryOptionCombos: genderOptions.map(option => ({
                id: generateUID(),
                name: option.name,
                code: option.code,
                displayName: option.displayName,
                categoryOptions: [option]
            }))
        }

        // Age x Gender combination
        const ageGenderCombo = {
            id: generateUID(),
            name: 'Age and Gender',
            code: 'AGE_GENDER_COMBO',
            displayName: 'Age and Gender',
            dataDimensionType: 'DISAGGREGATION',
            categories: [ageCategory, genderCategory],
            categoryOptionCombos: []
        }

        // Generate all combinations of age x gender
        ageOptions.forEach(ageOption => {
            genderOptions.forEach(genderOption => {
                ageGenderCombo.categoryOptionCombos.push({
                    id: generateUID(),
                    name: `${ageOption.name}, ${genderOption.name}`,
                    code: `${ageOption.code}_${genderOption.code}`,
                    displayName: `${ageOption.displayName}, ${genderOption.displayName}`,
                    categoryOptions: [ageOption, genderOption]
                })
            })
        })

        setCategoryOptions([...ageOptions, ...genderOptions])
        setCategories([ageCategory, genderCategory])
        setCategoryCombos([ageCombo, genderCombo, ageGenderCombo])
    }

    const handleFinish = () => {
        const metadata = {
            dataSeparationStrategy,
            namingConventions: dataSeparationStrategy === 'separate_elements' ? namingConventions : null,
            datasets,
            dataElements,
            orgUnits,
            categories,
            categoryOptions,
            categoryCombos
        }
        onMetadataCreated(metadata)
    }

    return (
        <Box>
            <Box marginBottom="24px">
                <h2 style={{ margin: 0, fontSize: '24px', fontWeight: '500', color: '#212934' }}>
                    {i18n.t('Manual Metadata Creation')}
                </h2>
                <Box marginTop="8px" fontSize="14px" color="#6c757d">
                    {i18n.t('Create datasets, data elements, and organization units manually without connecting to DHIS2')}
                </Box>
            </Box>

            <TabBar>
                <Tab selected={activeTab === 'strategy'} onClick={() => setActiveTab('strategy')}>
                    {i18n.t('Data Separation Strategy')}
                </Tab>
                {dataSeparationStrategy && (
                    <>
                        {dataSeparationStrategy === 'separate_elements' && (
                            <Tab selected={activeTab === 'naming'} onClick={() => setActiveTab('naming')}>
                                {i18n.t('Naming Conventions')}
                            </Tab>
                        )}
                        <Tab selected={activeTab === 'datasets'} onClick={() => setActiveTab('datasets')}>
                            {i18n.t('Datasets')} ({datasets.length})
                        </Tab>
                        <Tab selected={activeTab === 'dataElements'} onClick={() => setActiveTab('dataElements')}>
                            {i18n.t('Data Elements')} ({dataElements.length})
                        </Tab>
                        <Tab selected={activeTab === 'orgUnits'} onClick={() => setActiveTab('orgUnits')}>
                            {i18n.t('Organization Units')} ({orgUnits.length})
                        </Tab>
                        {dataSeparationStrategy === 'aoc' && (
                            <Tab selected={activeTab === 'categories'} onClick={() => setActiveTab('categories')}>
                                {i18n.t('Categories')} ({categories.length})
                            </Tab>
                        )}
                        {dataSeparationStrategy === 'separate_elements' && (
                            <Tab selected={activeTab === 'categories'} onClick={() => setActiveTab('categories')}>
                                {i18n.t('Disaggregations')} ({categories.length})
                            </Tab>
                        )}
                    </>
                )}
            </TabBar>

            <Box marginTop="24px">
                {activeTab === 'strategy' && (
                    <DataSeparationStrategySelection 
                        selectedStrategy={dataSeparationStrategy}
                        onStrategySelect={(strategy) => {
                            setDataSeparationStrategy(strategy)
                            setActiveTab('datasets')
                        }}
                    />
                )}
                
                {activeTab === 'naming' && (
                    <NamingConventionsManagement 
                        conventions={namingConventions}
                        onChange={setNamingConventions}
                    />
                )}
                
                {activeTab === 'datasets' && (
                    <DatasetManagement 
                        datasets={datasets}
                        setDatasets={setDatasets}
                        dataElements={dataElements}
                        orgUnits={orgUnits}
                        onShowModal={() => setShowDatasetModal(true)}
                        onEdit={(item) => {
                            setEditingItem(item)
                            setShowDatasetModal(true)
                        }}
                        generateUID={generateUID}
                    />
                )}
                
                {activeTab === 'dataElements' && (
                    <DataElementManagement 
                        dataElements={dataElements}
                        setDataElements={setDataElements}
                        onShowModal={() => setShowDataElementModal(true)}
                        onEdit={(item) => {
                            setEditingItem(item)
                            setShowDataElementModal(true)
                        }}
                        generateUID={generateUID}
                        strategy={dataSeparationStrategy}
                        namingConventions={namingConventions}
                    />
                )}
                
                {activeTab === 'orgUnits' && (
                    <OrgUnitManagement 
                        orgUnits={orgUnits}
                        setOrgUnits={setOrgUnits}
                        onShowModal={() => setShowOrgUnitModal(true)}
                        onEdit={(item) => {
                            setEditingItem(item)
                            setShowOrgUnitModal(true)
                        }}
                        generateUID={generateUID}
                    />
                )}
                
                {activeTab === 'categories' && (
                    <CategoryManagement 
                        categories={categories}
                        categoryOptions={categoryOptions}
                        categoryCombos={categoryCombos}
                        strategy={dataSeparationStrategy}
                    />
                )}
            </Box>

            <Box marginTop="32px">
                <ButtonStrip>
                    <Button primary onClick={handleFinish} disabled={!dataSeparationStrategy || datasets.length === 0 || dataElements.length === 0 || orgUnits.length === 0}>
                        {i18n.t('Use This Metadata')}
                    </Button>
                    <Button onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                </ButtonStrip>
            </Box>

            {/* Modals */}
            {showDatasetModal && (
                <DatasetModal
                    dataset={editingItem}
                    dataElements={dataElements}
                    orgUnits={orgUnits}
                    categoryCombos={categoryCombos}
                    onSave={(dataset) => {
                        if (editingItem) {
                            setDatasets(prev => prev.map(d => d.id === editingItem.id ? dataset : d))
                        } else {
                            setDatasets(prev => [...prev, { ...dataset, id: generateUID() }])
                        }
                        setShowDatasetModal(false)
                        setEditingItem(null)
                    }}
                    onClose={() => {
                        setShowDatasetModal(false)
                        setEditingItem(null)
                    }}
                />
            )}

            {showDataElementModal && (
                <DataElementModal
                    dataElement={editingItem}
                    categoryCombos={categoryCombos}
                    onSave={(dataElement) => {
                        if (editingItem) {
                            setDataElements(prev => prev.map(de => de.id === editingItem.id ? dataElement : de))
                        } else {
                            setDataElements(prev => [...prev, { ...dataElement, id: generateUID() }])
                        }
                        setShowDataElementModal(false)
                        setEditingItem(null)
                    }}
                    onClose={() => {
                        setShowDataElementModal(false)
                        setEditingItem(null)
                    }}
                />
            )}

            {showOrgUnitModal && (
                <OrgUnitModal
                    orgUnit={editingItem}
                    orgUnits={orgUnits}
                    onSave={(orgUnit) => {
                        if (editingItem) {
                            setOrgUnits(prev => prev.map(ou => ou.id === editingItem.id ? orgUnit : ou))
                        } else {
                            setOrgUnits(prev => [...prev, { ...orgUnit, id: generateUID() }])
                        }
                        setShowOrgUnitModal(false)
                        setEditingItem(null)
                    }}
                    onClose={() => {
                        setShowOrgUnitModal(false)
                        setEditingItem(null)
                    }}
                />
            )}
        </Box>
    )
}

// Dataset Management Component
const DatasetManagement = ({ datasets, setDatasets, dataElements, orgUnits, onShowModal, onEdit, generateUID }) => {
    const handleDelete = (id) => {
        setDatasets(prev => prev.filter(d => d.id !== id))
    }

    return (
        <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                <h3 style={{ margin: 0 }}>{i18n.t('Datasets')}</h3>
                <Button small icon={<IconAdd16 />} onClick={onShowModal}>
                    {i18n.t('Add Dataset')}
                </Button>
            </Box>

            {datasets.length === 0 ? (
                <NoticeBox title={i18n.t('No datasets created')}>
                    {i18n.t('Click "Add Dataset" to create your first dataset')}
                </NoticeBox>
            ) : (
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Period Type')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Data Elements')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Org Units')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {datasets.map(dataset => (
                            <DataTableRow key={dataset.id}>
                                <DataTableCell>{dataset.name}</DataTableCell>
                                <DataTableCell>{dataset.code}</DataTableCell>
                                <DataTableCell>{dataset.periodType}</DataTableCell>
                                <DataTableCell>{dataset.dataElements?.length || 0}</DataTableCell>
                                <DataTableCell>{dataset.orgUnits?.length || 0}</DataTableCell>
                                <DataTableCell>
                                    <ButtonStrip>
                                        <Button small icon={<IconEdit16 />} onClick={() => onEdit(dataset)}>
                                            {i18n.t('Edit')}
                                        </Button>
                                        <Button small destructive icon={<IconDelete16 />} onClick={() => handleDelete(dataset.id)}>
                                            {i18n.t('Delete')}
                                        </Button>
                                    </ButtonStrip>
                                </DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            )}
        </Box>
    )
}

// Data Element Management Component
const DataElementManagement = ({ dataElements, setDataElements, onShowModal, onEdit, generateUID, strategy, namingConventions }) => {
    const [showBulkCreateModal, setShowBulkCreateModal] = useState(false)
    
    const handleDelete = (id) => {
        setDataElements(prev => prev.filter(de => de.id !== id))
    }

    const generateDataElementsFromConventions = (baseElements) => {
        if (strategy !== 'separate_elements' || !namingConventions) return baseElements
        
        const generatedElements = []
        const dataSources = ['register', 'summary', 'reported', 'corrected']
        
        baseElements.forEach(baseElement => {
            dataSources.forEach(source => {
                const convention = namingConventions[source]
                let elementName = convention.pattern || '{name}{suffix}'
                
                elementName = elementName.replace('{name}', baseElement.name)
                elementName = elementName.replace('{prefix}', convention.prefix || '')
                elementName = elementName.replace('{suffix}', convention.suffix || '')
                elementName = elementName.replace('{source}', convention.source || source)
                
                const generatedElement = {
                    ...baseElement,
                    id: generateUID(),
                    name: elementName,
                    shortName: elementName.length > 50 ? elementName.substring(0, 47) + '...' : elementName,
                    code: `${baseElement.code || baseElement.name.replace(/\s+/g, '_').toUpperCase()}_${source.toUpperCase()}`,
                    dataSource: source
                }
                
                generatedElements.push(generatedElement)
            })
        })
        
        return generatedElements
    }

    return (
        <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                <h3 style={{ margin: 0 }}>{i18n.t('Data Elements')}</h3>
                <ButtonStrip>
                    {strategy === 'separate_elements' && (
                        <Button secondary onClick={() => setShowBulkCreateModal(true)}>
                            {i18n.t('Bulk Create from Base Elements')}
                        </Button>
                    )}
                    <Button small icon={<IconAdd16 />} onClick={onShowModal}>
                        {i18n.t('Add Data Element')}
                    </Button>
                </ButtonStrip>
            </Box>

            {dataElements.length === 0 ? (
                <NoticeBox title={i18n.t('No data elements created')}>
                    {i18n.t('Click "Add Data Element" to create your first data element')}
                </NoticeBox>
            ) : (
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Value Type')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Domain Type')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {dataElements.map(dataElement => (
                            <DataTableRow key={dataElement.id}>
                                <DataTableCell>{dataElement.name}</DataTableCell>
                                <DataTableCell>{dataElement.code}</DataTableCell>
                                <DataTableCell>{dataElement.valueType}</DataTableCell>
                                <DataTableCell>{dataElement.domainType}</DataTableCell>
                                <DataTableCell>
                                    <ButtonStrip>
                                        <Button small icon={<IconEdit16 />} onClick={() => onEdit(dataElement)}>
                                            {i18n.t('Edit')}
                                        </Button>
                                        <Button small destructive icon={<IconDelete16 />} onClick={() => handleDelete(dataElement.id)}>
                                            {i18n.t('Delete')}
                                        </Button>
                                    </ButtonStrip>
                                </DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            )}

            {/* Bulk Create Modal */}
            {showBulkCreateModal && (
                <BulkCreateDataElementsModal
                    onClose={() => setShowBulkCreateModal(false)}
                    onGenerate={(baseElements) => {
                        const generatedElements = generateDataElementsFromConventions(baseElements)
                        setDataElements(prev => [...prev, ...generatedElements])
                        setShowBulkCreateModal(false)
                    }}
                    namingConventions={namingConventions}
                    generateUID={generateUID}
                />
            )}
        </Box>
    )
}

// Organization Unit Management Component
const OrgUnitManagement = ({ orgUnits, setOrgUnits, onShowModal, onEdit, generateUID }) => {
    const handleDelete = (id) => {
        setOrgUnits(prev => prev.filter(ou => ou.id !== id))
    }

    return (
        <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                <h3 style={{ margin: 0 }}>{i18n.t('Organization Units')}</h3>
                <Button small icon={<IconAdd16 />} onClick={onShowModal}>
                    {i18n.t('Add Organization Unit')}
                </Button>
            </Box>

            {orgUnits.length === 0 ? (
                <NoticeBox title={i18n.t('No organization units created')}>
                    {i18n.t('Click "Add Organization Unit" to create your first organization unit')}
                </NoticeBox>
            ) : (
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Level')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Parent')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {orgUnits.map(orgUnit => (
                            <DataTableRow key={orgUnit.id}>
                                <DataTableCell>{orgUnit.name}</DataTableCell>
                                <DataTableCell>{orgUnit.code}</DataTableCell>
                                <DataTableCell>{orgUnit.level}</DataTableCell>
                                <DataTableCell>
                                    {orgUnit.parent ? 
                                        orgUnits.find(ou => ou.id === orgUnit.parent)?.name || i18n.t('Unknown') 
                                        : i18n.t('Root')
                                    }
                                </DataTableCell>
                                <DataTableCell>
                                    <ButtonStrip>
                                        <Button small icon={<IconEdit16 />} onClick={() => onEdit(orgUnit)}>
                                            {i18n.t('Edit')}
                                        </Button>
                                        <Button small destructive icon={<IconDelete16 />} onClick={() => handleDelete(orgUnit.id)}>
                                            {i18n.t('Delete')}
                                        </Button>
                                    </ButtonStrip>
                                </DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            )}
        </Box>
    )
}

// Dataset Modal Component
const DatasetModal = ({ dataset, dataElements, orgUnits, categoryCombos, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: dataset?.name || '',
        shortName: dataset?.shortName || '',
        code: dataset?.code || '',
        description: dataset?.description || '',
        periodType: dataset?.periodType || 'Monthly',
        categoryCombo: dataset?.categoryCombo || (categoryCombos?.[0]?.id || null),
        dataElements: dataset?.dataElements || [],
        orgUnits: dataset?.orgUnits || []
    })

    const periodTypes = [
        'Daily', 'Weekly', 'Monthly', 'BiMonthly', 'Quarterly', 
        'SixMonthly', 'Yearly', 'FinancialApril', 'FinancialJuly', 'FinancialOct'
    ]

    const handleSave = () => {
        if (!formData.name || !formData.code) {
            alert(i18n.t('Name and Code are required'))
            return
        }
        onSave(formData)
    }

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>{dataset ? i18n.t('Edit Dataset') : i18n.t('Add Dataset')}</ModalTitle>
            <ModalContent>
                <Box display="flex" flexDirection="column" gap="16px">
                    <InputField
                        label={i18n.t('Name')}
                        value={formData.name}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, name: value }))}
                        required
                    />
                    <InputField
                        label={i18n.t('Short Name')}
                        value={formData.shortName}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, shortName: value }))}
                    />
                    <InputField
                        label={i18n.t('Code')}
                        value={formData.code}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, code: value }))}
                        required
                    />
                    <TextAreaField
                        label={i18n.t('Description')}
                        value={formData.description}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, description: value }))}
                    />
                    <SingleSelect
                        label={i18n.t('Period Type')}
                        selected={formData.periodType}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, periodType: selected }))}
                    >
                        {periodTypes.map(type => (
                            <SingleSelectOption key={type} label={type} value={type} />
                        ))}
                    </SingleSelect>
                    <SingleSelect
                        label={i18n.t('Attribute Category Combination')}
                        selected={formData.categoryCombo}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, categoryCombo: selected }))}
                    >
                        {categoryCombos?.map(combo => (
                            <SingleSelectOption key={combo.id} label={`${combo.name} (Attribute)`} value={combo.id} />
                        ))}
                    </SingleSelect>
                    <Box marginTop="8px" fontSize="12px" color="#666">
                        {i18n.t('💡 This dataset will use Attribute Option Combos (AOCs) to separate data by source: Register, Summary, Reported, Corrected')}
                    </Box>
                    <Box>
                        <MultiSelect
                            label={i18n.t('Data Elements')}
                            selected={formData.dataElements.map(de => de.id)}
                            onChange={({ selected }) => {
                                const selectedElements = dataElements.filter(de => selected.includes(de.id))
                                setFormData(prev => ({ ...prev, dataElements: selectedElements }))
                            }}
                        >
                            {dataElements.map(de => (
                                <MultiSelectOption key={de.id} label={de.name} value={de.id} />
                            ))}
                        </MultiSelect>
                        <Box marginTop="8px" fontSize="12px" color="#666">
                            {i18n.t('💡 Tip: Data elements can be reused across multiple datasets. Data values are distinguished by period and organization unit.')}
                        </Box>
                    </Box>
                    <MultiSelect
                        label={i18n.t('Organization Units')}
                        selected={formData.orgUnits.map(ou => ou.id)}
                        onChange={({ selected }) => {
                            const selectedOrgUnits = orgUnits.filter(ou => selected.includes(ou.id))
                            setFormData(prev => ({ ...prev, orgUnits: selectedOrgUnits }))
                        }}
                    >
                        {orgUnits.map(ou => (
                            <MultiSelectOption key={ou.id} label={ou.name} value={ou.id} />
                        ))}
                    </MultiSelect>
                </Box>
            </ModalContent>
            <ModalActions>
                <ButtonStrip>
                    <Button primary onClick={handleSave}>
                        {i18n.t('Save')}
                    </Button>
                    <Button onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

// Data Element Modal Component
const DataElementModal = ({ dataElement, categoryCombos, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: dataElement?.name || '',
        shortName: dataElement?.shortName || '',
        code: dataElement?.code || '',
        description: dataElement?.description || '',
        valueType: dataElement?.valueType || 'INTEGER',
        domainType: dataElement?.domainType || 'AGGREGATE',
        aggregationType: dataElement?.aggregationType || 'SUM',
        categoryCombo: dataElement?.categoryCombo || null // For disaggregations
    })

    const valueTypes = [
        'TEXT', 'LONG_TEXT', 'LETTER', 'PHONE_NUMBER', 'EMAIL', 'BOOLEAN', 
        'TRUE_ONLY', 'DATE', 'DATETIME', 'TIME', 'NUMBER', 'UNIT_INTERVAL', 
        'PERCENTAGE', 'INTEGER', 'INTEGER_POSITIVE', 'INTEGER_NEGATIVE', 
        'INTEGER_ZERO_OR_POSITIVE', 'TRACKER_ASSOCIATE', 'USERNAME', 'COORDINATE', 
        'ORGANISATION_UNIT', 'AGE', 'URL', 'FILE_RESOURCE', 'IMAGE'
    ]

    const domainTypes = ['AGGREGATE', 'TRACKER']
    const aggregationTypes = ['SUM', 'AVERAGE', 'AVERAGE_SUM_ORG_UNIT', 'COUNT', 'STDDEV', 'VARIANCE', 'MIN', 'MAX', 'NONE']

    const handleSave = () => {
        if (!formData.name || !formData.code) {
            alert(i18n.t('Name and Code are required'))
            return
        }
        onSave(formData)
    }

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>{dataElement ? i18n.t('Edit Data Element') : i18n.t('Add Data Element')}</ModalTitle>
            <ModalContent>
                <Box display="flex" flexDirection="column" gap="16px">
                    <InputField
                        label={i18n.t('Name')}
                        value={formData.name}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, name: value }))}
                        required
                    />
                    <InputField
                        label={i18n.t('Short Name')}
                        value={formData.shortName}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, shortName: value }))}
                    />
                    <InputField
                        label={i18n.t('Code')}
                        value={formData.code}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, code: value }))}
                        required
                    />
                    <TextAreaField
                        label={i18n.t('Description')}
                        value={formData.description}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, description: value }))}
                    />
                    <SingleSelect
                        label={i18n.t('Value Type')}
                        selected={formData.valueType}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, valueType: selected }))}
                    >
                        {valueTypes.map(type => (
                            <SingleSelectOption key={type} label={type} value={type} />
                        ))}
                    </SingleSelect>
                    <SingleSelect
                        label={i18n.t('Domain Type')}
                        selected={formData.domainType}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, domainType: selected }))}
                    >
                        {domainTypes.map(type => (
                            <SingleSelectOption key={type} label={type} value={type} />
                        ))}
                    </SingleSelect>
                    <SingleSelect
                        label={i18n.t('Aggregation Type')}
                        selected={formData.aggregationType}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, aggregationType: selected }))}
                    >
                        {aggregationTypes.map(type => (
                            <SingleSelectOption key={type} label={type} value={type} />
                        ))}
                    </SingleSelect>
                    
                    {/* Category Combination for Disaggregations */}
                    <SingleSelect
                        label={i18n.t('Category Combination (Disaggregations)')}
                        selected={formData.categoryCombo}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, categoryCombo: selected }))}
                        clearable
                        clearText={i18n.t('No disaggregations (default)')}
                    >
                        {categoryCombos?.filter(combo => combo.dataDimensionType !== 'ATTRIBUTE').map(combo => (
                            <SingleSelectOption key={combo.id} label={combo.name} value={combo.id} />
                        ))}
                    </SingleSelect>
                    <Box marginTop="8px" fontSize="12px" color="#666">
                        {i18n.t('💡 Select a category combination to add disaggregations (e.g., Age, Gender) to this data element')}
                    </Box>
                </Box>
            </ModalContent>
            <ModalActions>
                <ButtonStrip>
                    <Button primary onClick={handleSave}>
                        {i18n.t('Save')}
                    </Button>
                    <Button onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

// Organization Unit Modal Component
const OrgUnitModal = ({ orgUnit, orgUnits, onSave, onClose }) => {
    const [formData, setFormData] = useState({
        name: orgUnit?.name || '',
        shortName: orgUnit?.shortName || '',
        code: orgUnit?.code || '',
        description: orgUnit?.description || '',
        level: orgUnit?.level || 1,
        parent: orgUnit?.parent || null
    })

    const handleSave = () => {
        if (!formData.name || !formData.code) {
            alert(i18n.t('Name and Code are required'))
            return
        }
        onSave(formData)
    }

    // Filter out current org unit from parent options to prevent circular references
    const availableParents = orgUnits.filter(ou => ou.id !== orgUnit?.id)

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>{orgUnit ? i18n.t('Edit Organization Unit') : i18n.t('Add Organization Unit')}</ModalTitle>
            <ModalContent>
                <Box display="flex" flexDirection="column" gap="16px">
                    <InputField
                        label={i18n.t('Name')}
                        value={formData.name}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, name: value }))}
                        required
                    />
                    <InputField
                        label={i18n.t('Short Name')}
                        value={formData.shortName}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, shortName: value }))}
                    />
                    <InputField
                        label={i18n.t('Code')}
                        value={formData.code}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, code: value }))}
                        required
                    />
                    <TextAreaField
                        label={i18n.t('Description')}
                        value={formData.description}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, description: value }))}
                    />
                    <InputField
                        label={i18n.t('Level')}
                        type="number"
                        value={formData.level.toString()}
                        onChange={({ value }) => setFormData(prev => ({ ...prev, level: parseInt(value) || 1 }))}
                        min="1"
                        max="10"
                    />
                    <SingleSelect
                        label={i18n.t('Parent Organization Unit')}
                        selected={formData.parent}
                        onChange={({ selected }) => setFormData(prev => ({ ...prev, parent: selected }))}
                        clearable
                        clearText={i18n.t('No parent (Root level)')}
                    >
                        {availableParents.map(ou => (
                            <SingleSelectOption key={ou.id} label={ou.name} value={ou.id} />
                        ))}
                    </SingleSelect>
                </Box>
            </ModalContent>
            <ModalActions>
                <ButtonStrip>
                    <Button primary onClick={handleSave}>
                        {i18n.t('Save')}
                    </Button>
                    <Button onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

// Category Management Component
const CategoryManagement = ({ categories, categoryOptions, categoryCombos, strategy }) => {
    const isAOCStrategy = strategy === 'aoc'
    
    return (
        <Box>
            <Box marginBottom="24px">
                <h3 style={{ margin: 0 }}>
                    {isAOCStrategy ? i18n.t('DQA Attribute Categories') : i18n.t('Disaggregation Categories')}
                </h3>
                <Box marginTop="8px" fontSize="14px" color="#666">
                    {isAOCStrategy 
                        ? i18n.t('Attribute categories automatically created to separate data from different sources (Register, Summary, Reported, Corrected)')
                        : i18n.t('Common disaggregation categories available for data elements (Age, Gender, etc.)')
                    }
                </Box>
            </Box>

            {/* Category Options */}
            <Box marginBottom="24px">
                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>{i18n.t('Category Options')}</h4>
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Display Name')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {categoryOptions.map(option => (
                            <DataTableRow key={option.id}>
                                <DataTableCell>{option.name}</DataTableCell>
                                <DataTableCell>{option.code}</DataTableCell>
                                <DataTableCell>{option.displayName}</DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            </Box>

            {/* Categories */}
            <Box marginBottom="24px">
                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>{i18n.t('Categories')}</h4>
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Options')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {categories.map(category => (
                            <DataTableRow key={category.id}>
                                <DataTableCell>{category.name}</DataTableCell>
                                <DataTableCell>{category.code}</DataTableCell>
                                <DataTableCell>{category.categoryOptions?.length || 0}</DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            </Box>

            {/* Category Combinations */}
            <Box marginBottom="24px">
                <h4 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>{i18n.t('Category Combinations')}</h4>
                <DataTable>
                    <DataTableHead>
                        <DataTableRow>
                            <DataTableColumnHeader>{i18n.t('Name')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Code')}</DataTableColumnHeader>
                            <DataTableColumnHeader>{i18n.t('Option Combos')}</DataTableColumnHeader>
                        </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                        {categoryCombos.map(combo => (
                            <DataTableRow key={combo.id}>
                                <DataTableCell>{combo.name}</DataTableCell>
                                <DataTableCell>{combo.code}</DataTableCell>
                                <DataTableCell>{combo.categoryOptionCombos?.length || 0}</DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                </DataTable>
            </Box>

            <NoticeBox title={isAOCStrategy ? i18n.t('How Attribute Option Combos (AOCs) Solve Data Separation') : i18n.t('How Disaggregation Categories Work')}>
                <Box fontSize="14px" lineHeight="1.5">
                    {isAOCStrategy ? (
                        <>
                            <p><strong>{i18n.t('Correct Approach: ONE Dataset with Attribute Option Combos')}</strong></p>
                            <p>{i18n.t('Instead of creating 4 separate datasets, we create ONE dataset with attribute categories:')}</p>
                            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                                <li><strong>{i18n.t('Single Dataset')}</strong>: {i18n.t('Contains all data elements')}</li>
                                <li><strong>{i18n.t('Attribute Categories')}</strong>: {i18n.t('Separate data by source (Register, Summary, Reported, Corrected)')}</li>
                                <li><strong>{i18n.t('Data Entry')}</strong>: {i18n.t('Users select the data source when entering data')}</li>
                                <li><strong>{i18n.t('Data Storage')}</strong>: {i18n.t('Each value has unique: Data Element + Period + Org Unit + AOC')}</li>
                            </ul>
                            <Box marginTop="12px" padding="12px" backgroundColor="#e8f4fd" borderRadius="4px">
                                <p><strong>{i18n.t('Example Data Entry:')}</strong></p>
                                <p>{i18n.t('Facility A, January 2024, "Patients Treated":')}</p>
                                <ul style={{ margin: '4px 0', paddingLeft: '20px' }}>
                                    <li>{i18n.t('Register AOC: 150 patients')}</li>
                                    <li>{i18n.t('Summary AOC: 145 patients')}</li>
                                    <li>{i18n.t('Reported AOC: 140 patients')}</li>
                                    <li>{i18n.t('Corrected AOC: 148 patients')}</li>
                                </ul>
                            </Box>
                        </>
                    ) : (
                        <>
                            <p><strong>{i18n.t('Disaggregation Categories for Data Elements')}</strong></p>
                            <p>{i18n.t('These categories can be assigned to data elements to break down data by different dimensions:')}</p>
                            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                                <li><strong>{i18n.t('Age Categories')}</strong>: {i18n.t('Break down data by age groups')}</li>
                                <li><strong>{i18n.t('Gender Categories')}</strong>: {i18n.t('Separate data by Male/Female')}</li>
                                <li><strong>{i18n.t('Combined Categories')}</strong>: {i18n.t('Age and Gender together for detailed analysis')}</li>
                                <li><strong>{i18n.t('Flexible Assignment')}</strong>: {i18n.t('Each data element can have different disaggregations')}</li>
                            </ul>
                            <Box marginTop="12px" padding="12px" backgroundColor="#fff3cd" borderRadius="4px">
                                <p><strong>{i18n.t('Example Usage:')}</strong></p>
                                <p>{i18n.t('Data Element: "Patients Treated - Register" with Age disaggregation:')}</p>
                                <ul style={{ margin: '4px 0', paddingLeft: '20px' }}>
                                    <li>{i18n.t('<5 years: 25 patients')}</li>
                                    <li>{i18n.t('5-14 years: 30 patients')}</li>
                                    <li>{i18n.t('15-49 years: 70 patients')}</li>
                                    <li>{i18n.t('50+ years: 25 patients')}</li>
                                </ul>
                            </Box>
                        </>
                    )}
                </Box>
            </NoticeBox>
        </Box>
    )
}

// Data Separation Strategy Selection Component
const DataSeparationStrategySelection = ({ selectedStrategy, onStrategySelect }) => {
    return (
        <Box>
            <Box marginBottom="24px">
                <h3 style={{ margin: 0 }}>{i18n.t('Choose Data Separation Strategy')}</h3>
                <Box marginTop="8px" fontSize="14px" color="#666">
                    {i18n.t('Select how you want to separate data from different sources (Register, Summary, Reported, Corrected)')}
                </Box>
            </Box>

            <Box display="flex" flexDirection="column" gap="24px">
                {/* AOC Strategy */}
                <Card 
                    style={{ 
                        padding: '24px', 
                        border: selectedStrategy === 'aoc' ? '2px solid #0d7377' : '1px solid #e0e0e0',
                        backgroundColor: selectedStrategy === 'aoc' ? '#f0f8ff' : 'white',
                        cursor: 'pointer'
                    }}
                    onClick={() => onStrategySelect('aoc')}
                >
                    <Box display="flex" alignItems="flex-start" gap="16px">
                        <input
                            type="radio"
                            name="strategy"
                            value="aoc"
                            checked={selectedStrategy === 'aoc'}
                            onChange={() => onStrategySelect('aoc')}
                            style={{ marginTop: '4px' }}
                        />
                        <Box flex="1">
                            <Box fontSize="18px" fontWeight="500" marginBottom="8px" color="#212934">
                                {i18n.t('Attribute Option Combos (AOCs)')} 
                                <Tag positive style={{ marginLeft: '8px' }}>{i18n.t('Recommended')}</Tag>
                            </Box>
                            <Box fontSize="14px" color="#666" marginBottom="12px">
                                {i18n.t('Use ONE dataset with attribute categories to separate data sources')}
                            </Box>
                            
                            <Box marginBottom="16px">
                                <Box fontSize="14px" fontWeight="500" marginBottom="8px">{i18n.t('✅ Advantages:')}</Box>
                                <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '14px', color: '#666' }}>
                                    <li>{i18n.t('Single dataset - easier to manage')}</li>
                                    <li>{i18n.t('Same data elements reused across sources')}</li>
                                    <li>{i18n.t('DHIS2 best practice approach')}</li>
                                    <li>{i18n.t('Better analytics and reporting')}</li>
                                    <li>{i18n.t('Supports disaggregations within data elements')}</li>
                                </ul>
                            </Box>
                            
                            <Box backgroundColor="#e8f4fd" padding="12px" borderRadius="4px">
                                <Box fontSize="13px" fontWeight="500" marginBottom="4px">{i18n.t('Example:')}</Box>
                                <Box fontSize="13px" color="#666">
                                    {i18n.t('Dataset: "DQA Assessment" → Data Element: "Patients Treated" → Sources: Register (150), Summary (145), Reported (140), Corrected (148)')}
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Card>

                {/* Separate Elements Strategy */}
                <Card 
                    style={{ 
                        padding: '24px', 
                        border: selectedStrategy === 'separate_elements' ? '2px solid #0d7377' : '1px solid #e0e0e0',
                        backgroundColor: selectedStrategy === 'separate_elements' ? '#f0f8ff' : 'white',
                        cursor: 'pointer'
                    }}
                    onClick={() => onStrategySelect('separate_elements')}
                >
                    <Box display="flex" alignItems="flex-start" gap="16px">
                        <input
                            type="radio"
                            name="strategy"
                            value="separate_elements"
                            checked={selectedStrategy === 'separate_elements'}
                            onChange={() => onStrategySelect('separate_elements')}
                            style={{ marginTop: '4px' }}
                        />
                        <Box flex="1">
                            <Box fontSize="18px" fontWeight="500" marginBottom="8px" color="#212934">
                                {i18n.t('Separate Data Elements')}
                            </Box>
                            <Box fontSize="14px" color="#666" marginBottom="12px">
                                {i18n.t('Create different data elements for each data source')}
                            </Box>
                            
                            <Box marginBottom="16px">
                                <Box fontSize="14px" fontWeight="500" marginBottom="8px">{i18n.t('✅ Advantages:')}</Box>
                                <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '14px', color: '#666' }}>
                                    <li>{i18n.t('Simple and straightforward approach')}</li>
                                    <li>{i18n.t('Each data element can have different properties')}</li>
                                    <li>{i18n.t('Can use multiple datasets if needed')}</li>
                                    <li>{i18n.t('Full control over each data element')}</li>
                                    <li>{i18n.t('Supports different disaggregations per source')}</li>
                                </ul>
                            </Box>

                            <Box marginBottom="16px">
                                <Box fontSize="14px" fontWeight="500" marginBottom="8px">{i18n.t('⚠️ Considerations:')}</Box>
                                <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '14px', color: '#666' }}>
                                    <li>{i18n.t('More data elements to manage (4x more)')}</li>
                                    <li>{i18n.t('Requires careful naming conventions')}</li>
                                    <li>{i18n.t('Analytics queries more complex')}</li>
                                </ul>
                            </Box>
                            
                            <Box backgroundColor="#fff3cd" padding="12px" borderRadius="4px">
                                <Box fontSize="13px" fontWeight="500" marginBottom="4px">{i18n.t('Example:')}</Box>
                                <Box fontSize="13px" color="#666">
                                    {i18n.t('Data Elements: "Patients Treated - Register", "Patients Treated - Summary", "Patients Treated - Reported", "Patients Treated - Corrected"')}
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Card>
            </Box>

            {selectedStrategy && (
                <Box marginTop="24px" textAlign="center">
                    <Button primary onClick={() => onStrategySelect(selectedStrategy)}>
                        {i18n.t('Continue with {{strategy}}', { 
                            strategy: selectedStrategy === 'aoc' ? 'AOCs' : 'Separate Elements' 
                        })}
                    </Button>
                </Box>
            )}
        </Box>
    )
}

// Naming Conventions Management Component
const NamingConventionsManagement = ({ conventions, onChange }) => {
    const [previewName, setPreviewName] = useState('Patients Treated')
    
    const dataSources = [
        { key: 'register', label: 'Register Data', color: '#0d7377' },
        { key: 'summary', label: 'Summary Data', color: '#14a085' },
        { key: 'reported', label: 'Reported Data', color: '#f39c12' },
        { key: 'corrected', label: 'Corrected Data', color: '#e74c3c' }
    ]

    const presetPatterns = [
        { name: 'Suffix (Default)', pattern: '{name}{suffix}', example: 'Patients Treated - Register' },
        { name: 'Prefix', pattern: '{prefix}{name}', example: 'REG - Patients Treated' },
        { name: 'Prefix + Suffix', pattern: '{prefix}{name}{suffix}', example: 'REG - Patients Treated - Data' },
        { name: 'Parentheses', pattern: '{name} ({source})', example: 'Patients Treated (Register)' },
        { name: 'Brackets', pattern: '{name} [{source}]', example: 'Patients Treated [Register]' },
        { name: 'Underscore', pattern: '{name}_{source}', example: 'Patients_Treated_Register' },
        { name: 'Dot Notation', pattern: '{name}.{source}', example: 'Patients.Treated.Register' },
        { name: 'Custom', pattern: '', example: 'Define your own pattern' }
    ]

    const applyPreset = (sourceKey, preset) => {
        const newConventions = { ...conventions }
        newConventions[sourceKey].pattern = preset.pattern
        
        // Set default prefix/suffix based on pattern
        if (preset.pattern.includes('{prefix}') && !newConventions[sourceKey].prefix) {
            const sourceLabels = { register: 'REG', summary: 'SUM', reported: 'REP', corrected: 'COR' }
            newConventions[sourceKey].prefix = sourceLabels[sourceKey] + ' - '
        }
        if (preset.pattern.includes('{suffix}') && !newConventions[sourceKey].suffix) {
            const sourceLabels = { register: 'Register', summary: 'Summary', reported: 'Reported', corrected: 'Corrected' }
            newConventions[sourceKey].suffix = ' - ' + sourceLabels[sourceKey]
        }
        if (preset.pattern.includes('{source}')) {
            const sourceLabels = { register: 'Register', summary: 'Summary', reported: 'Reported', corrected: 'Corrected' }
            newConventions[sourceKey].source = sourceLabels[sourceKey]
        }
        
        onChange(newConventions)
    }

    const updateConvention = (sourceKey, field, value) => {
        const newConventions = { ...conventions }
        newConventions[sourceKey][field] = value
        onChange(newConventions)
    }

    const generatePreview = (sourceKey) => {
        const conv = conventions[sourceKey]
        let preview = conv.pattern || '{name}{suffix}'
        
        preview = preview.replace('{name}', previewName)
        preview = preview.replace('{prefix}', conv.prefix || '')
        preview = preview.replace('{suffix}', conv.suffix || '')
        preview = preview.replace('{source}', conv.source || sourceKey)
        
        return preview
    }

    return (
        <Box>
            <Box marginBottom="24px">
                <h3 style={{ margin: 0 }}>{i18n.t('Data Element Naming Conventions')}</h3>
                <Box marginTop="8px" fontSize="14px" color="#666">
                    {i18n.t('Configure how data elements will be named for each data source. Use prefixes, suffixes, or custom patterns.')}
                </Box>
            </Box>

            {/* Preview Section */}
            <Box marginBottom="32px" padding="20px" backgroundColor="#f8f9fa" borderRadius="8px">
                <Box marginBottom="16px">
                    <h4 style={{ margin: '0 0 8px 0', fontSize: '16px' }}>{i18n.t('Live Preview')}</h4>
                    <input
                        type="text"
                        placeholder={i18n.t('Enter base data element name')}
                        value={previewName}
                        onChange={e => setPreviewName(e.target.value)}
                        style={{ 
                            width: '300px', 
                            padding: '8px 12px', 
                            borderRadius: '4px', 
                            border: '1px solid #ccc', 
                            fontSize: '14px' 
                        }}
                    />
                </Box>
                
                <Box display="grid" gridTemplateColumns="repeat(auto-fit, minmax(250px, 1fr))" gap="12px">
                    {dataSources.map(source => (
                        <Box key={source.key} padding="12px" backgroundColor="white" borderRadius="4px" border="1px solid #e0e0e0">
                            <Box display="flex" alignItems="center" marginBottom="8px">
                                <Box 
                                    width="12px" 
                                    height="12px" 
                                    borderRadius="50%" 
                                    backgroundColor={source.color}
                                    marginRight="8px"
                                />
                                <Box fontSize="14px" fontWeight="500">{source.label}</Box>
                            </Box>
                            <Box 
                                fontSize="13px" 
                                fontFamily="monospace" 
                                padding="8px" 
                                backgroundColor="#f5f5f5" 
                                borderRadius="3px"
                                border="1px solid #ddd"
                            >
                                {generatePreview(source.key)}
                            </Box>
                        </Box>
                    ))}
                </Box>
            </Box>

            {/* Configuration for each data source */}
            {dataSources.map(source => (
                <Card key={source.key} style={{ marginBottom: '24px' }}>
                    <Box padding="24px">
                        <Box display="flex" alignItems="center" marginBottom="20px">
                            <Box 
                                width="16px" 
                                height="16px" 
                                borderRadius="50%" 
                                backgroundColor={source.color}
                                marginRight="12px"
                            />
                            <h4 style={{ margin: 0, fontSize: '18px' }}>{source.label}</h4>
                        </Box>

                        {/* Preset Patterns */}
                        <Box marginBottom="20px">
                            <Box marginBottom="12px" fontSize="14px" fontWeight="500">{i18n.t('Quick Patterns:')}</Box>
                            <Box display="flex" flexWrap="wrap" gap="8px">
                                {presetPatterns.map(preset => (
                                    <Button
                                        key={preset.name}
                                        small
                                        secondary={conventions[source.key].pattern !== preset.pattern}
                                        primary={conventions[source.key].pattern === preset.pattern}
                                        onClick={() => applyPreset(source.key, preset)}
                                        title={preset.example}
                                    >
                                        {preset.name}
                                    </Button>
                                ))}
                            </Box>
                        </Box>

                        {/* Custom Configuration */}
                        <Box display="grid" gridTemplateColumns="1fr 1fr 2fr" gap="16px" alignItems="end">
                            <Box>
                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: '500' }}>
                                    {i18n.t('Prefix')}
                                </label>
                                <input
                                    type="text"
                                    placeholder={i18n.t('e.g., REG -')}
                                    value={conventions[source.key].prefix || ''}
                                    onChange={e => updateConvention(source.key, 'prefix', e.target.value)}
                                    style={{ 
                                        width: '100%', 
                                        padding: '8px 12px', 
                                        borderRadius: '4px', 
                                        border: '1px solid #ccc', 
                                        fontSize: '14px' 
                                    }}
                                />
                            </Box>
                            
                            <Box>
                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: '500' }}>
                                    {i18n.t('Suffix')}
                                </label>
                                <input
                                    type="text"
                                    placeholder={i18n.t('e.g., - Register')}
                                    value={conventions[source.key].suffix || ''}
                                    onChange={e => updateConvention(source.key, 'suffix', e.target.value)}
                                    style={{ 
                                        width: '100%', 
                                        padding: '8px 12px', 
                                        borderRadius: '4px', 
                                        border: '1px solid #ccc', 
                                        fontSize: '14px' 
                                    }}
                                />
                            </Box>
                            
                            <Box>
                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: '500' }}>
                                    {i18n.t('Custom Pattern')}
                                </label>
                                <input
                                    type="text"
                                    placeholder={i18n.t('e.g., {prefix}{name}{suffix}')}
                                    value={conventions[source.key].pattern || ''}
                                    onChange={e => updateConvention(source.key, 'pattern', e.target.value)}
                                    style={{ 
                                        width: '100%', 
                                        padding: '8px 12px', 
                                        borderRadius: '4px', 
                                        border: '1px solid #ccc', 
                                        fontSize: '14px',
                                        fontFamily: 'monospace'
                                    }}
                                />
                                <Box marginTop="4px" fontSize="12px" color="#666">
                                    {i18n.t('Available variables: {name}, {prefix}, {suffix}, {source}')}
                                </Box>
                            </Box>
                        </Box>

                        {/* Source Variable */}
                        {conventions[source.key].pattern?.includes('{source}') && (
                            <Box marginTop="16px">
                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: '500' }}>
                                    {i18n.t('Source Name')}
                                </label>
                                <input
                                    type="text"
                                    placeholder={i18n.t('e.g., Register')}
                                    value={conventions[source.key].source || source.key}
                                    onChange={e => updateConvention(source.key, 'source', e.target.value)}
                                    style={{ 
                                        width: '200px', 
                                        padding: '8px 12px', 
                                        borderRadius: '4px', 
                                        border: '1px solid #ccc', 
                                        fontSize: '14px' 
                                    }}
                                />
                            </Box>
                        )}

                        {/* Current Preview */}
                        <Box marginTop="16px" padding="12px" backgroundColor="#f8f9fa" borderRadius="4px">
                            <Box fontSize="12px" color="#666" marginBottom="4px">{i18n.t('Result:')}</Box>
                            <Box fontSize="14px" fontFamily="monospace" fontWeight="500">
                                {generatePreview(source.key)}
                            </Box>
                        </Box>
                    </Box>
                </Card>
            ))}

            {/* Help Section */}
            <NoticeBox title={i18n.t('Naming Convention Tips')}>
                <Box fontSize="14px" lineHeight="1.5">
                    <p><strong>{i18n.t('Available Variables:')}</strong></p>
                    <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                        <li><code>{'{name}'}</code> - {i18n.t('The base data element name')}</li>
                        <li><code>{'{prefix}'}</code> - {i18n.t('Text to add before the name')}</li>
                        <li><code>{'{suffix}'}</code> - {i18n.t('Text to add after the name')}</li>
                        <li><code>{'{source}'}</code> - {i18n.t('The data source name (Register, Summary, etc.)')}</li>
                    </ul>
                    
                    <p><strong>{i18n.t('Pattern Examples:')}</strong></p>
                    <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                        <li><code>{'{name}{suffix}'}</code> → {i18n.t('Patients Treated - Register')}</li>
                        <li><code>{'{prefix}{name}'}</code> → {i18n.t('REG - Patients Treated')}</li>
                        <li><code>{'{name} ({source})'}</code> → {i18n.t('Patients Treated (Register)')}</li>
                        <li><code>{'{name}_{source}'}</code> → {i18n.t('Patients_Treated_Register')}</li>
                    </ul>

                    <Box marginTop="12px" padding="12px" backgroundColor="#e8f4fd" borderRadius="4px">
                        <p><strong>{i18n.t('💡 Best Practices:')}</strong></p>
                        <ul style={{ margin: '4px 0', paddingLeft: '20px' }}>
                            <li>{i18n.t('Keep names descriptive but not too long')}</li>
                            <li>{i18n.t('Use consistent patterns across all data sources')}</li>
                            <li>{i18n.t('Avoid special characters that might cause issues')}</li>
                            <li>{i18n.t('Test with different data element names to ensure clarity')}</li>
                        </ul>
                    </Box>
                </Box>
            </NoticeBox>
        </Box>
    )
}

// Bulk Create Data Elements Modal
const BulkCreateDataElementsModal = ({ onClose, onGenerate, namingConventions, generateUID }) => {
    const [baseElements, setBaseElements] = useState([
        { name: 'Patients Treated', valueType: 'INTEGER', aggregationType: 'SUM' },
        { name: 'Beds Occupied', valueType: 'INTEGER', aggregationType: 'AVERAGE' },
        { name: 'Staff Count', valueType: 'INTEGER', aggregationType: 'SUM' }
    ])
    const [newElementName, setNewElementName] = useState('')

    const addBaseElement = () => {
        if (newElementName.trim()) {
            setBaseElements(prev => [...prev, {
                name: newElementName.trim(),
                valueType: 'INTEGER',
                aggregationType: 'SUM'
            }])
            setNewElementName('')
        }
    }

    const removeBaseElement = (index) => {
        setBaseElements(prev => prev.filter((_, i) => i !== index))
    }

    const updateBaseElement = (index, field, value) => {
        setBaseElements(prev => prev.map((element, i) => 
            i === index ? { ...element, [field]: value } : element
        ))
    }

    const generatePreview = (baseName) => {
        const dataSources = ['register', 'summary', 'reported', 'corrected']
        return dataSources.map(source => {
            const convention = namingConventions[source]
            let elementName = convention.pattern || '{name}{suffix}'
            
            elementName = elementName.replace('{name}', baseName)
            elementName = elementName.replace('{prefix}', convention.prefix || '')
            elementName = elementName.replace('{suffix}', convention.suffix || '')
            elementName = elementName.replace('{source}', convention.source || source)
            
            return { source, name: elementName }
        })
    }

    const handleGenerate = () => {
        const elementsToGenerate = baseElements.map(element => ({
            ...element,
            id: generateUID(),
            code: element.name.replace(/\s+/g, '_').toUpperCase(),
            shortName: element.name.length > 50 ? element.name.substring(0, 47) + '...' : element.name,
            description: `Base element: ${element.name}`,
            domainType: 'AGGREGATE'
        }))
        
        onGenerate(elementsToGenerate)
    }

    return (
        <Modal large onClose={onClose}>
            <ModalTitle>{i18n.t('Bulk Create Data Elements')}</ModalTitle>
            <ModalContent>
                <Box marginBottom="24px">
                    <Box fontSize="14px" color="#666" marginBottom="16px">
                        {i18n.t('Define base data elements that will be automatically created for each data source using your naming conventions.')}
                    </Box>
                </Box>

                {/* Add New Base Element */}
                <Box marginBottom="24px" padding="16px" backgroundColor="#f8f9fa" borderRadius="4px">
                    <Box marginBottom="12px" fontSize="14px" fontWeight="500">{i18n.t('Add Base Data Element:')}</Box>
                    <Box display="flex" gap="12px" alignItems="end">
                        <Box flex="1">
                            <input
                                type="text"
                                placeholder={i18n.t('Enter data element name')}
                                value={newElementName}
                                onChange={e => setNewElementName(e.target.value)}
                                onKeyPress={e => e.key === 'Enter' && addBaseElement()}
                                style={{ 
                                    width: '100%', 
                                    padding: '8px 12px', 
                                    borderRadius: '4px', 
                                    border: '1px solid #ccc', 
                                    fontSize: '14px' 
                                }}
                            />
                        </Box>
                        <Button onClick={addBaseElement} disabled={!newElementName.trim()}>
                            {i18n.t('Add')}
                        </Button>
                    </Box>
                </Box>

                {/* Base Elements List */}
                <Box marginBottom="24px">
                    <h4 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>{i18n.t('Base Data Elements')}</h4>
                    
                    {baseElements.length === 0 ? (
                        <NoticeBox title={i18n.t('No base elements defined')}>
                            {i18n.t('Add at least one base data element to generate variants for each data source.')}
                        </NoticeBox>
                    ) : (
                        <Box>
                            {baseElements.map((element, index) => (
                                <Card key={index} style={{ marginBottom: '16px' }}>
                                    <Box padding="16px">
                                        <Box display="flex" justifyContent="space-between" alignItems="flex-start" marginBottom="12px">
                                            <Box flex="1" marginRight="16px">
                                                <input
                                                    type="text"
                                                    value={element.name}
                                                    onChange={e => updateBaseElement(index, 'name', e.target.value)}
                                                    style={{ 
                                                        width: '100%', 
                                                        padding: '8px 12px', 
                                                        borderRadius: '4px', 
                                                        border: '1px solid #ccc', 
                                                        fontSize: '14px',
                                                        fontWeight: '500'
                                                    }}
                                                />
                                            </Box>
                                            <Button small destructive onClick={() => removeBaseElement(index)}>
                                                {i18n.t('Remove')}
                                            </Button>
                                        </Box>

                                        <Box display="flex" gap="16px" marginBottom="16px">
                                            <Box>
                                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '12px', fontWeight: '500' }}>
                                                    {i18n.t('Value Type')}
                                                </label>
                                                <select
                                                    value={element.valueType}
                                                    onChange={e => updateBaseElement(index, 'valueType', e.target.value)}
                                                    style={{ 
                                                        padding: '6px 8px', 
                                                        borderRadius: '4px', 
                                                        border: '1px solid #ccc', 
                                                        fontSize: '12px' 
                                                    }}
                                                >
                                                    <option value="INTEGER">INTEGER</option>
                                                    <option value="NUMBER">NUMBER</option>
                                                    <option value="TEXT">TEXT</option>
                                                    <option value="BOOLEAN">BOOLEAN</option>
                                                </select>
                                            </Box>
                                            <Box>
                                                <label style={{ display: 'block', marginBottom: '4px', fontSize: '12px', fontWeight: '500' }}>
                                                    {i18n.t('Aggregation')}
                                                </label>
                                                <select
                                                    value={element.aggregationType}
                                                    onChange={e => updateBaseElement(index, 'aggregationType', e.target.value)}
                                                    style={{ 
                                                        padding: '6px 8px', 
                                                        borderRadius: '4px', 
                                                        border: '1px solid #ccc', 
                                                        fontSize: '12px' 
                                                    }}
                                                >
                                                    <option value="SUM">SUM</option>
                                                    <option value="AVERAGE">AVERAGE</option>
                                                    <option value="COUNT">COUNT</option>
                                                    <option value="NONE">NONE</option>
                                                </select>
                                            </Box>
                                        </Box>

                                        {/* Preview Generated Names */}
                                        <Box>
                                            <Box fontSize="12px" fontWeight="500" marginBottom="8px" color="#666">
                                                {i18n.t('Will generate:')}
                                            </Box>
                                            <Box display="grid" gridTemplateColumns="repeat(auto-fit, minmax(200px, 1fr))" gap="8px">
                                                {generatePreview(element.name).map(preview => (
                                                    <Box 
                                                        key={preview.source}
                                                        fontSize="11px" 
                                                        fontFamily="monospace" 
                                                        padding="6px 8px" 
                                                        backgroundColor="#f5f5f5" 
                                                        borderRadius="3px"
                                                        border="1px solid #ddd"
                                                    >
                                                        {preview.name}
                                                    </Box>
                                                ))}
                                            </Box>
                                        </Box>
                                    </Box>
                                </Card>
                            ))}
                        </Box>
                    )}
                </Box>

                {/* Summary */}
                {baseElements.length > 0 && (
                    <Box padding="16px" backgroundColor="#e8f4fd" borderRadius="4px">
                        <Box fontSize="14px" fontWeight="500" marginBottom="4px">
                            {i18n.t('Generation Summary:')}
                        </Box>
                        <Box fontSize="13px" color="#666">
                            {i18n.t('{{baseCount}} base elements × 4 data sources = {{totalCount}} data elements will be created', {
                                baseCount: baseElements.length,
                                totalCount: baseElements.length * 4
                            })}
                        </Box>
                    </Box>
                )}
            </ModalContent>
            <ModalActions>
                <ButtonStrip>
                    <Button primary onClick={handleGenerate} disabled={baseElements.length === 0}>
                        {i18n.t('Generate {{count}} Data Elements', { count: baseElements.length * 4 })}
                    </Button>
                    <Button onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                </ButtonStrip>
            </ModalActions>
        </Modal>
    )
}

export default ManualMetadataCreation