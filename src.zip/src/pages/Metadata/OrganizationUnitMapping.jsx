import React, { useState, useEffect } from 'react'
import {
    Box,
    Button,
    ButtonStrip,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    CircularLoader,
    NoticeBox,
    SingleSelect,
    SingleSelectOption,
    Tag,
    InputField,
    Pagination
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { useDataEngine } from '@dhis2/app-runtime'

const orgUnitsQuery = {
    organisationUnits: {
        resource: 'organisationUnits',
        params: {
            fields: 'id,displayName,level,path,parent[id,displayName,parent[id,displayName]]',
            paging: false
        }
    }
}

export const OrganizationUnitMapping = ({ 
    dhis2Config, 
    selectedOrgUnits = [], 
    value = [], 
    onChange, 
    onNext 
}) => {
    const engine = useDataEngine()
    const [localOrgUnits, setLocalOrgUnits] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    const [mappings, setMappings] = useState({})
    const [autoMappingResults, setAutoMappingResults] = useState(null)
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage] = useState(25)

    // Initialize mappings from existing value prop
    useEffect(() => {
        if (Array.isArray(value) && value.length > 0) {
            const existingMappings = {}
            value.forEach(mapping => {
                if (mapping.external?.id && mapping.local?.id) {
                    existingMappings[mapping.external.id] = mapping.local.id
                }
            })
            setMappings(existingMappings)
        }
    }, [value])

    // Fetch local DHIS2 organization units
    useEffect(() => {
        const fetchLocalOrgUnits = async () => {
            setLoading(true)
            setError(null)
            try {
                const result = await engine.query(orgUnitsQuery)
                setLocalOrgUnits(result.organisationUnits.organisationUnits || [])
                
                // Only perform auto-mapping if we don't have existing mappings
                if (Object.keys(mappings).length === 0) {
                    performAutoMapping(selectedOrgUnits, result.organisationUnits.organisationUnits || [])
                }
            } catch (err) {
                console.error('Error fetching local org units:', err)
                setError(err.message)
            } finally {
                setLoading(false)
            }
        }

        fetchLocalOrgUnits()
    }, [engine, selectedOrgUnits])

    // Auto-mapping logic
    const performAutoMapping = (externalOrgUnits, localOrgUnits) => {
        if (!Array.isArray(externalOrgUnits) || !Array.isArray(localOrgUnits)) {
            console.warn('Invalid data for auto-mapping:', { externalOrgUnits, localOrgUnits })
            return
        }

        const autoMapped = {}
        const results = {
            exactMatches: 0,
            partialMatches: 0,
            noMatches: 0
        }

        externalOrgUnits.forEach(extOrgUnit => {
            // Safety checks
            if (!extOrgUnit || !extOrgUnit.id || !extOrgUnit.displayName) {
                console.warn('Invalid external org unit:', extOrgUnit)
                results.noMatches++
                return
            }

            // Try exact name match first
            const exactMatch = localOrgUnits.find(localOrgUnit => 
                localOrgUnit && localOrgUnit.displayName &&
                localOrgUnit.displayName.toLowerCase() === extOrgUnit.displayName.toLowerCase()
            )

            if (exactMatch) {
                autoMapped[extOrgUnit.id] = exactMatch.id
                results.exactMatches++
                return
            }

            // Try partial name match
            const partialMatch = localOrgUnits.find(localOrgUnit => 
                localOrgUnit && localOrgUnit.displayName &&
                (localOrgUnit.displayName.toLowerCase().includes(extOrgUnit.displayName.toLowerCase()) ||
                extOrgUnit.displayName.toLowerCase().includes(localOrgUnit.displayName.toLowerCase()))
            )

            if (partialMatch) {
                autoMapped[extOrgUnit.id] = partialMatch.id
                results.partialMatches++
                return
            }

            results.noMatches++
        })

        setMappings(autoMapped)
        setAutoMappingResults(results)
    }

    const handleMappingChange = (externalOrgUnitId, localOrgUnitId) => {
        setMappings(prev => ({
            ...prev,
            [externalOrgUnitId]: localOrgUnitId
        }))
    }

    const handleClearMapping = (externalOrgUnitId) => {
        setMappings(prev => {
            const newMappings = { ...prev }
            delete newMappings[externalOrgUnitId]
            return newMappings
        })
    }

    const handleSaveAndContinue = () => {
        // Prepare mapping data for next step
        const mappingData = selectedOrgUnits.map(extOrgUnit => {
            const localOrgUnitId = mappings[extOrgUnit.id]
            const localOrgUnit = localOrgUnits.find(ou => ou.id === localOrgUnitId)
            
            return {
                external: extOrgUnit,
                local: localOrgUnit || null,
                mapped: !!localOrgUnit
            }
        })

        onChange && onChange(mappingData)
        onNext && onNext()
    }

    const getMappingStatus = () => {
        const totalMappings = selectedOrgUnits.length
        const completedMappings = Object.keys(mappings).length
        return { totalMappings, completedMappings }
    }

    const getLocalOrgUnitOptions = (currentMappedId = null) => {
        // Filter out already mapped org units to prevent duplicate mappings
        // but include the currently selected option for this row
        const mappedIds = Object.values(mappings)
        return localOrgUnits.filter(ou => 
            !mappedIds.includes(ou.id) || ou.id === currentMappedId
        )
    }

    if (loading) {
        return (
            <Box>
                <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Loading local organization units...')}</h3>
                </Box>
                <Box display="flex" justifyContent="center" alignItems="center" height="300px">
                    <CircularLoader />
                </Box>
            </Box>
        )
    }

    if (error) {
        return (
            <Box>
                <NoticeBox error title={i18n.t('Error loading organization units')}>
                    {error}
                </NoticeBox>
            </Box>
        )
    }

    const { totalMappings, completedMappings } = getMappingStatus()

    return (
        <Box>
            {/* Header */}
            <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Organization Unit Mapping')}</h3>
                <Box display="flex" gap="8px" alignItems="center" marginBottom="8px">
                    <span style={{ color: '#666', fontSize: '14px' }}>
                        {i18n.t('Map external organization units to local DHIS2 organization units')}
                    </span>
                </Box>
                
                {/* Auto-mapping results */}
                {autoMappingResults && (
                    <Box marginTop="16px">
                        <Box display="flex" gap="8px" alignItems="center" flexWrap="wrap">
                            <Tag color="green">{i18n.t('{{count}} exact matches', { count: autoMappingResults.exactMatches })}</Tag>
                            <Tag color="orange">{i18n.t('{{count}} partial matches', { count: autoMappingResults.partialMatches })}</Tag>
                            <Tag color="red">{i18n.t('{{count}} no matches', { count: autoMappingResults.noMatches })}</Tag>
                        </Box>
                    </Box>
                )}
            </Box>

            {/* Progress */}
            <Box marginBottom="16px">
                <NoticeBox title={i18n.t('Mapping Progress')}>
                    {i18n.t('{{completed}} of {{total}} organization units mapped', { 
                        completed: completedMappings, 
                        total: totalMappings 
                    })}
                </NoticeBox>
            </Box>

            {/* Mapping Table */}
            <DataTable>
                <DataTableHead>
                    <DataTableRow>
                        <DataTableColumnHeader>
                            {i18n.t('External Organization Unit')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Level')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Map to Local Organization Unit')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Status')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Actions')}
                        </DataTableColumnHeader>
                    </DataTableRow>
                </DataTableHead>
                <DataTableBody>
                    {(() => {
                        // Pagination calculations
                        const totalItems = selectedOrgUnits.length
                        const totalPages = Math.ceil(totalItems / itemsPerPage)
                        const startIndex = (currentPage - 1) * itemsPerPage
                        const endIndex = startIndex + itemsPerPage
                        const paginatedOrgUnits = selectedOrgUnits.slice(startIndex, endIndex)
                        
                        return paginatedOrgUnits.map(extOrgUnit => {
                        const mappedLocalId = mappings[extOrgUnit.id]
                        const mappedLocal = localOrgUnits.find(ou => ou.id === mappedLocalId)
                        const isMapped = !!mappedLocal
                        
                        return (
                            <DataTableRow 
                                key={extOrgUnit.id}
                                style={{ 
                                    backgroundColor: isMapped ? '#f3e5f5' : 'transparent',
                                    borderLeft: isMapped ? '4px solid #9c27b0' : '4px solid transparent'
                                }}
                            >
                                <DataTableCell>
                                    <Box>
                                        <strong>{extOrgUnit.displayName}</strong>
                                        {extOrgUnit.parent?.displayName && (
                                            <Box fontSize="12px" color="#666">
                                                {i18n.t('Parent: {{parent}}', { parent: extOrgUnit.parent.displayName })}
                                            </Box>
                                        )}
                                        {extOrgUnit.parent?.parent?.displayName && (
                                            <Box fontSize="11px" color="#999">
                                                {i18n.t('Grandparent: {{grandparent}}', { grandparent: extOrgUnit.parent.parent.displayName })}
                                            </Box>
                                        )}
                                    </Box>
                                </DataTableCell>
                                <DataTableCell>
                                    <Tag color="blue">{i18n.t('Level {{level}}', { level: extOrgUnit.level || 'Unknown' })}</Tag>
                                </DataTableCell>
                                <DataTableCell>
                                    <SingleSelect
                                        placeholder={i18n.t('Select local organization unit')}
                                        selected={(() => {
                                            // Safety check: only set selected if the value exists in options
                                            if (!mappedLocalId) return ''
                                            const options = getLocalOrgUnitOptions(mappedLocalId)
                                            const exists = options.some(ou => ou.id === mappedLocalId)
                                            return exists ? mappedLocalId : ''
                                        })()}
                                        onChange={({ selected }) => handleMappingChange(extOrgUnit.id, selected)}
                                        clearable
                                        clearText={i18n.t('Clear mapping')}
                                        filterable
                                    >
                                        {getLocalOrgUnitOptions(mappedLocalId).map(localOrgUnit => {
                                            let label = `${localOrgUnit.displayName} (Level ${localOrgUnit.level})`
                                            if (localOrgUnit.parent?.displayName) {
                                                label += ` - Parent: ${localOrgUnit.parent.displayName}`
                                            }
                                            return (
                                                <SingleSelectOption 
                                                    key={localOrgUnit.id} 
                                                    value={localOrgUnit.id} 
                                                    label={label}
                                                />
                                            )
                                        })}
                                    </SingleSelect>
                                </DataTableCell>
                                <DataTableCell>
                                    {isMapped ? (
                                        <Tag color="green">{i18n.t('Mapped')}</Tag>
                                    ) : (
                                        <Tag color="red">{i18n.t('Not Mapped')}</Tag>
                                    )}
                                </DataTableCell>
                                <DataTableCell>
                                    {isMapped && (
                                        <Button 
                                            small 
                                            destructive 
                                            onClick={() => handleClearMapping(extOrgUnit.id)}
                                        >
                                            {i18n.t('Clear')}
                                        </Button>
                                    )}
                                </DataTableCell>
                            </DataTableRow>
                        )
                    })})()}
                </DataTableBody>
            </DataTable>

            {/* Pagination Controls */}
            {(() => {
                const totalItems = selectedOrgUnits.length
                const totalPages = Math.ceil(totalItems / itemsPerPage)
                const startIndex = (currentPage - 1) * itemsPerPage
                const endIndex = startIndex + itemsPerPage
                
                return totalPages > 1 && (
                    <Box padding="16px" display="flex" justifyContent="space-between" alignItems="center" borderTop="1px solid #e8eaed">
                        <Box fontSize="14px" color="#666">
                            {i18n.t('Showing {{start}}-{{end}} of {{total}} organization units', {
                                start: startIndex + 1,
                                end: Math.min(endIndex, totalItems),
                                total: totalItems
                            })}
                        </Box>
                        <Pagination
                            page={currentPage}
                            pageCount={totalPages}
                            pageSize={itemsPerPage}
                            total={totalItems}
                            onPageChange={setCurrentPage}
                            hidePageSizeSelect
                        />
                    </Box>
                )
            })()}

            {/* Actions */}
            <Box marginTop="24px">
                <ButtonStrip>
                    <Button 
                        primary 
                        onClick={handleSaveAndContinue}
                        disabled={completedMappings === 0}
                    >
                        {i18n.t('Continue to Dataset Preparation')} ({completedMappings}/{totalMappings})
                    </Button>
                    <Button onClick={() => setMappings({})}>
                        {i18n.t('Clear All Mappings')}
                    </Button>
                </ButtonStrip>
            </Box>

            {/* Mapped Organization Units Preview */}
            {completedMappings > 0 && (
                <Box marginTop="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    <h4 style={{ margin: '0 0 12px 0' }}>{i18n.t('Mapped Organization Units')}</h4>
                    <Box display="flex" flexDirection="column" gap="8px">
                        {selectedOrgUnits
                            .filter(extOrgUnit => mappings[extOrgUnit.id])
                            .map(extOrgUnit => {
                                const mappedLocal = localOrgUnits.find(ou => ou.id === mappings[extOrgUnit.id])
                                return (
                                    <Box key={extOrgUnit.id} display="flex" alignItems="center" gap="8px">
                                        <span style={{ fontSize: '14px' }}>
                                            <strong>{extOrgUnit.displayName}</strong> → <strong>{mappedLocal?.displayName}</strong>
                                        </span>
                                        <Tag color="blue" small>Level {mappedLocal?.level}</Tag>
                                    </Box>
                                )
                            })}
                    </Box>
                </Box>
            )}
        </Box>
    )
}