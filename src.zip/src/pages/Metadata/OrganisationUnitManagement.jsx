import React, { useState, useEffect } from 'react'
import { useDataQuery } from '@dhis2/app-runtime'
import {
    Box,
    Button,
    ButtonStrip,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    CircularLoader,
    NoticeBox,
    InputField,
    Checkbox,
    Tag,
    Pagination
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'

// Dynamic query that will be created based on selected dataset
const createOrganisationUnitsQuery = (dataSetId) => ({
    dataSet: {
        resource: `dataSets/${dataSetId}`,
        params: {
            fields: 'id,displayName,organisationUnits[id,displayName,level,path,parent[id,displayName,parent[id,displayName]]]'
        }
    }
})

export const OrganisationUnitManagement = ({ dhis2Config, dataSets = [], selectedDataSet, selectedDataElements, value = [], onChange, onOrganisationUnitsSelected, selectedOrganisationUnits, onCreateTemplate }) => {
    const [externalData, setExternalData] = useState(null)
    const [externalLoading, setExternalLoading] = useState(false)
    const [externalError, setExternalError] = useState(null)

    // Function to fetch dataset organisation units from external DHIS2
    const fetchExternalOrgUnits = async () => {
        const datasetsToFetch = dataSets?.length > 0 ? dataSets : (selectedDataSet ? [selectedDataSet] : [])
        if (!dhis2Config?.configured || datasetsToFetch.length === 0) return

        setExternalLoading(true)
        setExternalError(null)

        try {
            const auth = btoa(`${dhis2Config.username}:${dhis2Config.password}`)
            
            // Fetch organization units for all selected datasets
            const promises = datasetsToFetch.map(async (dataset) => {
                const response = await fetch(`${dhis2Config.baseUrl}/api/dataSets/${dataset.id}?fields=id,displayName,organisationUnits[id,displayName,level,path,parent[id,displayName,parent[id,displayName]]]`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Basic ${auth}`,
                        'Content-Type': 'application/json',
                    },
                })

                if (response.ok) {
                    const result = await response.json()
                    return { dataset, orgUnits: result.organisationUnits || [] }
                } else {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`)
                }
            })

            const results = await Promise.all(promises)
            
            // Merge organization units from all datasets, removing duplicates
            const orgUnitsMap = new Map()
            const datasetInfo = []
            
            results.forEach(({ dataset, orgUnits }) => {
                datasetInfo.push({ id: dataset.id, displayName: dataset.displayName, orgUnitsCount: orgUnits.length })
                
                orgUnits.forEach(orgUnit => {
                    if (!orgUnitsMap.has(orgUnit.id)) {
                        orgUnitsMap.set(orgUnit.id, {
                            ...orgUnit,
                            datasets: [dataset.displayName]
                        })
                    } else {
                        // Add dataset name to existing org unit
                        const existing = orgUnitsMap.get(orgUnit.id)
                        if (!existing.datasets.includes(dataset.displayName)) {
                            existing.datasets.push(dataset.displayName)
                        }
                    }
                })
            })

            const mergedOrgUnits = Array.from(orgUnitsMap.values())
            
            setExternalData({ 
                dataSets: datasetInfo,
                organisationUnits: mergedOrgUnits,
                totalOrgUnits: mergedOrgUnits.length
            })
        } catch (error) {
            console.error('Error fetching external organisation units:', error)
            setExternalError(error.message)
        } finally {
            setExternalLoading(false)
        }
    }

    // Fetch external data when config or selected dataset changes
    useEffect(() => {
        if (dhis2Config?.configured && (dataSets?.length > 0 || selectedDataSet)) {
            fetchExternalOrgUnits()
        }
    }, [dhis2Config?.configured, dhis2Config?.baseUrl, dhis2Config?.username, dataSets?.map(ds => ds.id).join(','), selectedDataSet?.id])

    // Use external data if available
    const data = externalData
    const loading = externalLoading
    const error = externalError
    
    // Use props for selected org units, with fallback to local state if not provided
    const [localSelectedOrgUnits, setLocalSelectedOrgUnits] = useState(new Set())
    const selectedOrgUnits = value?.length > 0 ? new Set(value.map(ou => ou.id)) : 
                            selectedOrganisationUnits ? new Set(selectedOrganisationUnits) : 
                            localSelectedOrgUnits
    const setSelectedOrgUnits = onChange ? 
        (newSet) => {
            const selectedOrgUnitObjects = data?.organisationUnits?.filter(ou => newSet.has(ou.id)) || []
            onChange(selectedOrgUnitObjects)
        } :
        onOrganisationUnitsSelected ? 
        (newSet) => onOrganisationUnitsSelected(Array.from(newSet)) : 
        setLocalSelectedOrgUnits
    const [searchTerm, setSearchTerm] = useState('')
    const [filterLevel, setFilterLevel] = useState('')
    const [showSelectedOnly, setShowSelectedOnly] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage] = useState(25)

    // Reset selected org units when dataset changes
    useEffect(() => {
        if (onChange) {
            onChange([])
        } else if (onOrganisationUnitsSelected) {
            onOrganisationUnitsSelected([])
        } else {
            setLocalSelectedOrgUnits(new Set())
        }
        setSearchTerm('')
        setFilterLevel('')
        setShowSelectedOnly(false)
    }, [dataSets?.map(ds => ds.id).join(','), selectedDataSet?.id]) // Only depend on dataset IDs

    // Get organisation units from the merged data
    const availableOrgUnits = data?.organisationUnits || []
    
    // Filter organisation units based on search and filters
    const filteredOrgUnits = availableOrgUnits.filter(orgUnit => {
        const matchesSearch = orgUnit.displayName.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesLevel = !filterLevel || orgUnit.level?.toString() === filterLevel
        const matchesSelection = !showSelectedOnly || selectedOrgUnits.has(orgUnit.id)
        
        return matchesSearch && matchesLevel && matchesSelection
    })

    // Pagination calculations
    const totalItems = filteredOrgUnits.length
    const totalPages = Math.ceil(totalItems / itemsPerPage)
    const startIndex = (currentPage - 1) * itemsPerPage
    const endIndex = startIndex + itemsPerPage
    const paginatedOrgUnits = filteredOrgUnits.slice(startIndex, endIndex)

    // Reset to first page when filters change
    useEffect(() => {
        setCurrentPage(1)
    }, [searchTerm, filterLevel, showSelectedOnly])

    const handleOrgUnitToggle = (orgUnitId) => {
        const newSelected = new Set(selectedOrgUnits)
        if (newSelected.has(orgUnitId)) {
            newSelected.delete(orgUnitId)
        } else {
            newSelected.add(orgUnitId)
        }
        setSelectedOrgUnits(newSelected)
    }

    const handleSelectAll = () => {
        if (selectedOrgUnits.size === filteredOrgUnits.length) {
            setSelectedOrgUnits(new Set())
        } else {
            setSelectedOrgUnits(new Set(filteredOrgUnits.map(ou => ou.id)))
        }
    }

    const getLevelColor = (level) => {
        const colors = {
            '1': 'blue',
            '2': 'green', 
            '3': 'orange',
            '4': 'purple',
            '5': 'red',
            '6': 'teal'
        }
        return colors[level?.toString()] || 'grey'
    }

    // Check if DHIS2 is configured
    if (!dhis2Config?.configured) {
        return (
            <Box>
                <NoticeBox warning title={i18n.t('DHIS2 Configuration Required')}>
                    {i18n.t('Please configure the external DHIS2 instance first in the DHIS2 Configuration tab.')}
                </NoticeBox>
            </Box>
        )
    }

    // Show message if no dataset is selected
    if (!selectedDataSet && (!dataSets || dataSets.length === 0)) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" height="300px">
                <NoticeBox title={i18n.t('No Dataset Selected')}>
                    {i18n.t('Please select a dataset from the Data Sets tab to view its organisation units.')}
                </NoticeBox>
            </Box>
        )
    }

    // Show loading state when fetching dataset-specific organisation units
    if (loading) {
        return (
            <Box>
                <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    <h3 style={{ margin: '0 0 8px 0' }}>
                        {dataSets?.length > 0 
                            ? i18n.t('Loading organisation units for selected datasets...')
                            : i18n.t('Loading organisation units for: {{name}}', { name: selectedDataSet?.displayName || selectedDataSet?.name || 'Unknown' })
                        }
                    </h3>
                </Box>
                <Box display="flex" justifyContent="center" alignItems="center" height="300px">
                    <CircularLoader />
                </Box>
            </Box>
        )
    }

    // Show error state
    if (error) {
        return (
            <Box>
                <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    <h3 style={{ margin: '0 0 8px 0' }}>
                        {dataSets?.length > 0 
                            ? i18n.t('Error loading organisation units for selected datasets')
                            : i18n.t('Error loading: {{name}}', { name: selectedDataSet?.displayName || selectedDataSet?.name || 'Unknown' })
                        }
                    </h3>
                </Box>
                <NoticeBox error title={i18n.t('Error loading organisation units')}>
                    {error.message}
                </NoticeBox>
            </Box>
        )
    }

    return (
        <Box>
            {/* Selected Datasets and Data Elements Header */}
            <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Box>
                        {dataSets?.length > 0 ? (
                            <>
                                <h3 style={{ margin: '0 0 8px 0' }}>
                                    {i18n.t('Selected Datasets')} ({dataSets.length})
                                </h3>
                                <Box display="flex" gap="8px" alignItems="center" marginBottom="8px" flexWrap="wrap">
                                    {data?.dataSets?.map(ds => (
                                        <Tag key={ds.id} color="blue">
                                            {ds.displayName} ({ds.orgUnitsCount} {i18n.t('org units')})
                                        </Tag>
                                    ))}
                                </Box>
                                <Box display="flex" gap="8px" alignItems="center" marginBottom="8px">
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {selectedDataElements?.length || 0} {i18n.t('data elements selected')}
                                    </span>
                                    <span style={{ color: '#666', fontSize: '14px' }}>•</span>
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {availableOrgUnits.length} {i18n.t('unique organisation units available')}
                                    </span>
                                </Box>
                            </>
                        ) : selectedDataSet ? (
                            <>
                                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Selected Dataset: {{name}}', { name: selectedDataSet?.displayName || selectedDataSet?.name || 'Unknown' })}</h3>
                                <Box display="flex" gap="8px" alignItems="center" marginBottom="8px">
                                    <Tag color="blue">{selectedDataSet?.periodType || 'Unknown'}</Tag>
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {selectedDataElements?.length || 0} {i18n.t('data elements selected')}
                                    </span>
                                    <span style={{ color: '#666', fontSize: '14px' }}>•</span>
                                    <span style={{ color: '#666', fontSize: '14px' }}>
                                        {availableOrgUnits.length} {i18n.t('organisation units available')}
                                    </span>
                                </Box>
                            </>
                        ) : null}
                        {selectedDataElements && selectedDataElements.length > 0 && (
                            <Box>
                                <span style={{ color: '#666', fontSize: '12px' }}>
                                    {i18n.t('Data Elements')}: {selectedDataElements.slice(0, 3).map(de => de.displayName).join(', ')}
                                    {selectedDataElements.length > 3 && ` +${selectedDataElements.length - 3} more`}
                                </span>
                            </Box>
                        )}
                    </Box>
                    <ButtonStrip>
                        <Button primary onClick={() => {
                            if (onCreateTemplate && selectedOrgUnits.size > 0) {
                                const selectedOrgUnitsData = availableOrgUnits.filter(ou => selectedOrgUnits.has(ou.id))
                                onCreateTemplate({
                                    dataSet: selectedDataSet,
                                    dataElements: selectedDataElements,
                                    organisationUnits: selectedOrgUnitsData
                                })
                            }
                        }} disabled={selectedOrgUnits.size === 0}>
                            {i18n.t('Create Assessment Template')} ({selectedOrgUnits.size})
                        </Button>
                    </ButtonStrip>
                </Box>
            </Box>

            <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                <h3>{i18n.t('Organisation Unit Selection')}</h3>
            </Box>

            {/* Filters */}
            <Box display="flex" gap="16px" marginBottom="16px" alignItems="end">
                <Box flex="1">
                    <InputField
                        label={i18n.t('Search organisation units')}
                        placeholder={i18n.t('Enter organisation unit name...')}
                        value={searchTerm}
                        onChange={({ value }) => setSearchTerm(value)}
                    />
                </Box>
                <Box width="150px">
                    <InputField
                        label={i18n.t('Level')}
                        placeholder={i18n.t('All levels')}
                        value={filterLevel}
                        onChange={({ value }) => setFilterLevel(value)}
                    />
                </Box>
                <Box>
                    <Checkbox
                        label={i18n.t('Show selected only')}
                        checked={showSelectedOnly}
                        onChange={({ checked }) => setShowSelectedOnly(checked)}
                    />
                </Box>
            </Box>

            {/* Selection Summary */}
            {selectedOrgUnits.size > 0 && (
                <Box marginBottom="16px">
                    <NoticeBox title={i18n.t('Selection Summary')}>
                        {i18n.t('{{count}} organisation units selected for assessment', { count: selectedOrgUnits.size })}
                    </NoticeBox>
                </Box>
            )}

            {/* Organisation Units Table */}
            <DataTable>
                <DataTableHead>
                    <DataTableRow>
                        <DataTableColumnHeader>
                            <Checkbox
                                checked={selectedOrgUnits.size === filteredOrgUnits.length && filteredOrgUnits.length > 0}
                                indeterminate={selectedOrgUnits.size > 0 && selectedOrgUnits.size < filteredOrgUnits.length}
                                onChange={handleSelectAll}
                            />
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Organisation Unit Name')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Level')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Parent Hierarchy')}
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                            {i18n.t('Path')}
                        </DataTableColumnHeader>
                        {dataSets?.length > 1 && (
                            <DataTableColumnHeader>
                                {i18n.t('Datasets')}
                            </DataTableColumnHeader>
                        )}
                    </DataTableRow>
                </DataTableHead>
                <DataTableBody>
                    {paginatedOrgUnits.map(orgUnit => (
                        <DataTableRow key={orgUnit.id}>
                            <DataTableCell>
                                <Checkbox
                                    checked={selectedOrgUnits.has(orgUnit.id)}
                                    onChange={() => handleOrgUnitToggle(orgUnit.id)}
                                />
                            </DataTableCell>
                            <DataTableCell>{orgUnit.displayName}</DataTableCell>
                            <DataTableCell>
                                {orgUnit.level && (
                                    <Tag color={getLevelColor(orgUnit.level)}>
                                        Level {orgUnit.level}
                                    </Tag>
                                )}
                            </DataTableCell>
                            <DataTableCell>
                                <Box display="flex" flexDirection="column" gap="2px">
                                    {orgUnit.parent?.displayName && (
                                        <Box fontSize="13px" fontWeight="500">
                                            {i18n.t('Parent: {{name}}', { name: orgUnit.parent.displayName })}
                                        </Box>
                                    )}
                                    {orgUnit.parent?.parent?.displayName && (
                                        <Box fontSize="12px" color="#666">
                                            {i18n.t('Grandparent: {{name}}', { name: orgUnit.parent.parent.displayName })}
                                        </Box>
                                    )}
                                    {!orgUnit.parent?.displayName && (
                                        <Box fontSize="13px" color="#999">-</Box>
                                    )}
                                </Box>
                            </DataTableCell>
                            <DataTableCell>
                                <span style={{ fontSize: '12px', color: '#666', fontFamily: 'monospace' }}>
                                    {orgUnit.path || '-'}
                                </span>
                            </DataTableCell>
                            {dataSets?.length > 1 && (
                                <DataTableCell>
                                    <Box display="flex" gap="4px" flexWrap="wrap">
                                        {orgUnit.datasets?.map(datasetName => (
                                            <Tag key={datasetName} color="neutral" style={{ fontSize: '11px' }}>
                                                {datasetName}
                                            </Tag>
                                        ))}
                                    </Box>
                                </DataTableCell>
                            )}
                        </DataTableRow>
                    ))}
                </DataTableBody>
            </DataTable>

            {/* Pagination Controls */}
            {totalPages > 1 && (
                <Box padding="16px" display="flex" justifyContent="space-between" alignItems="center" borderTop="1px solid #e8eaed">
                    <Box fontSize="14px" color="#666">
                        {i18n.t('Showing {{start}}-{{end}} of {{total}} organisation units', {
                            start: startIndex + 1,
                            end: Math.min(endIndex, totalItems),
                            total: totalItems
                        })}
                    </Box>
                    <Pagination
                        page={currentPage}
                        pageCount={totalPages}
                        pageSize={itemsPerPage}
                        total={totalItems}
                        onPageChange={setCurrentPage}
                        hidePageSizeSelect
                    />
                </Box>
            )}

            {filteredOrgUnits.length === 0 && (
                <Box padding="24px" textAlign="center">
                    <NoticeBox>
                        {searchTerm || filterLevel || showSelectedOnly
                            ? i18n.t('No organisation units match your current filters')
                            : i18n.t('No organisation units found')
                        }
                    </NoticeBox>
                </Box>
            )}
        </Box>
    )
}