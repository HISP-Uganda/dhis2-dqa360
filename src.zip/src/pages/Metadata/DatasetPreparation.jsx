import React, { useState, useEffect } from 'react'
import {
    Box,
    Button,
    ButtonStrip,
    Card,
    InputField,
    TextAreaField,
    SingleSelect,
    SingleSelectOption,
    Tag,
    NoticeBox,
    CircularLoader,
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    TabBar,
    Tab,
    Divider
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { useDataEngine } from '@dhis2/app-runtime'

// Datastore operations
const DATASTORE_NAMESPACE = 'dqa360-assessments'

// UID generation query
const generateUIDs = {
    resource: 'system/id',
    params: ({ count }) => ({
        limit: count
    })
}

const saveToDatastore = {
    resource: `dataStore/${DATASTORE_NAMESPACE}`,
    type: 'create',
    data: ({ key, data }) => data,
    params: ({ key }) => ({ key })
}

const updateDatastore = {
    resource: `dataStore/${DATASTORE_NAMESPACE}`,
    type: 'update', 
    data: ({ key, data }) => data,
    params: ({ key }) => ({ key })
}

const createDataSet = {
    resource: 'dataSets',
    type: 'create',
    data: ({ dataSet }) => dataSet
}

// Query to get default category combo
const defaultCategoryComboQuery = {
    categoryCombos: {
        resource: 'categoryCombos',
        params: {
            filter: 'name:eq:default',
            fields: 'id,name',
            paging: false
        }
    }
}

export const DatasetPreparation = ({ 
    dhis2Config,
    selectedDataSets = [],
    selectedDataElements = [],
    orgUnitMappings = [],
    assessmentName = '',
    period = '',
    onSave,
    onFinish
}) => {
    const engine = useDataEngine()
    const [datasets, setDatasets] = useState({})
    const [dataElementFormNames, setDataElementFormNames] = useState({}) // Store custom form names for each data element in each dataset
    const [activeTab, setActiveTab] = useState('register')
    const [defaultCategoryCombo, setDefaultCategoryCombo] = useState('bjDvmb4bfuf') // Default fallback
    const [saving, setSaving] = useState(false)
    const [creating, setCreating] = useState(false)
    const [error, setError] = useState(null)
    const [success, setSuccess] = useState(null)

    // Fetch default category combo
    useEffect(() => {
        const fetchDefaultCategoryCombo = async () => {
            try {
                const result = await engine.query(defaultCategoryComboQuery)
                if (result.categoryCombos.categoryCombos.length > 0) {
                    setDefaultCategoryCombo(result.categoryCombos.categoryCombos[0].id)
                }
            } catch (err) {
                console.warn('Could not fetch default category combo, using fallback:', err)
                // Keep the fallback value
            }
        }
        fetchDefaultCategoryCombo()
    }, [engine])

    // Function to generate UIDs from DHIS2
    const generateDatasetUIDs = async () => {
        try {
            const result = await engine.query(generateUIDs, {
                variables: { count: 4 } // Generate 4 UIDs for 4 datasets
            })
            return result.codes || []
        } catch (error) {
            console.error('Error generating UIDs:', error)
            throw new Error('Failed to generate valid UIDs from DHIS2')
        }
    }

    // Initialize the 4 datasets
    useEffect(() => {
        const initializeDatasets = async () => {
            const baseCode = assessmentName.replace(/\s+/g, '_').toUpperCase()
            const baseName = assessmentName
            
            // Generate UIDs for all datasets
            let uids = []
            try {
                uids = await generateDatasetUIDs()
                if (uids.length < 4) {
                    throw new Error('Not enough UIDs generated')
                }
            } catch (error) {
                console.error('Failed to generate UIDs, proceeding without IDs:', error)
                // Fallback to no IDs - let DHIS2 auto-generate
            }

            const initialDatasets = {
                register: {
                    ...(uids.length >= 4 && { id: uids[0] }), // Add UID if available
                    name: `${baseName} - Register Data (${period})`,
                    shortName: `${baseName} Register`,
                    code: `${baseCode}_REG_${period}`,
                    description: `Register data collection for ${baseName} assessment in ${period}`,
                    periodType: 'Monthly',
                    categoryCombo: { id: defaultCategoryCombo }, // Default category combo as object
                    dataSetElements: selectedDataElements.map(de => ({
                        dataElement: { id: de.id },
                        categoryCombo: { id: de.categoryCombo?.id || defaultCategoryCombo }
                    })),
                    organisationUnits: orgUnitMappings
                        .filter(mapping => mapping.mapped && mapping.local?.id)
                        .map(mapping => ({ id: mapping.local.id })),
                    openFuturePeriods: 0,
                    expiryDays: 0,
                    timelyDays: 15,
                    notifyCompletingUser: false,
                    skipOffline: false,
                    dataElementDecoration: false,
                    renderAsTabs: false,
                    renderHorizontally: false
                },
                summary: {
                    ...(uids.length >= 4 && { id: uids[1] }), // Add UID if available
                    name: `${baseName} - Summary Data (${period})`,
                    shortName: `${baseName} Summary`,
                    code: `${baseCode}_SUM_${period}`,
                    description: `Summary data collection for ${baseName} assessment in ${period}`,
                    periodType: 'Monthly',
                    categoryCombo: { id: defaultCategoryCombo },
                    dataSetElements: selectedDataElements.map(de => ({
                        dataElement: { id: de.id },
                        categoryCombo: { id: de.categoryCombo?.id || defaultCategoryCombo }
                    })),
                    organisationUnits: orgUnitMappings
                        .filter(mapping => mapping.mapped && mapping.local?.id)
                        .map(mapping => ({ id: mapping.local.id })),
                    openFuturePeriods: 0,
                    expiryDays: 0,
                    timelyDays: 15,
                    notifyCompletingUser: false,
                    skipOffline: false,
                    dataElementDecoration: false,
                    renderAsTabs: false,
                    renderHorizontally: false
                },
                reported: {
                    ...(uids.length >= 4 && { id: uids[2] }), // Add UID if available
                    name: `${baseName} - Reported Data (${period})`,
                    shortName: `${baseName} Reported`,
                    code: `${baseCode}_REP_${period}`,
                    description: `Reported data collection for ${baseName} assessment in ${period}`,
                    periodType: 'Monthly',
                    categoryCombo: { id: defaultCategoryCombo },
                    dataSetElements: selectedDataElements.map(de => ({
                        dataElement: { id: de.id },
                        categoryCombo: { id: de.categoryCombo?.id || defaultCategoryCombo }
                    })),
                    organisationUnits: orgUnitMappings
                        .filter(mapping => mapping.mapped && mapping.local?.id)
                        .map(mapping => ({ id: mapping.local.id })),
                    openFuturePeriods: 0,
                    expiryDays: 0,
                    timelyDays: 15,
                    notifyCompletingUser: false,
                    skipOffline: false,
                    dataElementDecoration: false,
                    renderAsTabs: false,
                    renderHorizontally: false
                },
                correction: {
                    ...(uids.length >= 4 && { id: uids[3] }), // Add UID if available
                    name: `${baseName} - Correction Data (${period})`,
                    shortName: `${baseName} Correction`,
                    code: `${baseCode}_COR_${period}`,
                    description: `Correction data collection for ${baseName} assessment in ${period}`,
                    periodType: 'Monthly',
                    categoryCombo: { id: defaultCategoryCombo },
                    dataSetElements: selectedDataElements.map(de => ({
                        dataElement: { id: de.id },
                        categoryCombo: { id: de.categoryCombo?.id || defaultCategoryCombo }
                    })),
                    organisationUnits: orgUnitMappings
                        .filter(mapping => mapping.mapped && mapping.local?.id)
                        .map(mapping => ({ id: mapping.local.id })),
                    openFuturePeriods: 0,
                    expiryDays: 0,
                    timelyDays: 15,
                    notifyCompletingUser: false,
                    skipOffline: false,
                    dataElementDecoration: false,
                    renderAsTabs: false,
                    renderHorizontally: false
                }
            }

            setDatasets(initialDatasets)
        }

        if (assessmentName && period && selectedDataElements.length > 0 && orgUnitMappings.length > 0 && defaultCategoryCombo) {
            initializeDatasets().catch(error => {
                console.error('Error initializing datasets:', error)
                // Continue with initialization even if UID generation fails
            })
            initializeFormNames()
        }
    }, [assessmentName, period, selectedDataElements, orgUnitMappings, defaultCategoryCombo, engine])

    // Initialize form names for data elements
    const initializeFormNames = () => {
        const formNames = {}
        const datasetTypes = ['register', 'summary', 'reported', 'correction']
        
        datasetTypes.forEach(type => {
            formNames[type] = {}
            selectedDataElements.forEach(de => {
                // Use displayName as default, but allow customization
                formNames[type][de.id] = de.displayName || de.name || ''
            })
        })
        
        setDataElementFormNames(formNames)
    }

    const handleDatasetChange = (datasetType, field, value) => {
        setDatasets(prev => ({
            ...prev,
            [datasetType]: {
                ...prev[datasetType],
                [field]: value
            }
        }))
    }

    const handleFormNameChange = (datasetType, dataElementId, formName) => {
        setDataElementFormNames(prev => ({
            ...prev,
            [datasetType]: {
                ...prev[datasetType],
                [dataElementId]: formName
            }
        }))
    }

    const handleSaveMetadata = async () => {
        setSaving(true)
        setError(null)
        try {
            const assessmentData = {
                id: `${assessmentName.replace(/\s+/g, '_')}_${period}`,
                name: assessmentName,
                period,
                dhis2Config,
                selectedDataSets,
                selectedDataElements,
                orgUnitMappings,
                datasets,
                dataElementFormNames,
                created: new Date().toISOString(),
                status: 'prepared'
            }

            // Save to datastore
            try {
                await engine.mutate(saveToDatastore, {
                    variables: {
                        key: assessmentData.id,
                        data: assessmentData
                    }
                })
            } catch (saveError) {
                // If save fails, try update (key might already exist)
                await engine.mutate(updateDatastore, {
                    variables: {
                        key: assessmentData.id,
                        data: assessmentData
                    }
                })
            }

            setSuccess(i18n.t('Assessment metadata saved successfully'))
            onSave && onSave(assessmentData)
        } catch (err) {
            console.error('Error saving metadata:', err)
            setError(err.message)
        } finally {
            setSaving(false)
        }
    }

    const validateDataset = (dataset, type) => {
        const errors = []
        
        if (!dataset.name || dataset.name.trim() === '') {
            errors.push(`${type}: Dataset name is required`)
        }
        if (!dataset.shortName || dataset.shortName.trim() === '') {
            errors.push(`${type}: Short name is required`)
        }
        if (!dataset.code || dataset.code.trim() === '') {
            errors.push(`${type}: Code is required`)
        }
        if (!dataset.periodType) {
            errors.push(`${type}: Period type is required`)
        }
        if (!dataset.dataSetElements || dataset.dataSetElements.length === 0) {
            errors.push(`${type}: At least one data element is required`)
        }
        if (!dataset.organisationUnits || dataset.organisationUnits.length === 0) {
            errors.push(`${type}: At least one organization unit is required`)
        }
        
        return errors
    }

    const handleCreateDatasets = async () => {
        setCreating(true)
        setError(null)
        try {
            // Validate all datasets first
            const allErrors = []
            Object.entries(datasets).forEach(([type, dataset]) => {
                const errors = validateDataset(dataset, type)
                allErrors.push(...errors)
            })
            
            if (allErrors.length > 0) {
                throw new Error(`Validation errors:\n${allErrors.join('\n')}`)
            }
            
            const createdDatasets = {}
            
            // Create each dataset in DHIS2
            for (const [type, dataset] of Object.entries(datasets)) {
                try {
                    console.log(`Creating ${type} dataset:`, JSON.stringify(dataset, null, 2))
                    
                    // Clean the dataset object - remove any undefined values
                    const cleanDataset = JSON.parse(JSON.stringify(dataset))
                    
                    const result = await engine.mutate(createDataSet, {
                        variables: { dataSet: cleanDataset }
                    })
                    createdDatasets[type] = result.response
                    console.log(`Successfully created ${type} dataset:`, result.response)
                } catch (createError) {
                    console.error(`Error creating ${type} dataset:`, createError)
                    console.error(`Dataset payload:`, JSON.stringify(dataset, null, 2))
                    
                    // Try to extract more specific error information
                    let errorMessage = createError.message || 'Unknown error'
                    if (createError.details) {
                        errorMessage += ` - Details: ${JSON.stringify(createError.details)}`
                    }
                    
                    throw new Error(`Failed to create ${type} dataset: ${errorMessage}`)
                }
            }

            // Update assessment with created dataset IDs
            const assessmentData = {
                id: `${assessmentName.replace(/\s+/g, '_')}_${period}`,
                name: assessmentName,
                period,
                dhis2Config,
                selectedDataSets,
                selectedDataElements,
                orgUnitMappings,
                datasets,
                dataElementFormNames,
                createdDatasets,
                created: new Date().toISOString(),
                status: 'created'
            }

            // Update datastore
            await engine.mutate(updateDatastore, {
                variables: {
                    key: assessmentData.id,
                    data: assessmentData
                }
            })

            setSuccess(i18n.t('All datasets created successfully in DHIS2'))
            onFinish && onFinish(assessmentData)
        } catch (err) {
            console.error('Error creating datasets:', err)
            setError(err.message)
        } finally {
            setCreating(false)
        }
    }

    const getDatasetTypeColor = (type) => {
        const colors = {
            register: 'blue',
            summary: 'green', 
            reported: 'orange',
            correction: 'purple'
        }
        return colors[type] || 'grey'
    }

    const getDatasetTypeLabel = (type) => {
        const labels = {
            register: i18n.t('Register Dataset'),
            summary: i18n.t('Summary Dataset'),
            reported: i18n.t('Reported Dataset'),
            correction: i18n.t('Correction Dataset')
        }
        return labels[type] || type
    }

    if (Object.keys(datasets).length === 0) {
        return (
            <Box>
                <NoticeBox title={i18n.t('Preparing Datasets')}>
                    {i18n.t('Please ensure assessment name, period, data elements, and organization unit mappings are configured.')}
                </NoticeBox>
            </Box>
        )
    }

    return (
        <Box>
            {/* Header */}
            <Box marginBottom="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Dataset Preparation')}</h3>
                <Box display="flex" gap="8px" alignItems="center" marginBottom="8px">
                    <span style={{ color: '#666', fontSize: '14px' }}>
                        {i18n.t('Configure the 4 datasets and customize data element form names for each dataset type')}
                    </span>
                </Box>
                <Box display="flex" gap="8px" alignItems="center" flexWrap="wrap">
                    <Tag color="blue">{i18n.t('{{count}} data elements', { count: selectedDataElements.length })}</Tag>
                    <Tag color="green">{i18n.t('{{count}} organization units', { count: orgUnitMappings.filter(m => m.mapped).length })}</Tag>
                    <Tag color="orange">{period}</Tag>
                </Box>
            </Box>

            {/* Success/Error Messages */}
            {success && (
                <Box marginBottom="16px">
                    <NoticeBox valid title={i18n.t('Success')}>
                        {success}
                    </NoticeBox>
                </Box>
            )}

            {error && (
                <Box marginBottom="16px">
                    <NoticeBox error title={i18n.t('Error')}>
                        {error}
                    </NoticeBox>
                </Box>
            )}

            {/* Tab Navigation */}
            <Box marginBottom="16px">
                <TabBar>
                    <Tab 
                        selected={activeTab === 'register'} 
                        onClick={() => setActiveTab('register')}
                    >
                        {i18n.t('Register Dataset')}
                    </Tab>
                    <Tab 
                        selected={activeTab === 'summary'} 
                        onClick={() => setActiveTab('summary')}
                    >
                        {i18n.t('Summary Dataset')}
                    </Tab>
                    <Tab 
                        selected={activeTab === 'reported'} 
                        onClick={() => setActiveTab('reported')}
                    >
                        {i18n.t('Reported Dataset')}
                    </Tab>
                    <Tab 
                        selected={activeTab === 'correction'} 
                        onClick={() => setActiveTab('correction')}
                    >
                        {i18n.t('Correction Dataset')}
                    </Tab>
                </TabBar>
            </Box>

            {/* Dataset Configuration for Active Tab */}
            {datasets[activeTab] && (
                <Card style={{ marginBottom: '24px' }}>
                    <Box padding="24px">
                        {/* Dataset Basic Info */}
                        <Box marginBottom="24px">
                            <Box display="flex" alignItems="center" gap="8px" marginBottom="16px">
                                <Tag color={getDatasetTypeColor(activeTab)}>{getDatasetTypeLabel(activeTab)}</Tag>
                            </Box>
                            
                            <Box display="grid" gridTemplateColumns="1fr 1fr" gap="16px" marginBottom="16px">
                                <InputField
                                    label={i18n.t('Dataset Name')}
                                    value={datasets[activeTab].name}
                                    onChange={({ value }) => handleDatasetChange(activeTab, 'name', value)}
                                />
                                <InputField
                                    label={i18n.t('Short Name')}
                                    value={datasets[activeTab].shortName}
                                    onChange={({ value }) => handleDatasetChange(activeTab, 'shortName', value)}
                                />
                            </Box>

                            <Box display="grid" gridTemplateColumns="1fr 1fr" gap="16px" marginBottom="16px">
                                <InputField
                                    label={i18n.t('Code')}
                                    value={datasets[activeTab].code}
                                    onChange={({ value }) => handleDatasetChange(activeTab, 'code', value)}
                                />
                                <SingleSelect
                                    label={i18n.t('Period Type')}
                                    selected={datasets[activeTab].periodType}
                                    onChange={({ selected }) => handleDatasetChange(activeTab, 'periodType', selected)}
                                >
                                    <SingleSelectOption value="Daily" label={i18n.t('Daily')} />
                                    <SingleSelectOption value="Weekly" label={i18n.t('Weekly')} />
                                    <SingleSelectOption value="Monthly" label={i18n.t('Monthly')} />
                                    <SingleSelectOption value="Quarterly" label={i18n.t('Quarterly')} />
                                    <SingleSelectOption value="Yearly" label={i18n.t('Yearly')} />
                                </SingleSelect>
                            </Box>

                            <TextAreaField
                                label={i18n.t('Description')}
                                value={datasets[activeTab].description}
                                onChange={({ value }) => handleDatasetChange(activeTab, 'description', value)}
                                rows={3}
                            />
                        </Box>

                        <Divider />

                        {/* Data Elements Configuration */}
                        <Box marginTop="24px">
                            <h4 style={{ margin: '0 0 16px 0' }}>{i18n.t('Data Elements & Form Names')}</h4>
                            <Box marginBottom="8px" fontSize="14px" color="#666">
                                {i18n.t('Customize how each data element will appear in the data entry form for this dataset type')}
                            </Box>
                            
                            <DataTable>
                                <DataTableHead>
                                    <DataTableRow>
                                        <DataTableColumnHeader>
                                            {i18n.t('Data Element')}
                                        </DataTableColumnHeader>
                                        <DataTableColumnHeader>
                                            {i18n.t('Original Name')}
                                        </DataTableColumnHeader>
                                        <DataTableColumnHeader>
                                            {i18n.t('Form Name (Display Name)')}
                                        </DataTableColumnHeader>
                                        <DataTableColumnHeader>
                                            {i18n.t('Value Type')}
                                        </DataTableColumnHeader>
                                    </DataTableRow>
                                </DataTableHead>
                                <DataTableBody>
                                    {selectedDataElements.map(dataElement => (
                                        <DataTableRow key={dataElement.id}>
                                            <DataTableCell>
                                                <Box>
                                                    <strong>{dataElement.displayName || dataElement.name}</strong>
                                                    <Box fontSize="12px" color="#666">
                                                        {dataElement.code && `Code: ${dataElement.code}`}
                                                    </Box>
                                                </Box>
                                            </DataTableCell>
                                            <DataTableCell>
                                                <Box fontSize="14px" color="#666">
                                                    {dataElement.displayName || dataElement.name}
                                                </Box>
                                            </DataTableCell>
                                            <DataTableCell>
                                                <InputField
                                                    value={dataElementFormNames[activeTab]?.[dataElement.id] || ''}
                                                    onChange={({ value }) => handleFormNameChange(activeTab, dataElement.id, value)}
                                                    placeholder={i18n.t('Enter custom form name')}
                                                    dense
                                                />
                                            </DataTableCell>
                                            <DataTableCell>
                                                <Tag color="neutral" small>
                                                    {dataElement.valueType || 'TEXT'}
                                                </Tag>
                                            </DataTableCell>
                                        </DataTableRow>
                                    ))}
                                </DataTableBody>
                            </DataTable>
                        </Box>

                        {/* Dataset Summary */}
                        <Box marginTop="24px" padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                            <h5 style={{ margin: '0 0 8px 0' }}>{i18n.t('Dataset Summary')}</h5>
                            <Box display="flex" gap="16px" alignItems="center" flexWrap="wrap">
                                <Box fontSize="14px" color="#666">
                                    {i18n.t('Data Elements: {{count}}', { count: datasets[activeTab].dataSetElements?.length || 0 })}
                                </Box>
                                <Box fontSize="14px" color="#666">
                                    {i18n.t('Organization Units: {{count}}', { count: datasets[activeTab].organisationUnits?.length || 0 })}
                                </Box>
                                <Box fontSize="14px" color="#666">
                                    {i18n.t('Period Type: {{type}}', { type: datasets[activeTab].periodType })}
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Card>
            )}

            {/* All Datasets Overview */}
            <Card style={{ marginBottom: '24px' }}>
                <Box padding="24px">
                    <h4 style={{ margin: '0 0 16px 0' }}>{i18n.t('All Datasets Overview')}</h4>
                    <Box display="grid" gridTemplateColumns="1fr 1fr 1fr 1fr" gap="16px">
                        {Object.entries(datasets).map(([type, dataset]) => (
                            <Box key={type} padding="12px" style={{ 
                                backgroundColor: activeTab === type ? '#e3f2fd' : '#f8f9fa', 
                                borderRadius: '4px',
                                border: activeTab === type ? '2px solid #2196f3' : '1px solid #e0e0e0',
                                cursor: 'pointer'
                            }} onClick={() => setActiveTab(type)}>
                                <Box display="flex" alignItems="center" gap="8px" marginBottom="8px">
                                    <Tag color={getDatasetTypeColor(type)} small>{getDatasetTypeLabel(type)}</Tag>
                                </Box>
                                <Box fontSize="14px" fontWeight="500" marginBottom="4px">
                                    {dataset.name}
                                </Box>
                                <Box fontSize="12px" color="#666">
                                    {dataset.code}
                                </Box>
                                <Box fontSize="12px" color="#666" marginTop="4px">
                                    {i18n.t('{{count}} elements', { count: dataset.dataSetElements?.length || 0 })}
                                </Box>
                            </Box>
                        ))}
                    </Box>
                </Box>
            </Card>

            {/* Actions */}
            <Box marginTop="24px">
                <ButtonStrip>
                    <Button 
                        onClick={handleSaveMetadata}
                        loading={saving}
                        disabled={creating}
                    >
                        {i18n.t('Save Configuration to Datastore')}
                    </Button>
                    <Button 
                        primary
                        onClick={handleCreateDatasets}
                        loading={creating}
                        disabled={saving}
                    >
                        {i18n.t('Create All Datasets in DHIS2')}
                    </Button>
                </ButtonStrip>
            </Box>
        </Box>
    )
}