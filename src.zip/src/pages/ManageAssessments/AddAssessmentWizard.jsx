import React, { useState } from 'react'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Input,
    TextArea,
    CircularLoader,
    NoticeBox,
    LinearLoader,
    Tag
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { DHIS2Configuration } from '../Metadata/DHIS2Configuration'
import { DataSetManagement } from '../Metadata/DataSetManagement'
import { OrganisationUnitManagement } from '../Metadata/OrganisationUnitManagement'

export const AddAssessmentWizard = ({ onAssessmentCreated, onCancel }) => {
    const [currentStep, setCurrentStep] = useState(1)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    
    // Wizard state
    const [assessmentInfo, setAssessmentInfo] = useState({
        name: '',
        description: ''
    })
    const [dhis2Config, setDhis2Config] = useState(null)
    const [selectedDataSet, setSelectedDataSet] = useState(null)
    const [selectedDataElements, setSelectedDataElements] = useState([])
    const [selectedOrgUnits, setSelectedOrgUnits] = useState([])
    const [createdDatasets, setCreatedDatasets] = useState([])

    const steps = [
        { id: 1, label: i18n.t('Assessment Info'), description: i18n.t('Basic information') },
        { id: 2, label: i18n.t('DHIS2 Connection'), description: i18n.t('Connect to DHIS2') },
        { id: 3, label: i18n.t('Dataset Selection'), description: i18n.t('Choose source dataset') },
        { id: 4, label: i18n.t('Organisation Units'), description: i18n.t('Select facilities') },
        { id: 5, label: i18n.t('Create & Save'), description: i18n.t('Generate assessment') }
    ]

    const canProceedToNext = () => {
        switch (currentStep) {
            case 1:
                return assessmentInfo.name.trim().length > 0
            case 2:
                return dhis2Config?.configured
            case 3:
                return selectedDataSet && selectedDataElements.length > 0
            case 4:
                return selectedOrgUnits.length > 0
            case 5:
                return true
            default:
                return false
        }
    }

    const handleNext = () => {
        if (currentStep < steps.length) {
            setCurrentStep(currentStep + 1)
        }
    }

    const handlePrevious = () => {
        if (currentStep > 1) {
            setCurrentStep(currentStep - 1)
        }
    }

    const handleCreateAssessment = async () => {
        setLoading(true)
        setError(null)

        try {
            // Import the assessment tools creation logic
            const { createAssessmentTools } = await import('../../utils/assessmentToolsCreator')
            
            // Create the 4 DHIS2 datasets
            const result = await createAssessmentTools({
                dhis2Config,
                selectedDataSet,
                dataElements: selectedDataElements,
                orgUnits: selectedOrgUnits,
                onProgress: (progress) => {
                    console.log('Progress:', progress)
                    // You can add progress UI updates here if needed
                }
            })

            if (result.success) {
                // Create the assessment object
                const newAssessment = {
                    id: `assessment_${Date.now()}`,
                    name: assessmentInfo.name,
                    description: assessmentInfo.description,
                    status: 'active',
                    dhis2Config,
                    sourceDataset: selectedDataSet,
                    dataElementsCount: selectedDataElements.length,
                    orgUnitsCount: selectedOrgUnits.length,
                    createdDatasets: result.createdDatasets,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                }

                // Notify parent component
                onAssessmentCreated(newAssessment)
            } else {
                throw new Error(result.error || 'Failed to create assessment tools')
            }
        } catch (error) {
            console.error('Error creating assessment:', error)
            setError(error.message || 'An unexpected error occurred')
        } finally {
            setLoading(false)
        }
    }

    const renderStepContent = () => {
        switch (currentStep) {
            case 1:
                return (
                    <Box>
                        <Box marginBottom="24px">
                            <h3 style={{ margin: '0 0 16px 0' }}>
                                {i18n.t('Assessment Information')}
                            </h3>
                            <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>
                                {i18n.t('Provide basic information about your data quality assessment.')}
                            </p>
                        </Box>

                        <Box marginBottom="16px">
                            <Input
                                label={i18n.t('Assessment Name')}
                                placeholder={i18n.t('Enter a descriptive name for your assessment')}
                                value={assessmentInfo.name}
                                onChange={({ value }) => setAssessmentInfo(prev => ({ ...prev, name: value }))}
                                required
                            />
                        </Box>

                        <Box marginBottom="16px">
                            <TextArea
                                label={i18n.t('Description (Optional)')}
                                placeholder={i18n.t('Describe the purpose and scope of this assessment')}
                                value={assessmentInfo.description}
                                onChange={({ value }) => setAssessmentInfo(prev => ({ ...prev, description: value }))}
                                rows={3}
                            />
                        </Box>
                    </Box>
                )

            case 2:
                return (
                    <Box>
                        <Box marginBottom="24px">
                            <h3 style={{ margin: '0 0 16px 0' }}>
                                {i18n.t('DHIS2 Connection')}
                            </h3>
                            <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>
                                {i18n.t('Connect to your DHIS2 instance to access datasets and metadata.')}
                            </p>
                        </Box>

                        <DHIS2Configuration 
                            onConfigured={(config) => {
                                setDhis2Config(config)
                            }}
                        />
                    </Box>
                )

            case 3:
                return (
                    <Box>
                        <Box marginBottom="24px">
                            <h3 style={{ margin: '0 0 16px 0' }}>
                                {i18n.t('Dataset & Data Elements')}
                            </h3>
                            <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>
                                {i18n.t('Select the source dataset and data elements for your assessment.')}
                            </p>
                        </Box>

                        {dhis2Config ? (
                            <DataSetManagement 
                                dhis2Config={dhis2Config}
                                onDataSetSelect={(dataSet) => {
                                    setSelectedDataSet(dataSet)
                                }}
                                onDataElementsSelect={(dataElements) => {
                                    setSelectedDataElements(dataElements)
                                }}
                            />
                        ) : (
                            <NoticeBox warning title={i18n.t('DHIS2 Connection Required')}>
                                {i18n.t('Please configure your DHIS2 connection in the previous step.')}
                            </NoticeBox>
                        )}
                    </Box>
                )

            case 4:
                return (
                    <Box>
                        <Box marginBottom="24px">
                            <h3 style={{ margin: '0 0 16px 0' }}>
                                {i18n.t('Organisation Units')}
                            </h3>
                            <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>
                                {i18n.t('Select the facilities and organisation units to include in your assessment.')}
                            </p>
                        </Box>

                        {dhis2Config && selectedDataSet ? (
                            <OrganisationUnitManagement 
                                dhis2Config={dhis2Config}
                                selectedDataSet={selectedDataSet}
                                selectedDataElements={selectedDataElements}
                                onCreateTemplate={(data) => {
                                    setSelectedOrgUnits(data.organisationUnits || [])
                                }}
                            />
                        ) : (
                            <NoticeBox warning title={i18n.t('Previous Steps Required')}>
                                {i18n.t('Please complete the DHIS2 connection and dataset selection steps first.')}
                            </NoticeBox>
                        )}
                    </Box>
                )

            case 5:
                return (
                    <Box>
                        <Box marginBottom="24px">
                            <h3 style={{ margin: '0 0 16px 0' }}>
                                {i18n.t('Create Assessment')}
                            </h3>
                            <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>
                                {i18n.t('Review your configuration and create the assessment with DHIS2 datasets.')}
                            </p>
                        </Box>

                        <Card>
                            <Box padding="16px">
                                <h4 style={{ margin: '0 0 16px 0' }}>
                                    {i18n.t('Assessment Summary')}
                                </h4>
                                
                                <Box display="grid" style={{ gridTemplateColumns: 'auto 1fr', gap: '8px 16px', fontSize: '14px' }}>
                                    <strong>{i18n.t('Name:')}</strong>
                                    <span>{assessmentInfo.name}</span>
                                    
                                    <strong>{i18n.t('Description:')}</strong>
                                    <span>{assessmentInfo.description || i18n.t('No description')}</span>
                                    
                                    <strong>{i18n.t('DHIS2 Instance:')}</strong>
                                    <span>{dhis2Config?.systemInfo?.systemName || 'Unknown'}</span>
                                    
                                    <strong>{i18n.t('Source Dataset:')}</strong>
                                    <span>{selectedDataSet?.displayName || 'Unknown'}</span>
                                    
                                    <strong>{i18n.t('Data Elements:')}</strong>
                                    <span>{selectedDataElements.length} selected</span>
                                    
                                    <strong>{i18n.t('Organisation Units:')}</strong>
                                    <span>{selectedOrgUnits.length} selected</span>
                                </Box>
                            </Box>
                        </Card>

                        {error && (
                            <Box marginTop="16px">
                                <NoticeBox error title={i18n.t('Error Creating Assessment')}>
                                    {error}
                                </NoticeBox>
                            </Box>
                        )}

                        <Box marginTop="24px">
                            <NoticeBox title={i18n.t('What will be created:')}>
                                <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                                    <li>{i18n.t('4 DHIS2 datasets for assessment tools (Primary, Summary, DHIS2, Correction)')}</li>
                                    <li>{i18n.t('Local assessment configuration linking all datasets')}</li>
                                    <li>{i18n.t('Ready-to-use assessment with data quality options')}</li>
                                </ul>
                            </NoticeBox>
                        </Box>
                    </Box>
                )

            default:
                return null
        }
    }

    return (
        <Box>
            {/* Progress Indicator */}
            <Box marginBottom="32px">
                <Box marginBottom="16px">
                    <LinearLoader amount={Math.round((currentStep / steps.length) * 100)} />
                </Box>
                <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="16px">
                    <Box>
                        <h3 style={{ margin: 0, fontSize: '18px' }}>
                            {steps[currentStep - 1]?.label}
                        </h3>
                        <p style={{ margin: '4px 0 0 0', color: '#666', fontSize: '14px' }}>
                            {steps[currentStep - 1]?.description}
                        </p>
                    </Box>
                    <Tag neutral>
                        {i18n.t('Step {{current}} of {{total}}', { current: currentStep, total: steps.length })}
                    </Tag>
                </Box>
                <Box display="flex" gap="8px" flexWrap="wrap">
                    {steps.map((step) => (
                        <Tag 
                            key={step.id}
                            positive={currentStep > step.id}
                            neutral={currentStep === step.id}
                            style={{ fontSize: '12px' }}
                        >
                            {step.label}
                        </Tag>
                    ))}
                </Box>
            </Box>

            {/* Step Content */}
            <Box marginBottom="32px" style={{ minHeight: '400px' }}>
                {renderStepContent()}
            </Box>

            {/* Navigation Buttons */}
            <Box display="flex" justifyContent="space-between" alignItems="center">
                <Button secondary onClick={onCancel}>
                    {i18n.t('Cancel')}
                </Button>

                <ButtonStrip>
                    {currentStep > 1 && (
                        <Button secondary onClick={handlePrevious}>
                            {i18n.t('Previous')}
                        </Button>
                    )}
                    
                    {currentStep < steps.length ? (
                        <Button 
                            primary 
                            onClick={handleNext}
                            disabled={!canProceedToNext()}
                        >
                            {i18n.t('Next')}
                        </Button>
                    ) : (
                        <Button 
                            primary 
                            onClick={handleCreateAssessment}
                            disabled={!canProceedToNext() || loading}
                        >
                            {loading ? (
                                <>
                                    <CircularLoader small />
                                    {i18n.t('Creating...')}
                                </>
                            ) : (
                                i18n.t('Create Assessment')
                            )}
                        </Button>
                    )}
                </ButtonStrip>
            </Box>
        </Box>
    )
}