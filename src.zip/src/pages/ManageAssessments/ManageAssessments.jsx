import React, { useState, useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { 
    Box, 
    Button, 
    Card, 
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    Tag,
    ButtonStrip,
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions,
    DropdownButton,
    FlyoutMenu,
    MenuItem,
    Divider,
    IconAdd24,
    IconEdit24,
    IconDelete24,
    IconView24,
    IconDownload24,
    IconUpload24,
    IconSettings24
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { 
    DataQualityCheckModal, 
    CompletenessAnalysisModal, 
    AssessmentSettingsModal 
} from '../../components/DQActions/DQActionComponents'

export const ManageAssessments = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const [assessments, setAssessments] = useState([])
    const [loading, setLoading] = useState(true)
    const [successMessage, setSuccessMessage] = useState(null)
    
    // DQ Action Modals State
    const [dqModals, setDqModals] = useState({
        dataQualityCheck: { isOpen: false, assessment: null },
        completenessAnalysis: { isOpen: false, assessment: null },
        consistencyAnalysis: { isOpen: false, assessment: null },
        outlierDetection: { isOpen: false, assessment: null },
        assessmentSettings: { isOpen: false, assessment: null }
    })

    // Load saved assessments from localStorage (in real app, this would be from API)
    useEffect(() => {
        const loadAssessments = () => {
            try {
                const saved = localStorage.getItem('dqa360_assessments')
                if (saved) {
                    const parsedAssessments = JSON.parse(saved)
                    setAssessments(parsedAssessments)
                } else {
                    // Add sample data for demonstration
                    const sampleAssessments = [
                        {
                            id: 'sample-1',
                            name: 'Monthly Health Facility Assessment',
                            description: 'Comprehensive monthly data quality assessment for health facilities in the district',
                            startDate: '2024-01-01',
                            endDate: '2024-12-31',
                            assessmentType: 'routine',
                            frequency: 'monthly',
                            priority: 'high',
                            status: 'active',
                            sourceDataSet: {
                                id: 'ds-001',
                                name: 'Health Facility Monthly Report'
                            },
                            dhis2Config: {
                                baseUrl: 'https://demo.dhis2.org',
                                username: 'admin'
                            },
                            dataElements: [
                                { id: 'de-001', name: 'Total Patients' },
                                { id: 'de-002', name: 'Outpatient Visits' },
                                { id: 'de-003', name: 'Inpatient Admissions' }
                            ],
                            organisationUnits: [
                                { id: 'ou-001', name: 'District Hospital A' },
                                { id: 'ou-002', name: 'Health Center B' },
                                { id: 'ou-003', name: 'Clinic C' }
                            ],
                            statistics: {
                                totalDataElements: 15,
                                totalOrgUnits: 8,
                                expectedReports: 32,
                                completedReports: 28
                            },
                            createdAt: '2024-01-15T10:30:00Z',
                            updatedAt: '2024-03-20T14:45:00Z',
                            createdBy: 'admin'
                        },
                        {
                            id: 'sample-2',
                            name: 'Quarterly Immunization Review',
                            description: 'Quarterly assessment of immunization data quality and coverage',
                            startDate: '2024-01-01',
                            endDate: '2024-03-31',
                            assessmentType: 'special',
                            frequency: 'quarterly',
                            priority: 'critical',
                            status: 'completed',
                            sourceDataSet: {
                                id: 'ds-002',
                                name: 'Immunization Dataset'
                            },
                            dhis2Config: {
                                baseUrl: 'https://demo.dhis2.org',
                                username: 'admin'
                            },
                            dataElements: [
                                { id: 'de-004', name: 'BCG Doses' },
                                { id: 'de-005', name: 'DPT Doses' },
                                { id: 'de-006', name: 'Measles Doses' }
                            ],
                            organisationUnits: [
                                { id: 'ou-004', name: 'Regional Hospital' },
                                { id: 'ou-005', name: 'Community Health Center' }
                            ],
                            statistics: {
                                totalDataElements: 12,
                                totalOrgUnits: 5,
                                expectedReports: 20,
                                completedReports: 20
                            },
                            createdAt: '2024-01-01T08:00:00Z',
                            updatedAt: '2024-03-31T16:30:00Z',
                            createdBy: 'data_manager'
                        },
                        {
                            id: 'sample-3',
                            name: 'Emergency Response Assessment',
                            description: 'Rapid assessment for emergency health response data validation',
                            startDate: '2024-03-15',
                            endDate: '2024-04-15',
                            assessmentType: 'emergency',
                            frequency: 'adhoc',
                            priority: 'critical',
                            status: 'draft',
                            sourceDataSet: {
                                id: 'ds-003',
                                name: 'Emergency Response Dataset'
                            },
                            dhis2Config: {
                                baseUrl: 'https://emergency.dhis2.org',
                                username: 'emergency_user'
                            },
                            dataElements: [
                                { id: 'de-007', name: 'Emergency Cases' },
                                { id: 'de-008', name: 'Referrals' }
                            ],
                            organisationUnits: [
                                { id: 'ou-006', name: 'Emergency Response Unit' }
                            ],
                            statistics: {
                                totalDataElements: 8,
                                totalOrgUnits: 3,
                                expectedReports: 12,
                                completedReports: 0
                            },
                            createdAt: '2024-03-15T12:00:00Z',
                            updatedAt: '2024-03-15T12:00:00Z',
                            createdBy: 'emergency_coordinator'
                        }
                    ]
                    setAssessments(sampleAssessments)
                    localStorage.setItem('dqa360_assessments', JSON.stringify(sampleAssessments))
                }
            } catch (error) {
                console.error('Error loading assessments:', error)
            } finally {
                setLoading(false)
            }
        }

        loadAssessments()

        // Check for success message from navigation state
        if (location.state?.message) {
            setSuccessMessage(location.state.message)
            // Clear the state to prevent showing message on refresh
            window.history.replaceState({}, document.title)
            // Auto-hide success message after 5 seconds
            setTimeout(() => setSuccessMessage(null), 5000)
        }
    }, [location.state])

    // Save assessments to localStorage
    const saveAssessments = (updatedAssessments) => {
        try {
            localStorage.setItem('dqa360_assessments', JSON.stringify(updatedAssessments))
            setAssessments(updatedAssessments)
        } catch (error) {
            console.error('Error saving assessments:', error)
        }
    }

    // Handle navigation to create assessment page
    const handleCreateAssessment = () => {
        navigate('/manage-assessments/create')
    }

    // Handle assessment deletion
    const handleDeleteAssessment = (assessmentId) => {
        if (confirm(i18n.t('Are you sure you want to delete this assessment? This action cannot be undone.'))) {
            const updatedAssessments = assessments.filter(a => a.id !== assessmentId)
            saveAssessments(updatedAssessments)
        }
    }

    // DQ Modal Management
    const openDQModal = (modalType, assessment) => {
        setDqModals(prev => ({
            ...prev,
            [modalType]: { isOpen: true, assessment }
        }))
    }

    const closeDQModal = (modalType) => {
        setDqModals(prev => ({
            ...prev,
            [modalType]: { isOpen: false, assessment: null }
        }))
    }

    // Handle assessment settings save
    const handleAssessmentSettingsSave = (assessmentId, newSettings) => {
        const updatedAssessments = assessments.map(assessment => 
            assessment.id === assessmentId 
                ? { ...assessment, ...newSettings, updatedAt: new Date().toISOString() }
                : assessment
        )
        saveAssessments(updatedAssessments)
    }

    // Get status tag color
    const getStatusColor = (status) => {
        switch (status) {
            case 'active': return 'positive'
            case 'completed': return 'neutral'
            case 'draft': return 'default'
            case 'error': return 'negative'
            default: return 'default'
        }
    }

    // DQ Actions for each assessment
    const getDQActions = (assessment) => [
        {
            label: i18n.t('View Assessment'),
            icon: <IconView24 />,
            onClick: () => console.log('View assessment:', assessment.id)
        },
        {
            label: i18n.t('Edit Configuration'),
            icon: <IconEdit24 />,
            onClick: () => console.log('Edit assessment:', assessment.id)
        },
        { type: 'divider' },
        {
            label: i18n.t('🔍 Data Quality Check'),
            onClick: () => openDQModal('dataQualityCheck', assessment)
        },
        {
            label: i18n.t('📊 Completeness Analysis'),
            onClick: () => openDQModal('completenessAnalysis', assessment)
        },
        {
            label: i18n.t('🔄 Consistency Analysis'),
            onClick: () => openDQModal('consistencyAnalysis', assessment)
        },
        {
            label: i18n.t('⚠️ Outlier Detection'),
            onClick: () => openDQModal('outlierDetection', assessment)
        },
        {
            label: i18n.t('📈 Trend Analysis'),
            onClick: () => console.log('Trend Analysis:', assessment.id)
        },
        {
            label: i18n.t('🎯 Accuracy Assessment'),
            onClick: () => console.log('Accuracy Assessment:', assessment.id)
        },
        {
            label: i18n.t('⏱️ Timeliness Check'),
            onClick: () => console.log('Timeliness Check:', assessment.id)
        },
        { type: 'divider' },
        {
            label: i18n.t('📤 Export DQ Report'),
            icon: <IconDownload24 />,
            onClick: () => console.log('Export DQ Report:', assessment.id)
        },
        {
            label: i18n.t('📥 Import Corrections'),
            icon: <IconUpload24 />,
            onClick: () => console.log('Import Corrections:', assessment.id)
        },
        {
            label: i18n.t('🔄 Sync with DHIS2'),
            onClick: () => console.log('Sync with DHIS2:', assessment.id)
        },
        {
            label: i18n.t('📋 Generate Summary'),
            onClick: () => console.log('Generate Summary:', assessment.id)
        },
        { type: 'divider' },
        {
            label: i18n.t('Assessment Settings'),
            icon: <IconSettings24 />,
            onClick: () => openDQModal('assessmentSettings', assessment)
        },
        {
            label: i18n.t('Delete Assessment'),
            icon: <IconDelete24 />,
            destructive: true,
            onClick: () => handleDeleteAssessment(assessment.id)
        }
    ]

    if (loading) {
        return (
            <Box padding="16px">
                <Card>
                    <Box padding="16px">
                        {i18n.t('Loading assessments...')}
                    </Box>
                </Card>
            </Box>
        )
    }

    return (
        <Box>
            {/* Success Message */}
            {successMessage && (
                <Box marginBottom="16px">
                    <NoticeBox valid title={i18n.t('Success')}>
                        {successMessage}
                    </NoticeBox>
                </Box>
            )}

            {/* Header */}
            <Box marginBottom="24px" display="flex" justifyContent="space-between" alignItems="center">
                <Box>
                    <h1 style={{ margin: 0, fontSize: '24px', fontWeight: '500' }}>
                        {i18n.t('Manage Assessments')}
                    </h1>
                    <p style={{ margin: '8px 0 0 0', color: '#666', fontSize: '14px' }}>
                        {i18n.t('Create, configure, and manage your data quality assessments')}
                    </p>
                </Box>
                <Button 
                    primary 
                    icon={<IconAdd24 />}
                    onClick={handleCreateAssessment}
                >
                    {i18n.t('Create New Assessment')}
                </Button>
            </Box>

            {/* Assessments List */}
            <Card>
                {assessments.length === 0 ? (
                    <Box padding="32px" textAlign="center">
                        <Box marginBottom="16px">
                            <h3 style={{ margin: 0, color: '#666' }}>
                                {i18n.t('No assessments created yet')}
                            </h3>
                        </Box>
                        <Box marginBottom="24px">
                            <p style={{ margin: 0, color: '#888', fontSize: '14px' }}>
                                {i18n.t('Get started by creating your first data quality assessment. Connect to DHIS2, select datasets, and configure your assessment tools.')}
                            </p>
                        </Box>
                        <Button 
                            primary 
                            icon={<IconAdd24 />}
                            onClick={handleCreateAssessment}
                        >
                            {i18n.t('Create Your First Assessment')}
                        </Button>
                    </Box>
                ) : (
                    <DataTable>
                        <DataTableHead>
                            <DataTableRow>
                                <DataTableColumnHeader>{i18n.t('Assessment Details')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Period')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Type & Priority')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Status')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Data Configuration')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Progress')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Created')}</DataTableColumnHeader>
                                <DataTableColumnHeader>{i18n.t('Actions')}</DataTableColumnHeader>
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableBody>
                            {assessments.map((assessment) => (
                                <DataTableRow key={assessment.id}>
                                    {/* Assessment Details */}
                                    <DataTableCell>
                                        <Box>
                                            <div style={{ fontWeight: '600', fontSize: '14px' }}>{assessment.name}</div>
                                            {assessment.description && (
                                                <div style={{ fontSize: '12px', color: '#666', marginTop: '2px' }}>
                                                    {assessment.description}
                                                </div>
                                            )}
                                            <div style={{ fontSize: '11px', color: '#999', marginTop: '4px' }}>
                                                ID: {assessment.id}
                                            </div>
                                        </Box>
                                    </DataTableCell>

                                    {/* Period */}
                                    <DataTableCell>
                                        <Box>
                                            {assessment.startDate && assessment.endDate ? (
                                                <>
                                                    <div style={{ fontSize: '12px', fontWeight: '500' }}>
                                                        {new Date(assessment.startDate).toLocaleDateString()} - {new Date(assessment.endDate).toLocaleDateString()}
                                                    </div>
                                                    <div style={{ fontSize: '11px', color: '#666', marginTop: '2px' }}>
                                                        {assessment.frequency || 'Not specified'}
                                                    </div>
                                                </>
                                            ) : (
                                                <span style={{ color: '#999', fontSize: '12px' }}>No period set</span>
                                            )}
                                        </Box>
                                    </DataTableCell>

                                    {/* Type & Priority */}
                                    <DataTableCell>
                                        <Box>
                                            <Tag neutral style={{ marginBottom: '4px' }}>
                                                {assessment.assessmentType || 'routine'}
                                            </Tag>
                                            <br />
                                            <Tag 
                                                positive={assessment.priority === 'low'}
                                                neutral={assessment.priority === 'medium'}
                                                negative={assessment.priority === 'high' || assessment.priority === 'critical'}
                                                style={{ fontSize: '10px' }}
                                            >
                                                {assessment.priority || 'medium'} priority
                                            </Tag>
                                        </Box>
                                    </DataTableCell>

                                    {/* Status */}
                                    <DataTableCell>
                                        <Tag positive={getStatusColor(assessment.status) === 'positive'} 
                                             neutral={getStatusColor(assessment.status) === 'neutral'}
                                             negative={getStatusColor(assessment.status) === 'negative'}>
                                            {assessment.status?.toUpperCase() || 'UNKNOWN'}
                                        </Tag>
                                    </DataTableCell>

                                    {/* Data Configuration */}
                                    <DataTableCell>
                                        <Box>
                                            <div style={{ fontSize: '12px', fontWeight: '500' }}>
                                                {assessment.sourceDataSet?.name || 'Unknown Dataset'}
                                            </div>
                                            <div style={{ fontSize: '11px', color: '#666', marginTop: '2px' }}>
                                                {assessment.statistics?.totalDataElements || assessment.dataElements?.length || 0} data elements
                                            </div>
                                            <div style={{ fontSize: '11px', color: '#666' }}>
                                                {assessment.statistics?.totalOrgUnits || assessment.organisationUnits?.length || 0} org units
                                            </div>
                                        </Box>
                                    </DataTableCell>

                                    {/* Progress */}
                                    <DataTableCell>
                                        <Box>
                                            {assessment.statistics ? (
                                                <>
                                                    <div style={{ fontSize: '12px', fontWeight: '500' }}>
                                                        {assessment.statistics.completedReports || 0} / {assessment.statistics.expectedReports || 0}
                                                    </div>
                                                    <div style={{ fontSize: '11px', color: '#666' }}>
                                                        {Math.round(((assessment.statistics.completedReports || 0) / (assessment.statistics.expectedReports || 1)) * 100)}% complete
                                                    </div>
                                                </>
                                            ) : (
                                                <span style={{ color: '#999', fontSize: '12px' }}>Not started</span>
                                            )}
                                        </Box>
                                    </DataTableCell>

                                    {/* Created */}
                                    <DataTableCell>
                                        <Box>
                                            <div style={{ fontSize: '12px' }}>
                                                {new Date(assessment.createdAt).toLocaleDateString()}
                                            </div>
                                            <div style={{ fontSize: '11px', color: '#666' }}>
                                                by {assessment.createdBy || 'Unknown'}
                                            </div>
                                        </Box>
                                    </DataTableCell>
                                    <DataTableCell>
                                        <DropdownButton
                                            component={
                                                <FlyoutMenu>
                                                    {getDQActions(assessment).map((action, index) => 
                                                        action.type === 'divider' ? (
                                                            <Divider key={index} />
                                                        ) : (
                                                            <MenuItem
                                                                key={index}
                                                                label={action.label}
                                                                icon={action.icon}
                                                                destructive={action.destructive}
                                                                onClick={action.onClick}
                                                            />
                                                        )
                                                    )}
                                                </FlyoutMenu>
                                            }
                                        >
                                            {i18n.t('Actions')}
                                        </DropdownButton>
                                    </DataTableCell>
                                </DataTableRow>
                            ))}
                        </DataTableBody>
                    </DataTable>
                )}
            </Card>



            {/* DQ Action Modals */}
            <DataQualityCheckModal
                assessment={dqModals.dataQualityCheck.assessment}
                isOpen={dqModals.dataQualityCheck.isOpen}
                onClose={() => closeDQModal('dataQualityCheck')}
            />

            <CompletenessAnalysisModal
                assessment={dqModals.completenessAnalysis.assessment}
                isOpen={dqModals.completenessAnalysis.isOpen}
                onClose={() => closeDQModal('completenessAnalysis')}
            />

            <AssessmentSettingsModal
                assessment={dqModals.assessmentSettings.assessment}
                isOpen={dqModals.assessmentSettings.isOpen}
                onClose={() => closeDQModal('assessmentSettings')}
                onSave={(settings) => {
                    if (dqModals.assessmentSettings.assessment) {
                        handleAssessmentSettingsSave(dqModals.assessmentSettings.assessment.id, settings)
                    }
                }}
            />
        </Box>
    )
}