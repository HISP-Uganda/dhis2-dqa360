import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Input,
    CircularLoader,
    NoticeBox,
    Tag,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    Checkbox,
    Tab,
    TabBar
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { DHIS2Configuration } from '../Metadata/DHIS2Configuration'
import { AssessmentDataSetSelection } from '../../components/AssessmentDataSetSelection'
import { OrganisationUnitManagement } from '../Metadata/OrganisationUnitManagement'

export const CreateAssessmentPage = () => {
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState('details')
    const [loading, setLoading] = useState(false)

    // Assessment data state
    const [assessmentData, setAssessmentData] = useState({
        name: '',
        description: '',
        assessmentType: 'baseline',
        priority: 'medium',
        frequency: 'monthly',
        startDate: '',
        endDate: '',
        notifications: true,
        autoSync: false,
        baselineAssessmentId: null
    })

    // Configuration states
    const [dhis2Config, setDhis2Config] = useState(null)
    const [selectedDataSet, setSelectedDataSet] = useState(null)
    const [selectedDataElements, setSelectedDataElements] = useState([])
    const [selectedOrgUnits, setSelectedOrgUnits] = useState([])
    
    // Baseline assessment states
    const [baselineAssessments, setBaselineAssessments] = useState([])
    const [loadingBaselines, setLoadingBaselines] = useState(false)

    // Tab configuration
    const tabs = [
        {
            id: 'details',
            title: i18n.t('Assessment Details'),
            label: i18n.t('Assessment Details')
        },
        {
            id: 'connection',
            title: i18n.t('DHIS2 Connection'),
            label: i18n.t('DHIS2 Connection')
        },
        {
            id: 'datasets',
            title: i18n.t('Select Datasets'),
            label: i18n.t('Select Datasets')
        },
        {
            id: 'dataelements',
            title: i18n.t('Select Data Elements'),
            label: i18n.t('Select Data Elements')
        },
        {
            id: 'reportingunits',
            title: i18n.t('Select Reporting Units'),
            label: i18n.t('Select Reporting Units')
        },
        {
            id: 'review',
            title: i18n.t('Review and Save'),
            label: i18n.t('Review and Save')
        }
    ]

    // Options data
    const assessmentTypes = [
        { value: 'baseline', label: i18n.t('Baseline Assessment') },
        { value: 'followup', label: i18n.t('Follow-up Assessment') },
        { value: 'routine', label: i18n.t('Routine Assessment') },
        { value: 'emergency', label: i18n.t('Emergency Response') },
        { value: 'quarterly', label: i18n.t('Quarterly Review') },
        { value: 'annual', label: i18n.t('Annual Evaluation') }
    ]

    const priorities = [
        { value: 'low', label: i18n.t('Low Priority') },
        { value: 'medium', label: i18n.t('Medium Priority') },
        { value: 'high', label: i18n.t('High Priority') },
        { value: 'critical', label: i18n.t('Critical Priority') }
    ]

    const frequencies = [
        { value: 'daily', label: i18n.t('Daily') },
        { value: 'weekly', label: i18n.t('Weekly') },
        { value: 'monthly', label: i18n.t('Monthly') },
        { value: 'quarterly', label: i18n.t('Quarterly') },
        { value: 'annually', label: i18n.t('Annually') }
    ]

    // Navigation handlers
    const handleTabChange = (tabId) => {
        setActiveTab(tabId)
    }

    const getTabIndex = (tabId) => {
        return tabs.findIndex(tab => tab.id === tabId)
    }

    const handleNext = () => {
        const currentIndex = getTabIndex(activeTab)
        if (currentIndex < tabs.length - 1) {
            setActiveTab(tabs[currentIndex + 1].id)
        }
    }

    const handlePrevious = () => {
        const currentIndex = getTabIndex(activeTab)
        if (currentIndex > 0) {
            setActiveTab(tabs[currentIndex - 1].id)
        }
    }

    const handleCancel = () => {
        navigate('/manage-assessments')
    }

    // Fetch baseline assessments for follow-up selection
    const fetchBaselineAssessments = async () => {
        setLoadingBaselines(true)
        try {
            // Mock data for now - replace with actual API call
            const mockBaselines = [
                {
                    id: 'baseline-1',
                    name: 'Q1 2024 Baseline Assessment',
                    createdDate: '2024-01-15',
                    status: 'completed'
                },
                {
                    id: 'baseline-2', 
                    name: 'Annual Health System Baseline',
                    createdDate: '2024-02-01',
                    status: 'completed'
                },
                {
                    id: 'baseline-3',
                    name: 'District Performance Baseline',
                    createdDate: '2024-03-10',
                    status: 'completed'
                }
            ]
            
            setBaselineAssessments(mockBaselines)
        } catch (error) {
            console.error('Error fetching baseline assessments:', error)
        } finally {
            setLoadingBaselines(false)
        }
    }

    // Load baseline assessments when assessment type changes to follow-up
    React.useEffect(() => {
        if (assessmentData.assessmentType === 'followup') {
            fetchBaselineAssessments()
        }
    }, [assessmentData.assessmentType])

    // Create assessment handler
    const handleCreateAssessment = async () => {
        setLoading(true)
        
        try {
            // Simulate assessment creation
            await new Promise(resolve => setTimeout(resolve, 2000))
            
            // Navigate back with success message
            navigate('/manage-assessments', { 
                state: { 
                    message: i18n.t('Assessment "{{name}}" created successfully!', { name: assessmentData.name }),
                    type: 'success'
                }
            })
        } catch (error) {
            console.error('Error creating assessment:', error)
        } finally {
            setLoading(false)
        }
    }

    // Tab validation
    const isTabValid = (tabId) => {
        switch (tabId) {
            case 'details':
                const basicValid = assessmentData.name.trim() && assessmentData.startDate && assessmentData.endDate
                // For follow-up assessments, also require baseline selection
                if (assessmentData.assessmentType === 'followup') {
                    return basicValid && assessmentData.baselineAssessmentId
                }
                return basicValid
            case 'connection':
                return dhis2Config?.configured || true // Allow skipping for demo
            case 'datasets':
                return selectedDataSet || true // Allow skipping for demo
            case 'dataelements':
                return selectedDataElements.length > 0 || true // Allow skipping for demo
            case 'reportingunits':
                return selectedOrgUnits.length > 0 || true // Allow skipping for demo
            case 'review':
                return true
            default:
                return false
        }
    }

    // Tab content renderer
    const renderTabContent = () => {
        const currentTab = tabs.find(tab => tab.id === activeTab)
        
        return (
            <Box>
                {/* Tab Header with Navigation */}
                <Box 
                    padding="24px 32px" 
                    style={{
                        borderBottom: '1px solid #e9ecef',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}
                >
                    <h2 style={{ 
                        margin: '0', 
                        fontSize: '24px', 
                        fontWeight: '600',
                        color: '#2c3e50'
                    }}>
                        {currentTab?.title}
                    </h2>
                    
                    {/* Navigation Buttons */}
                    <Box display="flex" alignItems="center" style={{ gap: '12px' }}>
                        {getTabIndex(activeTab) > 0 && (
                            <Button 
                                secondary 
                                onClick={handlePrevious} 
                                disabled={loading}
                                style={{
                                    padding: '8px 16px',
                                    fontWeight: '500',
                                    borderRadius: '6px',
                                    fontSize: '14px'
                                }}
                            >
                                ← {i18n.t('Previous')}
                            </Button>
                        )}
                        
                        {activeTab !== 'review' ? (
                            <Button 
                                primary 
                                onClick={handleNext} 
                                disabled={!isTabValid(activeTab) || loading}
                                style={{
                                    padding: '8px 16px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px'
                                }}
                            >
                                {i18n.t('Next')} →
                            </Button>
                        ) : (
                            <Button 
                                primary 
                                onClick={handleCreateAssessment} 
                                disabled={loading}
                                style={{
                                    padding: '8px 20px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px'
                                }}
                            >
                                {loading ? (
                                    <>
                                        <CircularLoader small /> {i18n.t('Creating...')}
                                    </>
                                ) : (
                                    <>
                                        💾 {i18n.t('Save')}
                                    </>
                                )}
                            </Button>
                        )}
                        
                        {/* Cancel Button */}
                        <Button 
                            onClick={handleCancel}
                            style={{
                                backgroundColor: '#dc3545',
                                color: 'white',
                                border: 'none',
                                padding: '8px 16px',
                                borderRadius: '6px',
                                fontSize: '14px',
                                fontWeight: '500'
                            }}
                        >
                            ✕ {i18n.t('Cancel')}
                        </Button>
                    </Box>
                </Box>

                {/* Full Screen Tab Content */}
                {renderTabSpecificContent()}
            </Box>
        )
    }

    const renderTabSpecificContent = () => {
        switch (activeTab) {
            case 'details':
                return (
                    <div style={{ 
                        padding: '32px 40px',
                        maxWidth: '1200px',
                        margin: '0 auto'
                    }}>
                        {/* Clean Form Layout */}
                        <div style={{ 
                            display: 'grid',
                            gap: '24px'
                        }}>
                            {/* Assessment Name */}
                            <div style={{ 
                                padding: '24px',
                                border: '1px solid #e9ecef',
                                borderRadius: '8px'
                            }}>
                                <InputField
                                    label={i18n.t('Assessment Name')}
                                    name="name"
                                    value={assessmentData.name}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, name: value }))}
                                    placeholder={i18n.t('Enter a descriptive name for your assessment')}
                                    required
                                    helpText={i18n.t('Choose a clear, descriptive name that identifies the purpose')}
                                />
                            </div>

                            {/* Assessment Type and Priority Row */}
                            <div style={{ 
                                display: 'grid',
                                gridTemplateColumns: '1fr 1fr',
                                gap: '24px'
                            }}>
                                <div style={{ 
                                    padding: '24px',
                                    border: '1px solid #e9ecef',
                                    borderRadius: '8px'
                                }}>
                                    <SingleSelectField
                                        label={i18n.t('Assessment Type')}
                                        selected={assessmentData.assessmentType}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, assessmentType: selected }))}
                                        helpText={i18n.t('Select the type based on your data quality needs')}
                                    >
                                        {assessmentTypes.map(type => (
                                            <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                                        ))}
                                    </SingleSelectField>
                                </div>

                                <div style={{ 
                                    padding: '24px',
                                    border: '1px solid #e9ecef',
                                    borderRadius: '8px'
                                }}>
                                    <SingleSelectField
                                        label={i18n.t('Priority Level')}
                                        selected={assessmentData.priority}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, priority: selected }))}
                                        helpText={i18n.t('Set the priority level for this assessment')}
                                    >
                                        {priorities.map(priority => (
                                            <SingleSelectOption key={priority.value} value={priority.value} label={priority.label} />
                                        ))}
                                    </SingleSelectField>
                                </div>
                            </div>

                            {/* Description */}
                            <div style={{ 
                                padding: '24px',
                                border: '1px solid #e9ecef',
                                borderRadius: '8px'
                            }}>
                                <TextAreaField
                                    label={i18n.t('Description')}
                                    name="description"
                                    value={assessmentData.description}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, description: value }))}
                                    placeholder={i18n.t('Provide a detailed description of this assessment')}
                                    rows={4}
                                    helpText={i18n.t('Describe the objectives, scope, and expected outcomes')}
                                />
                            </div>

                            {/* Date Range */}
                            <div style={{ 
                                display: 'grid',
                                gridTemplateColumns: '1fr 1fr',
                                gap: '24px'
                            }}>
                                <div style={{ 
                                    padding: '24px',
                                    border: '1px solid #e9ecef',
                                    borderRadius: '8px'
                                }}>
                                    <InputField
                                        label={i18n.t('Start Date')}
                                        name="startDate"
                                        type="date"
                                        value={assessmentData.startDate}
                                        onChange={({ value }) => setAssessmentData(prev => ({ ...prev, startDate: value }))}
                                        required
                                        helpText={i18n.t('Assessment period start date')}
                                    />
                                </div>

                                <div style={{ 
                                    padding: '24px',
                                    border: '1px solid #e9ecef',
                                    borderRadius: '8px'
                                }}>
                                    <InputField
                                        label={i18n.t('End Date')}
                                        name="endDate"
                                        type="date"
                                        value={assessmentData.endDate}
                                        onChange={({ value }) => setAssessmentData(prev => ({ ...prev, endDate: value }))}
                                        required
                                        helpText={i18n.t('Assessment period end date')}
                                    />
                                </div>
                            </div>

                            {/* Baseline Assessment (if follow-up type) */}
                            {assessmentData.assessmentType === 'followup' && (
                                <div style={{ 
                                    padding: '24px',
                                    border: '2px solid #007bff',
                                    borderRadius: '8px'
                                }}>
                                    <SingleSelectField
                                        label={i18n.t('Baseline Assessment')}
                                        selected={assessmentData.baselineAssessmentId}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, baselineAssessmentId: selected }))}
                                        helpText={i18n.t('Select the baseline assessment to compare against')}
                                        required
                                    >
                                        <SingleSelectOption value="" label={i18n.t('Select baseline assessment')} />
                                        {baselineAssessments.map(baseline => (
                                            <SingleSelectOption 
                                                key={baseline.id} 
                                                value={baseline.id} 
                                                label={`${baseline.name} (${baseline.startDate} - ${baseline.endDate})`} 
                                            />
                                        ))}
                                    </SingleSelectField>
                                </div>
                            )}

                            {/* Assessment Type Information */}
                            {assessmentData.assessmentType && (
                                <div style={{ 
                                    padding: '20px',
                                    border: `2px solid ${assessmentData.assessmentType === 'baseline' ? '#28a745' : '#ffc107'}`,
                                    borderRadius: '8px'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 12px 0',
                                        color: assessmentData.assessmentType === 'baseline' ? '#28a745' : '#856404',
                                        fontSize: '16px',
                                        fontWeight: '600'
                                    }}>
                                        {assessmentData.assessmentType === 'baseline' ? '📊 Baseline Assessment' : '📈 Follow-up Assessment'}
                                    </h4>
                                    <p style={{ 
                                        margin: 0,
                                        fontSize: '14px',
                                        color: '#666',
                                        lineHeight: '1.5'
                                    }}>
                                        {assessmentData.assessmentType === 'baseline' 
                                            ? 'This will establish the initial data quality baseline for future comparisons and improvements.'
                                            : 'This assessment will compare current data quality against the selected baseline to measure improvements.'
                                        }
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                }}>
                                    <InputField
                                        label={i18n.t('Description')}
                                        name="description"
                                        value={assessmentData.description}
                                        onChange={({ value }) => setAssessmentData(prev => ({ ...prev, description: value }))}
                                        placeholder={i18n.t('Describe the purpose, scope, and objectives of this assessment...')}
                                        multiline
                                        rows={4}
                                        helpText={i18n.t('Provide details about what this assessment will evaluate')}
                                    />
                                </Card>

                                {/* Assessment Period - 2 Column */}
                                <Card style={{ 
                                    padding: '32px', 
                                    border: 'none', 
                                    borderRadius: '12px',
                                    marginBottom: '32px',
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 24px 0', 
                                        fontSize: '18px', 
                                        fontWeight: '600',
                                        color: '#2c3e50',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        📅 {i18n.t('Assessment Period')}
                                    </h4>
                                    
                                    <div style={{ 
                                        display: 'flex', 
                                        gap: '24px', 
                                        marginBottom: '24px' 
                                    }}>
                                        <div style={{ flex: 1 }}>
                                            <label style={{ 
                                                display: 'block', 
                                                marginBottom: '12px', 
                                                fontWeight: '600', 
                                                color: '#495057',
                                                fontSize: '14px'
                                            }}>
                                                {i18n.t('Start Date')} *
                                            </label>
                                            <Input
                                                type="date"
                                                value={assessmentData.startDate}
                                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, startDate: value }))}
                                                style={{ width: '100%' }}
                                            />
                                            <p style={{ 
                                                margin: '8px 0 0 0', 
                                                fontSize: '12px', 
                                                color: '#6c757d',
                                                fontStyle: 'italic'
                                            }}>
                                                {i18n.t('When data collection begins')}
                                            </p>
                                        </div>
                                        <div style={{ flex: 1 }}>
                                            <label style={{ 
                                                display: 'block', 
                                                marginBottom: '12px', 
                                                fontWeight: '600', 
                                                color: '#495057',
                                                fontSize: '14px'
                                            }}>
                                                {i18n.t('End Date')} *
                                            </label>
                                            <Input
                                                type="date"
                                                value={assessmentData.endDate}
                                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, endDate: value }))}
                                                style={{ width: '100%' }}
                                            />
                                            <p style={{ 
                                                margin: '8px 0 0 0', 
                                                fontSize: '12px', 
                                                color: '#6c757d',
                                                fontStyle: 'italic'
                                            }}>
                                                {i18n.t('Assessment completion deadline')}
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <SingleSelectField
                                        label={i18n.t('Frequency')}
                                        selected={assessmentData.frequency}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, frequency: selected }))}
                                        helpText={i18n.t('How often will this assessment run?')}
                                    >
                                        {frequencies.map(freq => (
                                            <SingleSelectOption key={freq.value} value={freq.value} label={freq.label} />
                                        ))}
                                    </SingleSelectField>
                                </Card>
                            </div>

                            {/* Right Column - Settings & Options (40% width) */}
                            <div style={{ flex: '0 0 40%' }}>
                                {/* Assessment Settings */}
                                <Card style={{ 
                                    padding: '32px', 
                                    border: 'none', 
                                    borderRadius: '12px',
                                    marginBottom: '32px',
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 24px 0', 
                                        fontSize: '18px', 
                                        fontWeight: '600',
                                        color: '#2c3e50'
                                    }}>
                                        {i18n.t('Assessment Settings')}
                                    </h4>
                                    
                                    <Box style={{ marginBottom: '24px' }}>
                                        <SingleSelectField
                                            label={i18n.t('Priority Level')}
                                            selected={assessmentData.priority}
                                            onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, priority: selected }))}
                                            helpText={i18n.t('Set the urgency level for this assessment')}
                                        >
                                            {priorities.map(priority => (
                                                <SingleSelectOption key={priority.value} value={priority.value} label={priority.label} />
                                            ))}
                                        </SingleSelectField>
                                    </Box>

                                    {/* Assessment Type Info */}
                                    <Box style={{ 
                                        padding: '20px', 
                                        borderRadius: '8px',
                                        border: `2px solid ${assessmentData.assessmentType === 'baseline' ? '#bbdefb' : '#ffcc02'}`
                                    }}>
                                        <h5 style={{ 
                                            margin: '0 0 12px 0', 
                                            fontSize: '16px', 
                                            fontWeight: '600',
                                            color: assessmentData.assessmentType === 'baseline' ? '#1565c0' : '#f57c00'
                                        }}>
                                            {assessmentData.assessmentType === 'baseline' ? '📊 Baseline Assessment' : '📈 Follow-up Assessment'}
                                        </h5>
                                        <p style={{ 
                                            margin: 0, 
                                            fontSize: '14px', 
                                            color: '#666',
                                            lineHeight: '1.5'
                                        }}>
                                            {assessmentData.assessmentType === 'baseline' 
                                                ? i18n.t('Establishes initial data quality benchmark for future comparisons')
                                                : i18n.t('Measures improvements against a previous baseline assessment')
                                            }
                                        </p>
                                    </Box>
                                </Card>

                                {/* Assessment Options */}
                                <Card style={{ 
                                    padding: '32px', 
                                    border: 'none', 
                                    borderRadius: '12px',
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 24px 0', 
                                        fontSize: '18px', 
                                        fontWeight: '600',
                                        color: '#2c3e50',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        ⚙️ {i18n.t('Assessment Options')}
                                    </h4>
                                    <div style={{ 
                                        display: 'flex', 
                                        flexDirection: 'column',
                                        gap: '20px' 
                                    }}>
                                        <Checkbox
                                            label={i18n.t('Enable notifications')}
                                            checked={assessmentData.notifications}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, notifications: checked }))}
                                        />
                                        <Checkbox
                                            label={i18n.t('Auto-sync with DHIS2')}
                                            checked={assessmentData.autoSync}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, autoSync: checked }))}
                                        />
                                        <Checkbox
                                            label={i18n.t('Enable data validation alerts')}
                                            checked={assessmentData.validationAlerts || false}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, validationAlerts: checked }))}
                                        />
                                        <Checkbox
                                            label={i18n.t('Include historical comparison')}
                                            checked={assessmentData.historicalComparison || false}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, historicalComparison: checked }))}
                                        />
                                    </div>
                                </Card>
                            </div>
                        </div>

                        {/* Baseline Assessment Selection - Only show for follow-up assessments */}
                        {assessmentData.assessmentType === 'followup' && (
                            <Card style={{ 
                                padding: '20px', 
                                border: '1px solid #e9ecef', 
                                borderRadius: '8px', 
                                marginBottom: '24px'
                            }}>
                                <h4 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '16px', 
                                    fontWeight: '600',
                                    color: '#2c3e50'
                                }}>
                                    {i18n.t('Baseline Assessment')}
                                </h4>
                                <p style={{ 
                                    margin: '0 0 20px 0', 
                                    fontSize: '14px', 
                                    color: '#6c757d',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('Select the baseline assessment to compare improvements against. This enables tracking progress over time.')}
                                </p>
                                
                                {loadingBaselines ? (
                                    <Box display="flex" alignItems="center" style={{ gap: '12px' }}>
                                        <CircularLoader small />
                                        <span style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Loading baseline assessments...')}
                                        </span>
                                    </Box>
                                ) : baselineAssessments.length > 0 ? (
                                    <SingleSelectField
                                        label={i18n.t('Select Baseline Assessment')}
                                        selected={assessmentData.baselineAssessmentId}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, baselineAssessmentId: selected }))}
                                        placeholder={i18n.t('Choose a baseline assessment...')}
                                        required
                                        helpText={i18n.t('This follow-up will be compared against the selected baseline')}
                                    >
                                        {baselineAssessments.map(baseline => (
                                            <SingleSelectOption 
                                                key={baseline.id} 
                                                value={baseline.id} 
                                                label={`${baseline.name} (${baseline.createdDate})`} 
                                            />
                                        ))}
                                    </SingleSelectField>
                                ) : (
                                    <NoticeBox warning title={i18n.t('No Baseline Assessments Found')}>
                                        {i18n.t('No completed baseline assessments are available. You need to create and complete a baseline assessment first before creating a follow-up assessment.')}
                                    </NoticeBox>
                                )}
                            </Card>
                        )}

                        {/* Assessment Type Information */}
                        {assessmentData.assessmentType === 'baseline' && (
                            <Card style={{ 
                                padding: '20px', 
                                border: '1px solid #e3f2fd', 
                                borderRadius: '8px', 
                                marginBottom: '24px'
                            }}>
                                <Box display="flex" alignItems="center" style={{ gap: '12px', marginBottom: '12px' }}>
                                    <span style={{ fontSize: '20px' }}>📊</span>
                                    <h4 style={{ 
                                        margin: '0', 
                                        fontSize: '16px', 
                                        fontWeight: '600',
                                        color: '#1976d2'
                                    }}>
                                        {i18n.t('Baseline Assessment')}
                                    </h4>
                                </Box>
                                <p style={{ 
                                    margin: '0', 
                                    fontSize: '14px', 
                                    color: '#1565c0',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('This will establish the initial data quality benchmark. Future follow-up assessments can be compared against this baseline to track improvements over time.')}
                                </p>
                            </Card>
                        )}

                    </div>
                )

            case 'connection':
                return (
                    <Box style={{ maxWidth: '1000px', margin: '0 auto' }}>
                        <Box display="grid" style={{ gridTemplateColumns: '2fr 1fr', gap: '32px' }}>
                            {/* Left Column - Connection Configuration */}
                            <Box>
                                <DHIS2Configuration 
                                    onConfigured={(config) => {
                                        setDhis2Config(config)
                                    }}
                                />
                            </Box>
                            
                            {/* Right Column - Connection Info & Tips */}
                            <Box>
                                <Card style={{ 
                                    padding: '24px', 
                                    border: '1px solid #e9ecef', 
                                    borderRadius: '8px',
                                    height: 'fit-content'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 16px 0', 
                                        fontSize: '16px', 
                                        fontWeight: '600',
                                        color: '#2c3e50',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                    }}>
                                        💡 {i18n.t('Connection Tips')}
                                    </h4>
                                    
                                    <Box style={{ marginBottom: '20px' }}>
                                        <h5 style={{ 
                                            margin: '0 0 8px 0', 
                                            fontSize: '14px', 
                                            fontWeight: '600',
                                            color: '#495057'
                                        }}>
                                            {i18n.t('Required Permissions')}
                                        </h5>
                                        <ul style={{ 
                                            margin: '0', 
                                            paddingLeft: '16px',
                                            fontSize: '12px',
                                            color: '#666',
                                            lineHeight: '1.5'
                                        }}>
                                            <li>{i18n.t('Read access to datasets')}</li>
                                            <li>{i18n.t('Read access to data elements')}</li>
                                            <li>{i18n.t('Read access to organisation units')}</li>
                                            <li>{i18n.t('Create/update datasets (for assessment tools)')}</li>
                                        </ul>
                                    </Box>

                                    <Box style={{ marginBottom: '20px' }}>
                                        <h5 style={{ 
                                            margin: '0 0 8px 0', 
                                            fontSize: '14px', 
                                            fontWeight: '600',
                                            color: '#495057'
                                        }}>
                                            {i18n.t('Security Notes')}
                                        </h5>
                                        <p style={{ 
                                            margin: 0, 
                                            fontSize: '12px', 
                                            color: '#666',
                                            lineHeight: '1.4'
                                        }}>
                                            {i18n.t('Your credentials are encrypted and stored securely. They are only used for data fetching and assessment tool creation.')}
                                        </p>
                                    </Box>

                                    {dhis2Config && (
                                        <Box style={{ 
                                            padding: '12px', 
                                            border: '1px solid #c3e6cb',
                                            borderRadius: '6px'
                                        }}>
                                            <p style={{ 
                                                margin: '0 0 4px 0', 
                                                fontSize: '12px', 
                                                fontWeight: '600',
                                                color: '#155724'
                                            }}>
                                                ✅ {i18n.t('Connection Established')}
                                            </p>
                                            <p style={{ 
                                                margin: 0, 
                                                fontSize: '11px', 
                                                color: '#155724'
                                            }}>
                                                {dhis2Config.baseUrl}
                                            </p>
                                        </Box>
                                    )}
                                </Card>
                            </Box>
                        </Box>
                    </Box>
                )

            case 'datasets':
                return (
                    <Box style={{ maxWidth: '1000px', margin: '0 auto' }}>
                        <AssessmentDataSetSelection
                            dhis2Config={dhis2Config}
                            onDataSetSelected={setSelectedDataSet}
                            selectedDataSet={selectedDataSet}
                            mode="datasets"
                        />
                    </Box>
                )

            case 'dataelements':
                return (
                    <Box style={{ maxWidth: '1000px', margin: '0 auto' }}>
                        <AssessmentDataSetSelection
                            dhis2Config={dhis2Config}
                            selectedDataSet={selectedDataSet}
                            onDataElementsSelected={setSelectedDataElements}
                            selectedDataElements={selectedDataElements}
                            mode="dataelements"
                        />
                    </Box>
                )

            case 'reportingunits':
                return (
                    <Box style={{ maxWidth: '1000px', margin: '0 auto' }}>
                        <OrganisationUnitManagement
                            dhis2Config={dhis2Config}
                            selectedDataSet={selectedDataSet}
                            selectedDataElements={selectedDataElements}
                            onOrganisationUnitsSelected={setSelectedOrgUnits}
                            selectedOrganisationUnits={selectedOrgUnits}
                        />
                    </Box>
                )

            case 'review':
                return (
                    <Box style={{ maxWidth: '800px', margin: '0 auto' }}>
                        <Card style={{ 
                            padding: '24px', 
                            border: '1px solid #e9ecef', 
                            borderRadius: '8px'
                        }}>
                            <h3 style={{ 
                                margin: '0 0 32px 0', 
                                fontSize: '24px', 
                                fontWeight: '600',
                                color: '#2c3e50',
                                textAlign: 'center'
                            }}>
                                {i18n.t('Review and Save Assessment')}
                            </h3>
                            
                            <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '32px', marginBottom: '32px' }}>
                                <Box>
                                    <h4 style={{ margin: '0 0 16px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                        {i18n.t('Assessment Details')}
                                    </h4>
                                    <Box style={{ padding: '16px', border: '1px solid #e9ecef', borderRadius: '8px' }}>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Name')}:</strong> {assessmentData.name}</p>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Type')}:</strong> {assessmentTypes.find(t => t.value === assessmentData.assessmentType)?.label}</p>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Priority')}:</strong> {priorities.find(p => p.value === assessmentData.priority)?.label}</p>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Period')}:</strong> {assessmentData.startDate} to {assessmentData.endDate}</p>
                                        {assessmentData.assessmentType === 'followup' && assessmentData.baselineAssessmentId && (
                                            <p style={{ margin: 0 }}>
                                                <strong>{i18n.t('Baseline')}:</strong> {baselineAssessments.find(b => b.id === assessmentData.baselineAssessmentId)?.name}
                                            </p>
                                        )}
                                    </Box>
                                </Box>
                                <Box>
                                    <h4 style={{ margin: '0 0 16px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                        {i18n.t('Data Configuration')}
                                    </h4>
                                    <Box style={{ padding: '16px', border: '1px solid #e9ecef', borderRadius: '8px' }}>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('DHIS2 Instance')}:</strong> {dhis2Config?.baseUrl || 'Not configured'}</p>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Source Dataset')}:</strong> {selectedDataSet?.displayName || 'Not selected'}</p>
                                        <p style={{ margin: '0 0 8px 0' }}><strong>{i18n.t('Data Elements')}:</strong> {selectedDataElements.length} selected</p>
                                        <p style={{ margin: 0 }}><strong>{i18n.t('Reporting Units')}:</strong> {selectedOrgUnits.length} selected</p>
                                    </Box>
                                </Box>
                            </Box>

                            {/* Assessment Tools Creation Info */}
                            <Box style={{ marginBottom: '32px' }}>
                                <h4 style={{ margin: '0 0 16px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Assessment Tools to be Created')}
                                </h4>
                                <Box style={{ padding: '20px', border: '1px solid #e9ecef', borderRadius: '8px' }}>
                                    <p style={{ margin: '0 0 16px 0', color: '#1565c0', fontWeight: '500' }}>
                                        {i18n.t('The following 4 datasets will be automatically created in your DHIS2 instance:')}
                                    </p>
                                    <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                                        <Box style={{ padding: '12px', borderRadius: '6px', border: '1px solid #e9ecef' }}>
                                            <h5 style={{ margin: '0 0 8px 0', color: '#1976d2', fontSize: '14px', fontWeight: '600' }}>
                                                📊 {i18n.t('Completeness Dataset')}
                                            </h5>
                                            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
                                                {i18n.t('Tracks data completeness rates')}
                                            </p>
                                        </Box>
                                        <Box style={{ padding: '12px', borderRadius: '6px', border: '1px solid #e9ecef' }}>
                                            <h5 style={{ margin: '0 0 8px 0', color: '#1976d2', fontSize: '14px', fontWeight: '600' }}>
                                                🎯 {i18n.t('Accuracy Dataset')}
                                            </h5>
                                            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
                                                {i18n.t('Measures data accuracy and validation')}
                                            </p>
                                        </Box>
                                        <Box style={{ padding: '12px', borderRadius: '6px', border: '1px solid #e9ecef' }}>
                                            <h5 style={{ margin: '0 0 8px 0', color: '#1976d2', fontSize: '14px', fontWeight: '600' }}>
                                                ⏰ {i18n.t('Timeliness Dataset')}
                                            </h5>
                                            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
                                                {i18n.t('Monitors reporting timeliness')}
                                            </p>
                                        </Box>
                                        <Box style={{ padding: '12px', borderRadius: '6px', border: '1px solid #e9ecef' }}>
                                            <h5 style={{ margin: '0 0 8px 0', color: '#1976d2', fontSize: '14px', fontWeight: '600' }}>
                                                ✅ {i18n.t('Consistency Dataset')}
                                            </h5>
                                            <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
                                                {i18n.t('Evaluates data consistency patterns')}
                                            </p>
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>

                            {loading && (
                                <Box textAlign="center" marginTop="32px">
                                    <CircularLoader />
                                    <p style={{ marginTop: '16px', color: '#6c757d', fontSize: '16px' }}>
                                        {i18n.t('Creating assessment tools and configuring data quality checks...')}
                                    </p>
                                </Box>
                            )}
                        </Card>
                    </Box>
                )

            default:
                return null
        }
    }

    return (
        <Box style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
            {/* Clean Header */}
            <Box style={{ 
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                padding: '24px 32px'
            }}>
                <Box>
                    <h1 style={{ 
                        margin: '0 0 8px 0', 
                        fontSize: '28px', 
                        fontWeight: '600'
                    }}>
                        {i18n.t('Create New Assessment')}
                    </h1>
                    <p style={{ 
                        margin: 0, 
                        color: 'rgba(255,255,255,0.9)', 
                        fontSize: '16px',
                        fontWeight: '400'
                    }}>
                        {i18n.t('Build a comprehensive data quality assessment')}
                    </p>
                </Box>
            </Box>

            {/* Tab Navigation */}
            <Box style={{ backgroundColor: '#fff', borderBottom: '1px solid #e0e0e0' }}>
                <TabBar>
                    {tabs.map((tab) => (
                        <Tab 
                            key={tab.id}
                            selected={activeTab === tab.id}
                            onClick={() => handleTabChange(tab.id)}
                        >
                            {tab.label}
                        </Tab>
                    ))}
                </TabBar>
            </Box>

            {/* Full Screen Content Area */}
            <Box style={{ 
                flex: 1, 
                backgroundColor: '#f8f9fa',
                minHeight: 'calc(100vh - 200px)',
               padding: '0'
             }}>
                {renderTabContent()}
            </Box>

            {/* Clean Footer Actions */}
            <Box 
                style={{ 
                    borderTop: '1px solid #e0e0e0', 
                    padding: '24px 40px',
                    position: 'sticky',
                    bottom: 0
                }}
            >
                <Box display="flex" justifyContent="space-between" alignItems="center" style={{ maxWidth: '1400px', margin: '0 auto' }}>
                    <Box display="flex" alignItems="center" style={{ gap: '24px' }}>
                        <Tag 
                            positive={activeTab === 'review'}
                            neutral={activeTab !== 'review'}
                            style={{ fontSize: '14px', fontWeight: '500', padding: '8px 16px' }}
                        >
                            {tabs.find(tab => tab.id === activeTab)?.label}
                        </Tag>
                        {!isTabValid(activeTab) && activeTab !== 'review' && (
                            <p style={{ 
                                margin: 0, 
                                fontSize: '14px', 
                                color: '#dc3545',
                                fontWeight: '500'
                            }}>
                                Please complete all required fields to continue
                            </p>
                        )}
                    </Box>
                    
                    {/* Left Side - Cancel Button */}
                    <Button 
                        onClick={handleCancel}
                        disabled={loading}
                        style={{
                            backgroundColor: '#6c757d',
                            border: '1px solid #6c757d',
                            color: 'white',
                            fontWeight: '500',
                            padding: '10px 20px',
                            borderRadius: '6px',
                            fontSize: '14px',
                            minWidth: '100px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            transition: 'all 0.2s ease',
                            cursor: loading ? 'not-allowed' : 'pointer',
                            opacity: loading ? 0.7 : 1
                        }}
                    >
                        ✕ {i18n.t('Cancel')}
                    </Button>

                    {/* Right Side - Navigation Buttons */}
                    <ButtonStrip style={{ gap: '16px' }}>
                        {getTabIndex(activeTab) > 0 && (
                            <Button 
                                secondary 
                                onClick={handlePrevious} 
                                disabled={loading}
                                style={{
                                    padding: '10px 20px',
                                    fontWeight: '500',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#f8f9fa',
                                    border: '1px solid #dee2e6',
                                    color: '#495057',
                                    minWidth: '100px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    opacity: loading ? 0.7 : 1
                                }}
                            >
                                ← {i18n.t('Previous')}
                            </Button>
                        )}
                        
                        {activeTab !== 'review' ? (
                            <Button 
                                primary 
                                onClick={handleNext} 
                                disabled={!isTabValid(activeTab) || loading}
                                style={{
                                    padding: '10px 20px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#007bff',
                                    border: '1px solid #007bff',
                                    color: 'white',
                                    minWidth: '100px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: (!isTabValid(activeTab) || loading) ? 'not-allowed' : 'pointer',
                                    opacity: (!isTabValid(activeTab) || loading) ? 0.7 : 1
                                }}
                            >
                                {i18n.t('Next')} →
                            </Button>
                        ) : (
                            <Button 
                                primary 
                                onClick={handleCreateAssessment} 
                                disabled={loading}
                                style={{
                                    padding: '10px 24px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#28a745',
                                    border: '1px solid #28a745',
                                    color: 'white',
                                    minWidth: '140px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    opacity: loading ? 0.7 : 1
                                }}
                            >
                                {loading ? (
                                    <>
                                        <CircularLoader small /> {i18n.t('Creating...')}
                                    </>
                                ) : (
                                    <>
                                        💾 {i18n.t('Save Assessment')}
                                    </>
                                )}
                            </Button>
                        )}
                    </ButtonStrip>
                </Box>
            </Box>
        </Box>
    )
}