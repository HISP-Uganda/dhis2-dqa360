import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Input,
    CircularLoader,
    NoticeBox,
    Tag,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    Checkbox,
    Tab,
    TabBar
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { DHIS2Configuration } from '../Metadata/DHIS2Configuration'
import { AssessmentDataSetSelection } from '../../components/AssessmentDataSetSelection'
import { OrganisationUnitManagement } from '../Metadata/OrganisationUnitManagement'

export const CreateAssessmentPage = () => {
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState('details')
    const [loading, setLoading] = useState(false)

    // Assessment data state
    const [assessmentData, setAssessmentData] = useState({
        name: '',
        description: '',
        assessmentType: 'baseline',
        priority: 'medium',
        startDate: '',
        endDate: '',
        baselineAssessmentId: '',
        notifications: true,
        autoSync: true,
        validationAlerts: false,
        historicalComparison: false,
        // Additional assessment details
        objectives: '',
        scope: '',
        methodology: 'automated',
        frequency: 'monthly',
        reportingLevel: 'facility',
        dataQualityDimensions: ['completeness', 'timeliness'],
        stakeholders: '',
        expectedOutcomes: '',
        successCriteria: '',
        riskAssessment: '',
        budget: '',
        resources: '',
        timeline: '',
        approvalRequired: false,
        publicAccess: false,
        tags: [],
        customFields: {}
    })

    // Other state
    const [dhis2Config, setDhis2Config] = useState(null)
    const [selectedDataSet, setSelectedDataSet] = useState(null) // Keep for backward compatibility
    const [selectedDataSets, setSelectedDataSets] = useState([]) // New multi-select state
    const [selectedDataElements, setSelectedDataElements] = useState([])
    const [selectedOrgUnits, setSelectedOrgUnits] = useState([])
    const [baselineAssessments, setBaselineAssessments] = useState([])
    const [loadingBaselines, setLoadingBaselines] = useState(false)

    // Configuration data
    const assessmentTypes = [
        { value: 'baseline', label: i18n.t('Baseline Assessment') },
        { value: 'followup', label: i18n.t('Follow-up Assessment') }
    ]

    const priorities = [
        { value: 'low', label: i18n.t('Low Priority') },
        { value: 'medium', label: i18n.t('Medium Priority') },
        { value: 'high', label: i18n.t('High Priority') },
        { value: 'critical', label: i18n.t('Critical Priority') }
    ]

    const methodologies = [
        { value: 'automated', label: i18n.t('Automated Analysis') },
        { value: 'manual', label: i18n.t('Manual Review') },
        { value: 'hybrid', label: i18n.t('Hybrid Approach') },
        { value: 'sampling', label: i18n.t('Statistical Sampling') }
    ]

    const frequencies = [
        { value: 'daily', label: i18n.t('Daily') },
        { value: 'weekly', label: i18n.t('Weekly') },
        { value: 'monthly', label: i18n.t('Monthly') },
        { value: 'quarterly', label: i18n.t('Quarterly') },
        { value: 'annually', label: i18n.t('Annually') },
        { value: 'adhoc', label: i18n.t('Ad-hoc') }
    ]

    const reportingLevels = [
        { value: 'facility', label: i18n.t('Health Facility') },
        { value: 'district', label: i18n.t('District') },
        { value: 'region', label: i18n.t('Region/Province') },
        { value: 'national', label: i18n.t('National') },
        { value: 'global', label: i18n.t('Global') }
    ]

    const dataQualityDimensionOptions = [
        { value: 'completeness', label: i18n.t('Completeness') },
        { value: 'timeliness', label: i18n.t('Timeliness') },
        { value: 'accuracy', label: i18n.t('Accuracy') },
        { value: 'consistency', label: i18n.t('Consistency') },
        { value: 'validity', label: i18n.t('Validity') },
        { value: 'integrity', label: i18n.t('Integrity') },
        { value: 'precision', label: i18n.t('Precision') },
        { value: 'reliability', label: i18n.t('Reliability') }
    ]

    const tabs = [
        { id: 'details', title: i18n.t('Assessment Details'), label: i18n.t('Assessment Details') },
        { id: 'connection', title: i18n.t('Data Source'), label: i18n.t('Data Source') },
        { id: 'datasets', title: i18n.t('Select Dataset'), label: i18n.t('Select Dataset') },
        { id: 'elements', title: i18n.t('Data Elements'), label: i18n.t('Data Elements') },
        { id: 'units', title: i18n.t('Reporting Units'), label: i18n.t('Reporting Units') },
        { id: 'review', title: i18n.t('Review & Create'), label: i18n.t('Review & Create') }
    ]

    // Navigation functions
    const handleCancel = () => {
        navigate('/manage-assessments')
    }

    const getTabIndex = (tabId) => {
        return tabs.findIndex(tab => tab.id === tabId)
    }

    const handleNext = () => {
        const currentIndex = getTabIndex(activeTab)
        if (currentIndex < tabs.length - 1) {
            setActiveTab(tabs[currentIndex + 1].id)
        }
    }

    const handlePrevious = () => {
        const currentIndex = getTabIndex(activeTab)
        if (currentIndex > 0) {
            setActiveTab(tabs[currentIndex - 1].id)
        }
    }

    // Validation function
    const isTabValid = (tabId) => {
        switch (tabId) {
            case 'details':
                return assessmentData.name && 
                       assessmentData.assessmentType && 
                       assessmentData.priority && 
                       assessmentData.startDate && 
                       assessmentData.endDate &&
                       assessmentData.methodology &&
                       assessmentData.frequency &&
                       assessmentData.reportingLevel &&
                       assessmentData.dataQualityDimensions.length > 0 &&
                       (assessmentData.assessmentType !== 'followup' || assessmentData.baselineAssessmentId)
            case 'connection':
                return dhis2Config && dhis2Config.baseUrl
            case 'datasets':
                return selectedDataSets.length > 0
            case 'elements':
                return selectedDataSets.length > 0 && selectedDataElements.length > 0
            case 'units':
                return selectedOrgUnits.length > 0
            default:
                return true
        }
    }

    const handleCreateAssessment = async () => {
        setLoading(true)
        try {
            // Simulate assessment creation
            await new Promise(resolve => setTimeout(resolve, 2000))
            navigate('/manage-assessments')
        } catch (error) {
            console.error('Error creating assessment:', error)
        } finally {
            setLoading(false)
        }
    }

    const renderTabSpecificContent = () => {
        switch (activeTab) {
            case 'details':
                return (
                    <div style={{ 
                        padding: '20px 40px',
                        width: '100%'
                    }}>
                        <div style={{ 
                            display: 'grid',
                            gap: '20px',
                            width: '100%'
                        }}>
                            {/* Basic Information Section */}
                            <h3 style={{ margin: '0 0 12px 0', fontSize: '18px', fontWeight: '600', color: '#2c3e50' }}>
                                {i18n.t('Basic Information')}
                            </h3>
                            
                            <InputField
                                label={i18n.t('Assessment Name')}
                                name="name"
                                value={assessmentData.name}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, name: value }))}
                                placeholder={i18n.t('Enter a descriptive name for your assessment')}
                                required
                                helpText={i18n.t('Choose a clear, descriptive name that identifies the purpose')}
                            />

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                                <SingleSelectField
                                    label={i18n.t('Assessment Type')}
                                    selected={assessmentData.assessmentType}
                                    onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, assessmentType: selected }))}
                                    helpText={i18n.t('Select the type based on your data quality needs')}
                                >
                                    {assessmentTypes.map(type => (
                                        <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                                    ))}
                                </SingleSelectField>

                                <SingleSelectField
                                    label={i18n.t('Priority Level')}
                                    selected={assessmentData.priority}
                                    onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, priority: selected }))}
                                    helpText={i18n.t('Set the priority level for this assessment')}
                                >
                                    {priorities.map(priority => (
                                        <SingleSelectOption key={priority.value} value={priority.value} label={priority.label} />
                                    ))}
                                </SingleSelectField>

                                <SingleSelectField
                                    label={i18n.t('Reporting Level')}
                                    selected={assessmentData.reportingLevel}
                                    onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, reportingLevel: selected }))}
                                    helpText={i18n.t('Select the organizational level for reporting')}
                                >
                                    {reportingLevels.map(level => (
                                        <SingleSelectOption key={level.value} value={level.value} label={level.label} />
                                    ))}
                                </SingleSelectField>
                            </div>

                            <TextAreaField
                                label={i18n.t('Description')}
                                name="description"
                                value={assessmentData.description}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, description: value }))}
                                placeholder={i18n.t('Provide a detailed description of this assessment')}
                                rows={3}
                                helpText={i18n.t('Describe the purpose and scope of this assessment')}
                            />

                            {/* Assessment Configuration Section */}
                            <h3 style={{ margin: '16px 0 12px 0', fontSize: '18px', fontWeight: '600', color: '#2c3e50' }}>
                                {i18n.t('Assessment Configuration')}
                            </h3>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                                <SingleSelectField
                                    label={i18n.t('Methodology')}
                                    selected={assessmentData.methodology}
                                    onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, methodology: selected }))}
                                    helpText={i18n.t('Choose the assessment methodology')}
                                >
                                    {methodologies.map(method => (
                                        <SingleSelectOption key={method.value} value={method.value} label={method.label} />
                                    ))}
                                </SingleSelectField>

                                <SingleSelectField
                                    label={i18n.t('Frequency')}
                                    selected={assessmentData.frequency}
                                    onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, frequency: selected }))}
                                    helpText={i18n.t('How often will this assessment run')}
                                >
                                    {frequencies.map(freq => (
                                        <SingleSelectOption key={freq.value} value={freq.value} label={freq.label} />
                                    ))}
                                </SingleSelectField>

                                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                                    <Checkbox
                                        label={i18n.t('Approval Required')}
                                        checked={assessmentData.approvalRequired}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, approvalRequired: checked }))}
                                    />
                                    <Checkbox
                                        label={i18n.t('Public Access')}
                                        checked={assessmentData.publicAccess}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, publicAccess: checked }))}
                                    />
                                </div>
                            </div>

                            <MultiSelectField
                                label={i18n.t('Data Quality Dimensions')}
                                selected={assessmentData.dataQualityDimensions}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, dataQualityDimensions: selected }))}
                                helpText={i18n.t('Select the data quality dimensions to assess')}
                            >
                                {dataQualityDimensionOptions.map(dimension => (
                                    <MultiSelectOption key={dimension.value} value={dimension.value} label={dimension.label} />
                                ))}
                            </MultiSelectField>

                            {/* Timeline and Resources Section */}
                            <h3 style={{ margin: '16px 0 12px 0', fontSize: '18px', fontWeight: '600', color: '#2c3e50' }}>
                                {i18n.t('Timeline & Resources')}
                            </h3>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                <InputField
                                    label={i18n.t('Start Date')}
                                    name="startDate"
                                    type="date"
                                    value={assessmentData.startDate}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, startDate: value }))}
                                    required
                                    helpText={i18n.t('Assessment period start date')}
                                />

                                <InputField
                                    label={i18n.t('End Date')}
                                    name="endDate"
                                    type="date"
                                    value={assessmentData.endDate}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, endDate: value }))}
                                    required
                                    helpText={i18n.t('Assessment period end date')}
                                />
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                <InputField
                                    label={i18n.t('Budget')}
                                    name="budget"
                                    value={assessmentData.budget}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, budget: value }))}
                                    placeholder={i18n.t('Enter estimated budget')}
                                    helpText={i18n.t('Estimated budget for this assessment')}
                                />

                                <InputField
                                    label={i18n.t('Timeline')}
                                    name="timeline"
                                    value={assessmentData.timeline}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, timeline: value }))}
                                    placeholder={i18n.t('e.g., 3 months')}
                                    helpText={i18n.t('Expected duration for completion')}
                                />
                            </div>

                            <TextAreaField
                                label={i18n.t('Resources Required')}
                                name="resources"
                                value={assessmentData.resources}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, resources: value }))}
                                placeholder={i18n.t('List required resources, tools, and personnel')}
                                rows={2}
                                helpText={i18n.t('Specify human resources, tools, and infrastructure needed')}
                            />

                            {/* Objectives and Planning Section */}
                            <h3 style={{ margin: '16px 0 12px 0', fontSize: '18px', fontWeight: '600', color: '#2c3e50' }}>
                                {i18n.t('Objectives & Planning')}
                            </h3>

                            <TextAreaField
                                label={i18n.t('Objectives')}
                                name="objectives"
                                value={assessmentData.objectives}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, objectives: value }))}
                                placeholder={i18n.t('Define specific, measurable objectives for this assessment')}
                                rows={2}
                                helpText={i18n.t('What specific goals do you want to achieve?')}
                            />

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                <TextAreaField
                                    label={i18n.t('Scope')}
                                    name="scope"
                                    value={assessmentData.scope}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, scope: value }))}
                                    placeholder={i18n.t('Define the boundaries and coverage of this assessment')}
                                    rows={2}
                                    helpText={i18n.t('What data, systems, and processes will be included?')}
                                />

                                <TextAreaField
                                    label={i18n.t('Expected Outcomes')}
                                    name="expectedOutcomes"
                                    value={assessmentData.expectedOutcomes}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, expectedOutcomes: value }))}
                                    placeholder={i18n.t('Describe the expected results and deliverables')}
                                    rows={2}
                                    helpText={i18n.t('What results do you expect to achieve?')}
                                />
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                <TextAreaField
                                    label={i18n.t('Success Criteria')}
                                    name="successCriteria"
                                    value={assessmentData.successCriteria}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, successCriteria: value }))}
                                    placeholder={i18n.t('Define measurable criteria for success')}
                                    rows={2}
                                    helpText={i18n.t('How will you measure the success of this assessment?')}
                                />

                                <TextAreaField
                                    label={i18n.t('Risk Assessment')}
                                    name="riskAssessment"
                                    value={assessmentData.riskAssessment}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, riskAssessment: value }))}
                                    placeholder={i18n.t('Identify potential risks and mitigation strategies')}
                                    rows={2}
                                    helpText={i18n.t('What risks might affect this assessment?')}
                                />
                            </div>

                            <TextAreaField
                                label={i18n.t('Stakeholders')}
                                name="stakeholders"
                                value={assessmentData.stakeholders}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, stakeholders: value }))}
                                placeholder={i18n.t('List key stakeholders and their roles')}
                                rows={2}
                                helpText={i18n.t('Who are the key people involved in this assessment?')}
                            />

                            {/* Baseline Assessment (if follow-up type) */}
                            {assessmentData.assessmentType === 'followup' && (
                                <>
                                    <h3 style={{ margin: '16px 0 12px 0', fontSize: '18px', fontWeight: '600', color: '#2c3e50' }}>
                                        {i18n.t('Baseline Reference')}
                                    </h3>
                                    <SingleSelectField
                                        label={i18n.t('Baseline Assessment')}
                                        selected={assessmentData.baselineAssessmentId}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, baselineAssessmentId: selected }))}
                                        helpText={i18n.t('Select the baseline assessment to compare against')}
                                        required
                                    >
                                        <SingleSelectOption value="" label={i18n.t('Select baseline assessment')} />
                                        {baselineAssessments.map(baseline => (
                                            <SingleSelectOption 
                                                key={baseline.id} 
                                                value={baseline.id} 
                                                label={`${baseline.name} (${baseline.startDate} - ${baseline.endDate})`} 
                                            />
                                        ))}
                                    </SingleSelectField>
                                </>
                            )}

                            {/* Assessment Type Information */}
                            {assessmentData.assessmentType && (
                                <div style={{ marginTop: '12px' }}>
                                    <h4 style={{ 
                                        margin: '0 0 8px 0',
                                        color: assessmentData.assessmentType === 'baseline' ? '#28a745' : '#856404',
                                        fontSize: '16px',
                                        fontWeight: '600'
                                    }}>
                                        {assessmentData.assessmentType === 'baseline' ? '📊 Baseline Assessment' : '📈 Follow-up Assessment'}
                                    </h4>
                                    <p style={{ 
                                        margin: 0,
                                        fontSize: '14px',
                                        color: '#666',
                                        lineHeight: '1.4'
                                    }}>
                                        {assessmentData.assessmentType === 'baseline' 
                                            ? 'This will establish the initial data quality baseline for future comparisons and improvements.'
                                            : 'This assessment will compare current data quality against the selected baseline to measure improvements.'
                                        }
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                )

            case 'connection':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <DHIS2Configuration 
                            onConfigured={(config) => {
                                setDhis2Config(config)
                            }}
                        />
                    </div>
                )

            case 'datasets':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <AssessmentDataSetSelection
                            dhis2Config={dhis2Config}
                            multiSelect={true}
                            selectedDataSets={selectedDataSets}
                            onDataSetsSelected={setSelectedDataSets}
                            mode="datasets"
                        />
                    </div>
                )

            case 'elements':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <AssessmentDataSetSelection
                            dhis2Config={dhis2Config}
                            multiSelect={true}
                            selectedDataSets={selectedDataSets}
                            onDataSetsSelected={setSelectedDataSets}
                            selectedDataElements={selectedDataElements}
                            onDataElementsSelected={setSelectedDataElements}
                            mode="dataelements"
                        />
                    </div>
                )

            case 'units':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <OrganisationUnitManagement
                            dhis2Config={dhis2Config}
                            selectedDataSets={selectedDataSets}
                            onOrganisationUnitsSelected={setSelectedOrgUnits}
                        />
                    </div>
                )

            case 'review': 
                                    margin: '0 0 16px 0', 
                                    fontSize: '16px', 
                                    color: '#6c757d' 
                                }}>
                                    {i18n.t('Please select a dataset first')}
                                </p>
                                <p style={{ 
                                    margin: '0', 
                                    fontSize: '14px', 
                                    color: '#868e96' 
                                }}>
                                    {i18n.t('Go to the "Select Dataset" tab to choose a dataset before selecting data elements.')}
                                </p>
                            </div>
                        ) : (
                            <div>
                                <div style={{ 
                                    marginBottom: '24px', 
                                    padding: '16px', 
                                    backgroundColor: '#e3f2fd', 
                                    borderRadius: '8px',
                                    border: '1px solid #bbdefb'
                                }}>
                                    <h4 style={{ 
                                        margin: '0 0 8px 0', 
                                        fontSize: '16px', 
                                        fontWeight: '600',
                                        color: '#1565c0'
                                    }}>
                                        {i18n.t('Selected Dataset: {{name}}', { name: selectedDataSet.displayName })}
                                    </h4>
                                    <p style={{ 
                                        margin: '0', 
                                        fontSize: '14px', 
                                        color: '#1976d2' 
                                    }}>
                                        {i18n.t('{{count}} data elements available for selection', { 
                                            count: selectedDataSet.dataSetElements?.length || 0 
                                        })}
                                    </p>
                                </div>

                                {selectedDataSet.dataSetElements && selectedDataSet.dataSetElements.length > 0 ? (
                                    <div>
                                        <div style={{ marginBottom: '16px' }}>
                                            <InputField
                                                label={i18n.t('Search Data Elements')}
                                                placeholder={i18n.t('Search by data element name...')}
                                                type="text"
                                            />
                                        </div>
                                        
                                        <div style={{ 
                                            border: '1px solid #dee2e6', 
                                            borderRadius: '8px',
                                            backgroundColor: 'white'
                                        }}>
                                            <div style={{ 
                                                padding: '12px 16px', 
                                                borderBottom: '1px solid #dee2e6',
                                                backgroundColor: '#f8f9fa',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                                    <Checkbox 
                                                        label={i18n.t('Select All')}
                                                        checked={selectedDataElements.length === selectedDataSet.dataSetElements.length}
                                                        onChange={({ checked }) => {
                                                            if (checked) {
                                                                setSelectedDataElements(selectedDataSet.dataSetElements.map(de => de.dataElement))
                                                            } else {
                                                                setSelectedDataElements([])
                                                            }
                                                        }}
                                                    />
                                                </div>
                                                <span style={{ fontSize: '14px', color: '#6c757d' }}>
                                                    {i18n.t('{{selected}} of {{total}} selected', { 
                                                        selected: selectedDataElements.length,
                                                        total: selectedDataSet.dataSetElements.length
                                                    })}
                                                </span>
                                            </div>
                                            
                                            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                                                {selectedDataSet.dataSetElements.map((dataSetElement, index) => {
                                                    const dataElement = dataSetElement.dataElement
                                                    const isSelected = selectedDataElements.some(de => de.id === dataElement.id)
                                                    
                                                    return (
                                                        <div 
                                                            key={dataElement.id}
                                                            style={{ 
                                                                padding: '12px 16px',
                                                                borderBottom: index < selectedDataSet.dataSetElements.length - 1 ? '1px solid #f1f3f4' : 'none',
                                                                backgroundColor: isSelected ? '#f8f9ff' : 'white',
                                                                cursor: 'pointer'
                                                            }}
                                                            onClick={() => {
                                                                if (isSelected) {
                                                                    setSelectedDataElements(prev => 
                                                                        prev.filter(de => de.id !== dataElement.id)
                                                                    )
                                                                } else {
                                                                    setSelectedDataElements(prev => [...prev, dataElement])
                                                                }
                                                            }}
                                                        >
                                                            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                                                                <Checkbox 
                                                                    checked={isSelected}
                                                                    onChange={() => {}} // Handled by parent div click
                                                                />
                                                                <div style={{ flex: 1 }}>
                                                                    <div style={{ 
                                                                        fontWeight: '500', 
                                                                        fontSize: '14px',
                                                                        color: '#2c3e50',
                                                                        marginBottom: '4px'
                                                                    }}>
                                                                        {dataElement.displayName}
                                                                    </div>
                                                                    {dataElement.description && (
                                                                        <div style={{ 
                                                                            fontSize: '12px', 
                                                                            color: '#6c757d',
                                                                            marginBottom: '4px'
                                                                        }}>
                                                                            {dataElement.description}
                                                                        </div>
                                                                    )}
                                                                    <div style={{ 
                                                                        fontSize: '11px', 
                                                                        color: '#868e96',
                                                                        display: 'flex',
                                                                        gap: '16px'
                                                                    }}>
                                                                        <span>
                                                                            <strong>{i18n.t('Type')}:</strong> {dataElement.valueType || 'N/A'}
                                                                        </span>
                                                                        <span>
                                                                            <strong>{i18n.t('Domain')}:</strong> {dataElement.domainType || 'N/A'}
                                                                        </span>
                                                                        {dataElement.code && (
                                                                            <span>
                                                                                <strong>{i18n.t('Code')}:</strong> {dataElement.code}
                                                                            </span>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    )
                                                })}
                                            </div>
                                        </div>
                                        
                                        {selectedDataElements.length > 0 && (
                                            <div style={{ 
                                                marginTop: '16px',
                                                padding: '16px',
                                                backgroundColor: '#d4edda',
                                                borderRadius: '8px',
                                                border: '1px solid #c3e6cb'
                                            }}>
                                                <h5 style={{ 
                                                    margin: '0 0 8px 0', 
                                                    fontSize: '14px', 
                                                    fontWeight: '600',
                                                    color: '#155724'
                                                }}>
                                                    {i18n.t('Selected Data Elements ({{count}})', { count: selectedDataElements.length })}
                                                </h5>
                                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                                                    {selectedDataElements.slice(0, 10).map(dataElement => (
                                                        <Tag key={dataElement.id} neutral>
                                                            {dataElement.displayName}
                                                        </Tag>
                                                    ))}
                                                    {selectedDataElements.length > 10 && (
                                                        <Tag neutral>
                                                            {i18n.t('... and {{more}} more', { more: selectedDataElements.length - 10 })}
                                                        </Tag>
                                                    )}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div style={{ 
                                        padding: '40px', 
                                        textAlign: 'center', 
                                        backgroundColor: '#fff3cd', 
                                        borderRadius: '8px',
                                        border: '1px solid #ffeaa7'
                                    }}>
                                        <p style={{ 
                                            margin: '0', 
                                            fontSize: '16px', 
                                            color: '#856404' 
                                        }}>
                                            {i18n.t('No data elements found in the selected dataset')}
                                        </p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )

            case 'units':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <OrganisationUnitManagement
                            dhis2Config={dhis2Config}
                            selectedDataSet={selectedDataSet}
                            onOrganisationUnitsSelected={setSelectedOrgUnits}
                        />
                    </div>
                )

            case 'review':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <h3 style={{ 
                            margin: '0 0 20px 0', 
                            fontSize: '20px', 
                            fontWeight: '600',
                            color: '#2c3e50'
                        }}>
                            {i18n.t('Review Assessment Configuration')}
                        </h3>
                        
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            {/* Basic Information */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Basic Information')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Name')}:</strong> {assessmentData.name}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Type')}:</strong> {assessmentTypes.find(t => t.value === assessmentData.assessmentType)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Priority')}:</strong> {priorities.find(p => p.value === assessmentData.priority)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Reporting Level')}:</strong> {reportingLevels.find(r => r.value === assessmentData.reportingLevel)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Period')}:</strong> {assessmentData.startDate} to {assessmentData.endDate}</p>
                                    {assessmentData.description && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Description')}:</strong> {assessmentData.description.substring(0, 100)}{assessmentData.description.length > 100 ? '...' : ''}</p>
                                    )}
                                </div>
                            </div>

                            {/* Configuration */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Configuration')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Methodology')}:</strong> {methodologies.find(m => m.value === assessmentData.methodology)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Frequency')}:</strong> {frequencies.find(f => f.value === assessmentData.frequency)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Data Quality Dimensions')}:</strong> {assessmentData.dataQualityDimensions.length} selected</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Approval Required')}:</strong> {assessmentData.approvalRequired ? 'Yes' : 'No'}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Public Access')}:</strong> {assessmentData.publicAccess ? 'Yes' : 'No'}</p>
                                    {assessmentData.budget && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Budget')}:</strong> {assessmentData.budget}</p>
                                    )}
                                    {assessmentData.timeline && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Timeline')}:</strong> {assessmentData.timeline}</p>
                                    )}
                                </div>
                            </div>

                            {/* Data Sources */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Data Sources')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('DHIS2 Instance')}:</strong> {dhis2Config?.baseUrl || 'Not configured'}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Source Dataset')}:</strong> {selectedDataSet?.displayName || 'Not selected'}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Data Elements')}:</strong> {selectedDataElements.length} selected</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Reporting Units')}:</strong> {selectedOrgUnits.length} selected</p>
                                    {assessmentData.assessmentType === 'followup' && assessmentData.baselineAssessmentId && (
                                        <p style={{ margin: '0 0 6px 0' }}>
                                            <strong>{i18n.t('Baseline')}:</strong> {baselineAssessments.find(b => b.id === assessmentData.baselineAssessmentId)?.name}
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Additional Details */}
                        {(assessmentData.objectives || assessmentData.scope || assessmentData.expectedOutcomes || assessmentData.stakeholders) && (
                            <div style={{ marginTop: '20px' }}>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Additional Details')}
                                </h4>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', fontSize: '14px', lineHeight: '1.6' }}>
                                    <div>
                                        {assessmentData.objectives && (
                                            <p style={{ margin: '0 0 12px 0' }}>
                                                <strong>{i18n.t('Objectives')}:</strong><br />
                                                {assessmentData.objectives.substring(0, 200)}{assessmentData.objectives.length > 200 ? '...' : ''}
                                            </p>
                                        )}
                                        {assessmentData.scope && (
                                            <p style={{ margin: '0 0 12px 0' }}>
                                                <strong>{i18n.t('Scope')}:</strong><br />
                                                {assessmentData.scope.substring(0, 200)}{assessmentData.scope.length > 200 ? '...' : ''}
                                            </p>
                                        )}
                                    </div>
                                    <div>
                                        {assessmentData.expectedOutcomes && (
                                            <p style={{ margin: '0 0 12px 0' }}>
                                                <strong>{i18n.t('Expected Outcomes')}:</strong><br />
                                                {assessmentData.expectedOutcomes.substring(0, 200)}{assessmentData.expectedOutcomes.length > 200 ? '...' : ''}
                                            </p>
                                        )}
                                        {assessmentData.stakeholders && (
                                            <p style={{ margin: '0 0 12px 0' }}>
                                                <strong>{i18n.t('Stakeholders')}:</strong><br />
                                                {assessmentData.stakeholders.substring(0, 200)}{assessmentData.stakeholders.length > 200 ? '...' : ''}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Selected Data Quality Dimensions */}
                        {assessmentData.dataQualityDimensions.length > 0 && (
                            <div style={{ marginTop: '20px' }}>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Data Quality Dimensions')}
                                </h4>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                                    {assessmentData.dataQualityDimensions.map(dimension => (
                                        <Tag key={dimension} neutral>
                                            {dataQualityDimensionOptions.find(d => d.value === dimension)?.label}
                                        </Tag>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )

            default:
                return <div>Tab content not found</div>
        }
    }

    return (
        <div style={{ padding: '24px', minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
            {/* Tab Header with Navigation */}
            <div 
                style={{
                    padding: '24px 32px',
                    borderBottom: '1px solid #e9ecef',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    backgroundColor: 'white',
                    marginBottom: '0'
                }}
            >
                <h2 style={{ 
                    margin: '0', 
                    fontSize: '24px', 
                    fontWeight: '600',
                    color: '#2c3e50'
                }}>
                    {i18n.t('Create New Assessment')}
                </h2>
            </div>

            {/* Tab Navigation */}
            <div style={{ padding: '0 32px', borderBottom: '1px solid #e9ecef', backgroundColor: 'white' }}>
                <TabBar>
                    {tabs.map(tab => (
                        <Tab 
                            key={tab.id}
                            selected={activeTab === tab.id}
                            onClick={() => setActiveTab(tab.id)}
                        >
                            {tab.label}
                        </Tab>
                    ))}
                </TabBar>
            </div>

            {/* Tab Content */}
            <div style={{ flex: 1, padding: '0', backgroundColor: 'white', display: 'flex', flexDirection: 'column' }}>
                {renderTabSpecificContent()}
            </div>

            {/* Clean Footer Actions */}
            <div 
                style={{ 
                    borderTop: '1px solid #e0e0e0', 
                    padding: '20px 40px',
                    backgroundColor: 'white',
                    marginTop: 'auto',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    width: '100%'
                }}
            >
                {/* Left Side - Cancel Button */}
                <Button 
                    onClick={handleCancel}
                    disabled={loading}
                    style={{
                        backgroundColor: '#6c757d',
                        border: '1px solid #6c757d',
                        color: 'white',
                        fontWeight: '500',
                        padding: '10px 20px',
                        borderRadius: '6px',
                        fontSize: '14px',
                        minWidth: '100px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        transition: 'all 0.2s ease',
                        cursor: loading ? 'not-allowed' : 'pointer',
                        opacity: loading ? 0.7 : 1
                    }}
                >
                    ✕ {i18n.t('Cancel')}
                </Button>

                {/* Center - Status Info */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
                    <Tag 
                        positive={activeTab === 'review'}
                        neutral={activeTab !== 'review'}
                        style={{ fontSize: '14px', fontWeight: '500', padding: '8px 16px' }}
                    >
                        {tabs.find(tab => tab.id === activeTab)?.label}
                    </Tag>
                    {!isTabValid(activeTab) && activeTab !== 'review' && (
                        <p style={{ 
                            margin: 0, 
                            fontSize: '14px', 
                            color: '#dc3545',
                            fontWeight: '500'
                        }}>
                            Please complete all required fields to continue
                        </p>
                    )}
                </div>
                
                {/* Right Side - Navigation Buttons */}
                <div style={{ display: 'flex', gap: '16px' }}>
                        {getTabIndex(activeTab) > 0 && (
                            <Button 
                                secondary 
                                onClick={handlePrevious} 
                                disabled={loading}
                                style={{
                                    padding: '10px 20px',
                                    fontWeight: '500',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#f8f9fa',
                                    border: '1px solid #dee2e6',
                                    color: '#495057',
                                    minWidth: '100px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    opacity: loading ? 0.7 : 1
                                }}
                            >
                                ← {i18n.t('Previous')}
                            </Button>
                        )}
                        
                        {activeTab !== 'review' ? (
                            <Button 
                                primary 
                                onClick={handleNext} 
                                disabled={!isTabValid(activeTab) || loading}
                                style={{
                                    padding: '10px 20px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#007bff',
                                    border: '1px solid #007bff',
                                    color: 'white',
                                    minWidth: '100px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: (!isTabValid(activeTab) || loading) ? 'not-allowed' : 'pointer',
                                    opacity: (!isTabValid(activeTab) || loading) ? 0.7 : 1
                                }}
                            >
                                {i18n.t('Next')} →
                            </Button>
                        ) : (
                            <Button 
                                primary 
                                onClick={handleCreateAssessment} 
                                disabled={loading}
                                style={{
                                    padding: '10px 24px',
                                    fontWeight: '600',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    backgroundColor: '#28a745',
                                    border: '1px solid #28a745',
                                    color: 'white',
                                    minWidth: '140px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '6px',
                                    transition: 'all 0.2s ease',
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    opacity: loading ? 0.7 : 1
                                }}
                            >
                                {loading ? (
                                    <>
                                        <CircularLoader small /> {i18n.t('Creating...')}
                                    </>
                                ) : (
                                    <>
                                        💾 {i18n.t('Save')}
                                    </>
                                )}
                            </Button>
                        )}
                </div>
            </div>
        </div>
    )
}