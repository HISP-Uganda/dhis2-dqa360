import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Input,
    CircularLoader,
    NoticeBox,
    Tag,
    InputField,
    TextAreaField,
    SingleSelectField,
    SingleSelectOption,
    MultiSelectField,
    MultiSelectOption,
    Checkbox,
    Tab,
    TabBar
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { DHIS2Configuration } from '../Metadata/DHIS2Configuration'
import { AssessmentDataSetSelection } from '../../components/AssessmentDataSetSelection'
import { OrganisationUnitManagement } from '../Metadata/OrganisationUnitManagement'
import { OrganizationUnitMapping } from '../Metadata/OrganizationUnitMapping'
import { DatasetPreparation } from '../Metadata/DatasetPreparation'
import { useMetadataDataStore, METADATA_KEYS } from '../../services/metadataDataStoreService'
import DatasetFormModal from '../../components/DatasetFormModal'
import DataElementFormModal from '../../components/DataElementFormModal'
import OrganizationUnitFormModal from '../../components/OrganizationUnitFormModal'
import CategoryOptionFormModal from '../../components/CategoryOptionFormModal'
import CategoryFormModal from '../../components/CategoryFormModal'
import CategoryComboFormModal from '../../components/CategoryComboFormModal'
import AttributeFormModal from '../../components/AttributeFormModal'
import OptionSetFormModal from '../../components/OptionSetFormModal'

export const CreateAssessmentPage = () => {
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState('details')
    const [loading, setLoading] = useState(false)
    
    // DataStore service
    const {
        loadAllMetadata,
        saveMetadataItem,
        saveAssessment,
        createDefaultDQAMetadata,
        KEYS
    } = useMetadataDataStore()

    // Assessment data state
    const [assessmentData, setAssessmentData] = useState({
        name: '',
        description: '',
        assessmentType: 'baseline',
        priority: 'medium',
        startDate: '',
        endDate: '',
        baselineAssessmentId: '',
        notifications: true,
        autoSync: true,
        validationAlerts: false,
        historicalComparison: false,
        // Additional assessment details
        objectives: '',
        scope: '',
        methodology: 'automated',
        frequency: 'monthly',
        reportingLevel: 'facility',
        dataQualityDimensions: ['completeness', 'timeliness'],
        stakeholders: [],
        riskFactors: [],
        successCriteria: '',
        // Advanced settings
        confidentialityLevel: 'internal',
        dataRetentionPeriod: '5years',
        publicAccess: false,
        tags: [],
        customFields: {}
    })

    // Other state
    const [metadataSource, setMetadataSource] = useState(null) // 'dhis2' or 'manual'
    const [dhis2Config, setDhis2Config] = useState(null)
    
    // Additional metadata collections
    const [categoryOptions, setCategoryOptions] = useState([])
    const [categories, setCategories] = useState([])
    const [categoryCombos, setCategoryCombos] = useState([])
    const [attributes, setAttributes] = useState([])
    const [optionSets, setOptionSets] = useState([])
    const [selectedDataSet, setSelectedDataSet] = useState(null) // Keep for backward compatibility
    const [selectedDataSets, setSelectedDataSets] = useState([]) // New multi-select state
    const [selectedDataElements, setSelectedDataElements] = useState([])
    const [selectedOrgUnits, setSelectedOrgUnits] = useState([])
    const [orgUnitMappings, setOrgUnitMappings] = useState([])
    const [datasetPreparationComplete, setDatasetPreparationComplete] = useState(false)
    
    // Additional metadata collections
    const [baselineAssessments, setBaselineAssessments] = useState([])
    const [loadingBaselines, setLoadingBaselines] = useState(false)
    const [visitedTabs, setVisitedTabs] = useState(new Set(['details'])) // Track which tabs have been visited
    
    // Modal states for manual metadata creation
    const [datasetModalOpen, setDatasetModalOpen] = useState(false)
    const [dataElementModalOpen, setDataElementModalOpen] = useState(false)
    const [orgUnitModalOpen, setOrgUnitModalOpen] = useState(false)
    const [categoryOptionModalOpen, setCategoryOptionModalOpen] = useState(false)
    const [categoryModalOpen, setCategoryModalOpen] = useState(false)
    const [categoryComboModalOpen, setCategoryComboModalOpen] = useState(false)
    const [attributeModalOpen, setAttributeModalOpen] = useState(false)
    const [optionSetModalOpen, setOptionSetModalOpen] = useState(false)
    
    const [editingDataset, setEditingDataset] = useState(null)
    const [editingDataElement, setEditingDataElement] = useState(null)
    const [editingOrgUnit, setEditingOrgUnit] = useState(null)
    const [editingCategoryOption, setEditingCategoryOption] = useState(null)
    const [editingCategory, setEditingCategory] = useState(null)
    const [editingCategoryCombo, setEditingCategoryCombo] = useState(null)
    const [editingAttribute, setEditingAttribute] = useState(null)
    const [editingOptionSet, setEditingOptionSet] = useState(null)

    // Configuration data
    const assessmentTypes = [
        { value: 'baseline', label: i18n.t('Baseline Assessment') },
        { value: 'followup', label: i18n.t('Follow-up Assessment') }
    ]

    const priorities = [
        { value: 'low', label: i18n.t('Low') },
        { value: 'medium', label: i18n.t('Medium') },
        { value: 'high', label: i18n.t('High') },
        { value: 'critical', label: i18n.t('Critical') }
    ]

    const methodologies = [
        { value: 'automated', label: i18n.t('Automated') },
        { value: 'manual', label: i18n.t('Manual') },
        { value: 'hybrid', label: i18n.t('Hybrid') }
    ]

    // Load existing metadata on component mount
    useEffect(() => {
        const loadExistingMetadata = async () => {
            try {
                setLoading(true)
                const metadata = await loadAllMetadata()
                
                // Update metadata collections with existing data
                setCategoryOptions(metadata[KEYS.CATEGORY_OPTIONS] || [])
                setCategories(metadata[KEYS.CATEGORIES] || [])
                setCategoryCombos(metadata[KEYS.CATEGORY_COMBOS] || [])
                setAttributes(metadata[KEYS.ATTRIBUTES] || [])
                setOptionSets(metadata[KEYS.OPTION_SETS] || [])
                setSelectedDataSets(metadata[KEYS.DATA_SETS] || [])
                setSelectedDataElements(metadata[KEYS.DATA_ELEMENTS] || [])
                setSelectedOrgUnits(metadata[KEYS.ORGANISATION_UNITS] || [])
                
                console.log('Existing metadata loaded successfully')
            } catch (error) {
                console.error('Error loading existing metadata:', error)
            } finally {
                setLoading(false)
            }
        }
        
        loadExistingMetadata()
    }, [])

    const frequencies = [
        { value: 'daily', label: i18n.t('Daily') },
        { value: 'weekly', label: i18n.t('Weekly') },
        { value: 'monthly', label: i18n.t('Monthly') },
        { value: 'quarterly', label: i18n.t('Quarterly') },
        { value: 'annually', label: i18n.t('Annually') }
    ]

    const reportingLevels = [
        { value: 'facility', label: i18n.t('Facility Level') },
        { value: 'district', label: i18n.t('District Level') },
        { value: 'regional', label: i18n.t('Regional Level') },
        { value: 'national', label: i18n.t('National Level') }
    ]

    const dataQualityDimensions = [
        { value: 'completeness', label: i18n.t('Completeness') },
        { value: 'timeliness', label: i18n.t('Timeliness') },
        { value: 'accuracy', label: i18n.t('Accuracy') },
        { value: 'consistency', label: i18n.t('Consistency') },
        { value: 'validity', label: i18n.t('Validity') },
        { value: 'integrity', label: i18n.t('Integrity') },
        { value: 'precision', label: i18n.t('Precision') },
        { value: 'reliability', label: i18n.t('Reliability') },
        { value: 'accessibility', label: i18n.t('Accessibility') },
        { value: 'interpretability', label: i18n.t('Interpretability') },
        { value: 'relevance', label: i18n.t('Relevance') },
        { value: 'comparability', label: i18n.t('Comparability') },
        { value: 'coherence', label: i18n.t('Coherence') },
        { value: 'granularity', label: i18n.t('Granularity') },
        { value: 'uniqueness', label: i18n.t('Uniqueness') },
        { value: 'conformity', label: i18n.t('Conformity') }
    ]

    const confidentialityLevels = [
        { value: 'public', label: i18n.t('Public') },
        { value: 'internal', label: i18n.t('Internal') },
        { value: 'confidential', label: i18n.t('Confidential') },
        { value: 'restricted', label: i18n.t('Restricted') }
    ]

    const dataRetentionPeriods = [
        { value: '1year', label: i18n.t('1 Year') },
        { value: '3years', label: i18n.t('3 Years') },
        { value: '5years', label: i18n.t('5 Years') },
        { value: '10years', label: i18n.t('10 Years') },
        { value: 'indefinite', label: i18n.t('Indefinite') }
    ]

    const tabs = [
        { id: 'details', label: i18n.t('Assessment Details') },
        { id: 'connection', label: i18n.t('DHIS2 Connection') },
        { id: 'datasets', label: i18n.t('Select Datasets') },
        { id: 'elements', label: i18n.t('Data Elements') },
        { id: 'units', label: i18n.t('Organisation Units') },
        { id: 'mapping', label: i18n.t('Map Organisation Units') },
        { id: 'preparation', label: i18n.t('Dataset Preparation') },
        { id: 'review', label: i18n.t('Review & Create') }
    ]

    // Helper function to check if all prerequisite tabs are valid (without recursion)
    const arePrerequisiteTabsValid = () => {
        const detailsValid = assessmentData.name && 
                           assessmentData.startDate && 
                           assessmentData.endDate && 
                           assessmentData.methodology && 
                           assessmentData.frequency && 
                           assessmentData.reportingLevel &&
                           assessmentData.dataQualityDimensions.length > 0 &&
                           (assessmentData.assessmentType !== 'followup' || assessmentData.baselineAssessmentId) &&
                           metadataSource
        
        const connectionValid = metadataSource === 'manual' ? true : (dhis2Config && dhis2Config.baseUrl && dhis2Config.username && dhis2Config.password)
        const datasetsValid = selectedDataSets.length > 0
        const elementsValid = selectedDataSets.length > 0 && selectedDataElements.length > 0
        const unitsValid = selectedOrgUnits.length > 0
        const mappingValid = orgUnitMappings.length > 0 && orgUnitMappings.some(mapping => mapping.mapped)
        const preparationValid = datasetPreparationComplete
        
        return detailsValid && connectionValid && datasetsValid && elementsValid && unitsValid && mappingValid && preparationValid
    }

    // Validation functions
    const isTabValid = (tabId) => {
        switch (tabId) {
            case 'details':
                return assessmentData.name && 
                       assessmentData.startDate && 
                       assessmentData.endDate && 
                       assessmentData.methodology && 
                       assessmentData.frequency && 
                       assessmentData.reportingLevel &&
                       assessmentData.dataQualityDimensions.length > 0 &&
                       (assessmentData.assessmentType !== 'followup' || assessmentData.baselineAssessmentId) &&
                       metadataSource
            case 'connection':
                return metadataSource === 'manual' ? true : (dhis2Config && dhis2Config.baseUrl && dhis2Config.username && dhis2Config.password)
            case 'datasets':
                return selectedDataSets.length > 0
            case 'elements':
                return selectedDataSets.length > 0 && selectedDataElements.length > 0
            case 'units':
                return selectedOrgUnits.length > 0
            case 'mapping':
                return orgUnitMappings.length > 0 && orgUnitMappings.some(mapping => mapping.mapped)
            case 'preparation':
                return datasetPreparationComplete
            case 'review':
                // Review tab is only valid if user has visited it AND all previous tabs are valid
                return visitedTabs.has('review') && arePrerequisiteTabsValid()
            default:
                return false // Default to false for unknown tabs
        }
    }

    const canProceedToTab = (tabId) => {
        const tabIndex = tabs.findIndex(tab => tab.id === tabId)
        if (tabIndex === 0) return true
        
        // Check if all previous tabs are valid
        for (let i = 0; i < tabIndex; i++) {
            if (!isTabValid(tabs[i].id)) {
                return false
            }
        }
        return true
    }

    // Helper function to change tab and track visits
    const changeTab = (tabId) => {
        setActiveTab(tabId)
        setVisitedTabs(prev => new Set([...prev, tabId]))
    }

    const handleTabClick = (tabId) => {
        if (canProceedToTab(tabId)) {
            changeTab(tabId)
        }
    }

    const handleNext = () => {
        const currentIndex = tabs.findIndex(tab => tab.id === activeTab)
        if (currentIndex < tabs.length - 1) {
            const nextTab = tabs[currentIndex + 1]
            if (canProceedToTab(nextTab.id)) {
                changeTab(nextTab.id)
            }
        }
    }

    const handlePrevious = () => {
        const currentIndex = tabs.findIndex(tab => tab.id === activeTab)
        if (currentIndex > 0) {
            changeTab(tabs[currentIndex - 1].id)
        }
    }

    const handleCreateAssessment = async () => {
        setLoading(true)
        try {
            // Create comprehensive assessment object with all collected data
            const assessment = {
                id: `assessment_${Date.now()}`,
                ...assessmentData,
                metadataSource,
                dhis2Config,
                selectedDataSets,
                selectedDataElements,
                selectedOrgUnits,
                categoryOptions,
                categories,
                categoryCombos,
                attributes,
                optionSets,
                created: new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                status: 'draft'
            }
            
            console.log('Creating assessment with complete data:', assessment)
            
            // Save assessment to dataStore
            await saveAssessment(assessment)
            
            console.log('Assessment created and saved to dataStore successfully')
            
            // Navigate back to assessments list
            navigate('/manage-assessments')
        } catch (error) {
            console.error('Error creating assessment:', error)
            // You might want to show an error notification here
        } finally {
            setLoading(false)
        }
    }

    // Modal handlers for manual metadata creation with dataStore integration
    const handleDatasetSave = async (dataset) => {
        try {
            // Save to dataStore
            await saveMetadataItem(KEYS.DATA_SETS, dataset)
            
            // Update local state
            if (editingDataset) {
                setSelectedDataSets(prev => prev.map(ds => ds.id === dataset.id ? dataset : ds))
            } else {
                setSelectedDataSets(prev => [...prev, dataset])
            }
            setEditingDataset(null)
            console.log('Dataset saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving dataset to dataStore:', error)
        }
    }

    // Additional metadata handlers with dataStore integration
    const handleCategoryOptionSave = async (categoryOption) => {
        try {
            await saveMetadataItem(KEYS.CATEGORY_OPTIONS, categoryOption)
            if (editingCategoryOption) {
                setCategoryOptions(prev => prev.map(co => co.id === categoryOption.id ? categoryOption : co))
            } else {
                setCategoryOptions(prev => [...prev, categoryOption])
            }
            setEditingCategoryOption(null)
            console.log('Category option saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving category option to dataStore:', error)
        }
    }

    const handleCategorySave = async (category) => {
        try {
            await saveMetadataItem(KEYS.CATEGORIES, category)
            if (editingCategory) {
                setCategories(prev => prev.map(cat => cat.id === category.id ? category : cat))
            } else {
                setCategories(prev => [...prev, category])
            }
            setEditingCategory(null)
            console.log('Category saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving category to dataStore:', error)
        }
    }

    const handleCategoryComboSave = async (categoryCombo) => {
        try {
            await saveMetadataItem(KEYS.CATEGORY_COMBOS, categoryCombo)
            if (editingCategoryCombo) {
                setCategoryCombos(prev => prev.map(cc => cc.id === categoryCombo.id ? categoryCombo : cc))
            } else {
                setCategoryCombos(prev => [...prev, categoryCombo])
            }
            setEditingCategoryCombo(null)
            console.log('Category combination saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving category combination to dataStore:', error)
        }
    }

    const handleAttributeSave = async (attribute) => {
        try {
            await saveMetadataItem(KEYS.ATTRIBUTES, attribute)
            if (editingAttribute) {
                setAttributes(prev => prev.map(attr => attr.id === attribute.id ? attribute : attr))
            } else {
                setAttributes(prev => [...prev, attribute])
            }
            setEditingAttribute(null)
            console.log('Attribute saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving attribute to dataStore:', error)
        }
    }

    const handleOptionSetSave = async (optionSet) => {
        try {
            await saveMetadataItem(KEYS.OPTION_SETS, optionSet)
            if (editingOptionSet) {
                setOptionSets(prev => prev.map(os => os.id === optionSet.id ? optionSet : os))
            } else {
                setOptionSets(prev => [...prev, optionSet])
            }
            setEditingOptionSet(null)
            console.log('Option set saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving option set to dataStore:', error)
        }
    }

    const handleDataElementSave = async (dataElement) => {
        try {
            await saveMetadataItem(KEYS.DATA_ELEMENTS, dataElement)
            if (editingDataElement) {
                setSelectedDataElements(prev => prev.map(de => de.id === dataElement.id ? dataElement : de))
            } else {
                setSelectedDataElements(prev => [...prev, dataElement])
            }
            setEditingDataElement(null)
            console.log('Data element saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving data element to dataStore:', error)
        }
    }

    const handleOrgUnitSave = async (orgUnit) => {
        try {
            await saveMetadataItem(KEYS.ORGANISATION_UNITS, orgUnit)
            if (editingOrgUnit) {
                setSelectedOrgUnits(prev => prev.map(ou => ou.id === orgUnit.id ? orgUnit : ou))
            } else {
                setSelectedOrgUnits(prev => [...prev, orgUnit])
            }
            setEditingOrgUnit(null)
            console.log('Organisation unit saved to dataStore successfully')
        } catch (error) {
            console.error('Error saving organisation unit to dataStore:', error)
        }
    }

    const openDatasetModal = (dataset = null) => {
        setEditingDataset(dataset)
        setDatasetModalOpen(true)
    }

    const openDataElementModal = (dataElement = null) => {
        setEditingDataElement(dataElement)
        setDataElementModalOpen(true)
    }

    const openOrgUnitModal = (orgUnit = null) => {
        setEditingOrgUnit(orgUnit)
        setOrgUnitModalOpen(true)
    }

    const deleteDataset = (datasetId) => {
        setSelectedDataSets(prev => prev.filter(ds => ds.id !== datasetId))
    }

    const deleteDataElement = (dataElementId) => {
        setSelectedDataElements(prev => prev.filter(de => de.id !== dataElementId))
    }

    const deleteOrgUnit = (orgUnitId) => {
        setSelectedOrgUnits(prev => prev.filter(ou => ou.id !== orgUnitId))
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 'details':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <h3 style={{ 
                            margin: '0 0 20px 0', 
                            fontSize: '20px', 
                            fontWeight: '600',
                            color: '#2c3e50'
                        }}>
                            {i18n.t('Assessment Details')}
                        </h3>
                        
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            <InputField
                                label={i18n.t('Assessment Name')}
                                placeholder={i18n.t('Enter assessment name')}
                                value={assessmentData.name}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, name: value }))}
                                required
                            />
                            
                            <SingleSelectField
                                label={i18n.t('Assessment Type')}
                                selected={assessmentData.assessmentType}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, assessmentType: selected }))}
                            >
                                {assessmentTypes.map(type => (
                                    <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                                ))}
                            </SingleSelectField>
                        </div>

                        {/* Metadata Source Selection */}
                        <div style={{ 
                            marginBottom: '32px', 
                            padding: '24px', 
                            backgroundColor: '#f8f9fa', 
                            borderRadius: '8px', 
                            border: '2px solid #e9ecef' 
                        }}>
                            <h4 style={{ 
                                margin: '0 0 16px 0', 
                                fontSize: '18px', 
                                fontWeight: '600', 
                                color: '#495057' 
                            }}>
                                {i18n.t('Metadata Source')} *
                            </h4>
                            <div style={{ fontSize: '14px', color: '#6c757d', marginBottom: '20px' }}>
                                {i18n.t('Choose how you want to define the metadata for your assessment')}
                            </div>
                            
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                                <label style={{ 
                                    display: 'flex', 
                                    alignItems: 'flex-start', 
                                    padding: '20px', 
                                    border: metadataSource === 'dhis2' ? '2px solid #0d7377' : '2px solid #e0e0e0', 
                                    borderRadius: '8px', 
                                    cursor: 'pointer', 
                                    backgroundColor: metadataSource === 'dhis2' ? '#f0f8ff' : 'white',
                                    transition: 'all 0.2s ease'
                                }}>
                                    <input
                                        type="radio"
                                        name="metadataSource"
                                        value="dhis2"
                                        checked={metadataSource === 'dhis2'}
                                        onChange={e => setMetadataSource(e.target.value)}
                                        style={{ marginRight: '16px', marginTop: '4px', transform: 'scale(1.2)' }}
                                    />
                                    <div>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', fontSize: '16px', color: '#212529' }}>
                                            🔗 {i18n.t('Connect to DHIS2 Instance')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d', lineHeight: '1.5' }}>
                                            {i18n.t('Pull metadata from an existing DHIS2 system. Configure connection, select datasets, data elements, and organization units.')}
                                        </div>
                                        {metadataSource === 'dhis2' && (
                                            <div style={{ 
                                                marginTop: '12px', 
                                                padding: '8px 12px', 
                                                backgroundColor: '#d1ecf1', 
                                                borderRadius: '4px', 
                                                fontSize: '12px', 
                                                color: '#0c5460',
                                                fontWeight: '500'
                                            }}>
                                                ✓ {i18n.t('Selected: DHIS2 metadata will be imported')}
                                            </div>
                                        )}
                                    </div>
                                </label>
                                
                                <label style={{ 
                                    display: 'flex', 
                                    alignItems: 'flex-start', 
                                    padding: '20px', 
                                    border: metadataSource === 'manual' ? '2px solid #0d7377' : '2px solid #e0e0e0', 
                                    borderRadius: '8px', 
                                    cursor: 'pointer', 
                                    backgroundColor: metadataSource === 'manual' ? '#f0f8ff' : 'white',
                                    transition: 'all 0.2s ease'
                                }}>
                                    <input
                                        type="radio"
                                        name="metadataSource"
                                        value="manual"
                                        checked={metadataSource === 'manual'}
                                        onChange={e => setMetadataSource(e.target.value)}
                                        style={{ marginRight: '16px', marginTop: '4px', transform: 'scale(1.2)' }}
                                    />
                                    <div>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', fontSize: '16px', color: '#212529' }}>
                                            ✏️ {i18n.t('Create Metadata Manually')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d', lineHeight: '1.5' }}>
                                            {i18n.t('Define custom datasets, data elements, and organization units. Choose data separation strategy and naming conventions.')}
                                        </div>
                                        {metadataSource === 'manual' && (
                                            <div style={{ 
                                                marginTop: '12px', 
                                                padding: '8px 12px', 
                                                backgroundColor: '#d1ecf1', 
                                                borderRadius: '4px', 
                                                fontSize: '12px', 
                                                color: '#0c5460',
                                                fontWeight: '500'
                                            }}>
                                                ✓ {i18n.t('Selected: Custom metadata will be created')}
                                            </div>
                                        )}
                                    </div>
                                </label>
                            </div>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            <InputField
                                label={i18n.t('Start Date')}
                                type="date"
                                value={assessmentData.startDate}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, startDate: value }))}
                                required
                            />
                            
                            <InputField
                                label={i18n.t('End Date')}
                                type="date"
                                value={assessmentData.endDate}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, endDate: value }))}
                                required
                            />
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            <SingleSelectField
                                label={i18n.t('Priority')}
                                selected={assessmentData.priority}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, priority: selected }))}
                            >
                                {priorities.map(priority => (
                                    <SingleSelectOption key={priority.value} value={priority.value} label={priority.label} />
                                ))}
                            </SingleSelectField>
                            
                            <SingleSelectField
                                label={i18n.t('Methodology')}
                                selected={assessmentData.methodology}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, methodology: selected }))}
                            >
                                {methodologies.map(methodology => (
                                    <SingleSelectOption key={methodology.value} value={methodology.value} label={methodology.label} />
                                ))}
                            </SingleSelectField>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            <SingleSelectField
                                label={i18n.t('Frequency')}
                                selected={assessmentData.frequency}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, frequency: selected }))}
                            >
                                {frequencies.map(frequency => (
                                    <SingleSelectOption key={frequency.value} value={frequency.value} label={frequency.label} />
                                ))}
                            </SingleSelectField>
                            
                            <SingleSelectField
                                label={i18n.t('Reporting Level')}
                                selected={assessmentData.reportingLevel}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, reportingLevel: selected }))}
                            >
                                {reportingLevels.map(level => (
                                    <SingleSelectOption key={level.value} value={level.value} label={level.label} />
                                ))}
                            </SingleSelectField>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <MultiSelectField
                                label={i18n.t('Data Quality Dimensions')}
                                selected={assessmentData.dataQualityDimensions}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, dataQualityDimensions: selected }))}
                            >
                                {dataQualityDimensions.map(dimension => (
                                    <MultiSelectOption key={dimension.value} value={dimension.value} label={dimension.label} />
                                ))}
                            </MultiSelectField>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <TextAreaField
                                label={i18n.t('Description')}
                                placeholder={i18n.t('Enter assessment description')}
                                value={assessmentData.description}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, description: value }))}
                                rows={4}
                            />
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <TextAreaField
                                label={i18n.t('Objectives')}
                                placeholder={i18n.t('Enter assessment objectives')}
                                value={assessmentData.objectives}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, objectives: value }))}
                                rows={3}
                            />
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <TextAreaField
                                label={i18n.t('Scope')}
                                placeholder={i18n.t('Define the scope of the assessment')}
                                value={assessmentData.scope}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, scope: value }))}
                                rows={3}
                            />
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <TextAreaField
                                label={i18n.t('Success Criteria')}
                                placeholder={i18n.t('Define success criteria for the assessment')}
                                value={assessmentData.successCriteria}
                                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, successCriteria: value }))}
                                rows={3}
                            />
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            <SingleSelectField
                                label={i18n.t('Confidentiality Level')}
                                selected={assessmentData.confidentialityLevel}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, confidentialityLevel: selected }))}
                            >
                                {confidentialityLevels.map(level => (
                                    <SingleSelectOption key={level.value} value={level.value} label={level.label} />
                                ))}
                            </SingleSelectField>
                            
                            <SingleSelectField
                                label={i18n.t('Data Retention Period')}
                                selected={assessmentData.dataRetentionPeriod}
                                onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, dataRetentionPeriod: selected }))}
                            >
                                {dataRetentionPeriods.map(period => (
                                    <SingleSelectOption key={period.value} value={period.value} label={period.label} />
                                ))}
                            </SingleSelectField>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', fontWeight: '600', color: '#2c3e50' }}>
                                {i18n.t('Assessment Settings')}
                            </h4>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                                <div>
                                    <Checkbox
                                        label={i18n.t('Enable Notifications')}
                                        checked={assessmentData.notifications}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, notifications: checked }))}
                                    />
                                </div>
                                <div>
                                    <Checkbox
                                        label={i18n.t('Auto Sync Data')}
                                        checked={assessmentData.autoSync}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, autoSync: checked }))}
                                    />
                                </div>
                                <div>
                                    <Checkbox
                                        label={i18n.t('Validation Alerts')}
                                        checked={assessmentData.validationAlerts}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, validationAlerts: checked }))}
                                    />
                                </div>
                                <div>
                                    <Checkbox
                                        label={i18n.t('Historical Comparison')}
                                        checked={assessmentData.historicalComparison}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, historicalComparison: checked }))}
                                    />
                                </div>
                                <div>
                                    <Checkbox
                                        label={i18n.t('Public Access')}
                                        checked={assessmentData.publicAccess}
                                        onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, publicAccess: checked }))}
                                    />
                                </div>
                            </div>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <InputField
                                label={i18n.t('Tags')}
                                placeholder={i18n.t('Enter tags separated by commas')}
                                value={assessmentData.tags.join(', ')}
                                onChange={({ value }) => {
                                    const tags = value.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0)
                                    setAssessmentData(prev => ({ ...prev, tags }))
                                }}
                                helpText={i18n.t('Use tags to categorize and organize assessments')}
                            />
                        </div>
                    </div>
                )

            case 'connection':
                if (metadataSource === 'dhis2') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <DHIS2Configuration
                                value={dhis2Config}
                                onChange={setDhis2Config}
                            />
                        </div>
                    )
                } else if (metadataSource === 'manual') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ 
                                textAlign: 'center', 
                                padding: '60px 20px',
                                backgroundColor: '#f8f9fa',
                                borderRadius: '8px',
                                border: '2px dashed #dee2e6'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>✅</div>
                                <h3 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '24px', 
                                    fontWeight: '600', 
                                    color: '#28a745' 
                                }}>
                                    {i18n.t('Manual Metadata Mode')}
                                </h3>
                                <p style={{ 
                                    fontSize: '16px', 
                                    color: '#6c757d', 
                                    margin: '0 0 20px 0',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('No DHIS2 connection required. You will create custom datasets, data elements, and organization units in the following steps.')}
                                </p>
                                <div style={{ 
                                    padding: '16px', 
                                    backgroundColor: '#d1ecf1', 
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    color: '#0c5460'
                                }}>
                                    💡 {i18n.t('Tip: This mode is perfect for pilot assessments or when you want full control over your metadata structure.')}
                                </div>
                            </div>
                        </div>
                    )
                } else {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ 
                                textAlign: 'center', 
                                padding: '60px 20px',
                                backgroundColor: '#fff3cd',
                                borderRadius: '8px',
                                border: '2px dashed #ffeaa7'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>⚠️</div>
                                <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', color: '#856404' }}>
                                    {i18n.t('Please Select Metadata Source')}
                                </h3>
                                <p style={{ fontSize: '16px', color: '#856404', margin: 0 }}>
                                    {i18n.t('Go back to Assessment Details and choose your metadata source to continue.')}
                                </p>
                            </div>
                        </div>
                    )
                }

            case 'datasets':
                if (metadataSource === 'dhis2') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <AssessmentDataSetSelection
                                dhis2Config={dhis2Config}
                                multiSelect={true}
                                selectedDataSets={selectedDataSets}
                                onDataSetsSelected={setSelectedDataSets}
                                mode="datasets"
                            />
                        </div>
                    )
                } else if (metadataSource === 'manual') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ marginBottom: '24px' }}>
                                <h3 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '20px', 
                                    fontWeight: '600',
                                    color: '#2c3e50'
                                }}>
                                    {i18n.t('Create Custom Datasets')}
                                </h3>
                                <p style={{ fontSize: '14px', color: '#6c757d', margin: '0 0 24px 0' }}>
                                    {i18n.t('Define the datasets that will organize your data elements for the assessment.')}
                                </p>
                            </div>
                            
                            <div style={{ 
                                padding: '32px', 
                                backgroundColor: '#f8f9fa', 
                                borderRadius: '8px',
                                border: '2px dashed #dee2e6',
                                textAlign: 'center'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>📊</div>
                                <h4 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '18px', 
                                    fontWeight: '600', 
                                    color: '#495057' 
                                }}>
                                    {i18n.t('Manual Dataset Creation')}
                                </h4>
                                <p style={{ 
                                    fontSize: '16px', 
                                    color: '#6c757d', 
                                    margin: '0 0 24px 0',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('Create custom datasets to organize your data collection. You can define multiple datasets for different data sources (Register, Summary, Reported, Corrected).')}
                                </p>
                                
                                <div style={{ 
                                    display: 'grid', 
                                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
                                    gap: '16px',
                                    marginBottom: '24px'
                                }}>
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            📋 {i18n.t('Register Dataset')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Data from facility registers')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            📈 {i18n.t('Summary Dataset')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Aggregated summary data')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            📊 {i18n.t('Reported Dataset')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Officially reported data')}
                                        </div>
                                    </div>
                                </div>
                                
                                <div style={{ 
                                    padding: '16px', 
                                    backgroundColor: '#d1ecf1', 
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    color: '#0c5460',
                                    marginBottom: '20px'
                                }}>
                                    💡 {i18n.t('Coming Soon: Interactive dataset creation interface will be available here.')}
                                </div>
                                
                                <ButtonStrip>
                                    <Button 
                                        primary 
                                        onClick={() => openDatasetModal()}
                                    >
                                        {i18n.t('Create New Dataset')}
                                    </Button>
                                    <Button 
                                        secondary 
                                        onClick={() => {
                                            // Create default DQA datasets
                                            const defaultDatasets = [
                                                {
                                                    id: `ds_register_${Date.now()}`,
                                                    name: `${assessmentData.name || 'Assessment'} - Register`,
                                                    shortName: 'Register',
                                                    description: 'Data from facility registers',
                                                    periodType: 'Monthly',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `ds_summary_${Date.now() + 1}`,
                                                    name: `${assessmentData.name || 'Assessment'} - Summary`,
                                                    shortName: 'Summary',
                                                    description: 'Aggregated summary data',
                                                    periodType: 'Monthly',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `ds_reported_${Date.now() + 2}`,
                                                    name: `${assessmentData.name || 'Assessment'} - Reported`,
                                                    shortName: 'Reported',
                                                    description: 'Officially reported data',
                                                    periodType: 'Monthly',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                }
                                            ]
                                            setSelectedDataSets(defaultDatasets)
                                        }}
                                    >
                                        {i18n.t('Create Default DQA Datasets')}
                                    </Button>
                                </ButtonStrip>
                            </div>
                            
                            {selectedDataSets.length > 0 && (
                                <div style={{ marginTop: '24px' }}>
                                    <h4 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600' }}>
                                        {i18n.t('Created Datasets')} ({selectedDataSets.length})
                                    </h4>
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                        {selectedDataSets.map((dataset, index) => (
                                            <div key={index} style={{ 
                                                padding: '12px 16px', 
                                                backgroundColor: '#e8f5e8', 
                                                borderRadius: '6px',
                                                border: '1px solid #c3e6c3',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div style={{ flex: 1 }}>
                                                    <div style={{ fontWeight: '600', color: '#155724' }}>{dataset.name}</div>
                                                    <div style={{ fontSize: '14px', color: '#6c757d' }}>{dataset.description}</div>
                                                    <div style={{ fontSize: '12px', color: '#6c757d', marginTop: '4px' }}>
                                                        {i18n.t('Period: {{period}}', { period: dataset.periodType || 'Monthly' })} | 
                                                        {i18n.t(' Category: {{category}}', { category: dataset.categoryCombo || 'Default' })}
                                                    </div>
                                                </div>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                    <Button 
                                                        small 
                                                        secondary 
                                                        onClick={() => openDatasetModal(dataset)}
                                                    >
                                                        {i18n.t('Edit')}
                                                    </Button>
                                                    <Button 
                                                        small 
                                                        destructive 
                                                        onClick={() => deleteDataset(dataset.id)}
                                                    >
                                                        {i18n.t('Delete')}
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )
                } else {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ 
                                textAlign: 'center', 
                                padding: '60px 20px',
                                backgroundColor: '#fff3cd',
                                borderRadius: '8px',
                                border: '2px dashed #ffeaa7'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>⚠️</div>
                                <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', color: '#856404' }}>
                                    {i18n.t('Please Select Metadata Source')}
                                </h3>
                                <p style={{ fontSize: '16px', color: '#856404', margin: 0 }}>
                                    {i18n.t('Go back to Assessment Details and choose your metadata source to continue.')}
                                </p>
                            </div>
                        </div>
                    )
                }

            case 'elements':
                if (metadataSource === 'dhis2') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <AssessmentDataSetSelection
                                dhis2Config={dhis2Config}
                                multiSelect={true}
                                selectedDataSets={selectedDataSets}
                                onDataSetsSelected={setSelectedDataSets}
                                selectedDataElements={selectedDataElements}
                                onDataElementsSelected={setSelectedDataElements}
                                mode="dataelements"
                            />
                        </div>
                    )
                } else if (metadataSource === 'manual') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ marginBottom: '24px' }}>
                                <h3 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '20px', 
                                    fontWeight: '600',
                                    color: '#2c3e50'
                                }}>
                                    {i18n.t('Create Data Elements')}
                                </h3>
                                <p style={{ fontSize: '14px', color: '#6c757d', margin: '0 0 24px 0' }}>
                                    {i18n.t('Define the data elements that will be collected in your assessment.')}
                                </p>
                            </div>
                            
                            <div style={{ 
                                padding: '32px', 
                                backgroundColor: '#f8f9fa', 
                                borderRadius: '8px',
                                border: '2px dashed #dee2e6',
                                textAlign: 'center'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>🔢</div>
                                <h4 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '18px', 
                                    fontWeight: '600', 
                                    color: '#495057' 
                                }}>
                                    {i18n.t('Manual Data Element Creation')}
                                </h4>
                                <p style={{ 
                                    fontSize: '16px', 
                                    color: '#6c757d', 
                                    margin: '0 0 24px 0',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('Create custom data elements for your assessment. These will be the individual data points you collect and compare.')}
                                </p>
                                
                                <div style={{ 
                                    display: 'grid', 
                                    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', 
                                    gap: '16px',
                                    marginBottom: '24px'
                                }}>
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            👥 {i18n.t('Patients Treated')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Number of patients treated')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            💊 {i18n.t('Medicines Dispensed')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Number of medicines dispensed')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            🏥 {i18n.t('Facility Visits')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Number of facility visits')}
                                        </div>
                                    </div>
                                </div>
                                
                                <div style={{ 
                                    padding: '16px', 
                                    backgroundColor: '#d1ecf1', 
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    color: '#0c5460',
                                    marginBottom: '20px'
                                }}>
                                    💡 {i18n.t('Coming Soon: Interactive data element creation interface will be available here.')}
                                </div>
                                
                                <ButtonStrip>
                                    <Button 
                                        primary 
                                        onClick={() => openDataElementModal()}
                                    >
                                        {i18n.t('Create New Data Element')}
                                    </Button>
                                    <Button 
                                        secondary 
                                        onClick={() => {
                                            // Create default DQA data elements
                                            const defaultElements = [
                                                {
                                                    id: `de_patients_treated_${Date.now()}`,
                                                    name: 'Patients Treated',
                                                    shortName: 'Patients Treated',
                                                    description: 'Total number of patients treated',
                                                    valueType: 'INTEGER',
                                                    domainType: 'AGGREGATE',
                                                    aggregationType: 'SUM',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `de_medicines_dispensed_${Date.now() + 1}`,
                                                    name: 'Medicines Dispensed',
                                                    shortName: 'Medicines Dispensed',
                                                    description: 'Total number of medicines dispensed',
                                                    valueType: 'INTEGER',
                                                    domainType: 'AGGREGATE',
                                                    aggregationType: 'SUM',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `de_facility_visits_${Date.now() + 2}`,
                                                    name: 'Facility Visits',
                                                    shortName: 'Facility Visits',
                                                    description: 'Total number of facility visits',
                                                    valueType: 'INTEGER',
                                                    domainType: 'AGGREGATE',
                                                    aggregationType: 'SUM',
                                                    categoryCombo: 'dqa_sources',
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                }
                                            ]
                                            setSelectedDataElements(defaultElements)
                                        }}
                                    >
                                        {i18n.t('Create Default DQA Data Elements')}
                                    </Button>
                                </ButtonStrip>
                            </div>
                            
                            {selectedDataElements.length > 0 && (
                                <div style={{ marginTop: '24px' }}>
                                    <h4 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600' }}>
                                        {i18n.t('Created Data Elements')} ({selectedDataElements.length})
                                    </h4>
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                        {selectedDataElements.map((element, index) => (
                                            <div key={index} style={{ 
                                                padding: '12px 16px', 
                                                backgroundColor: '#e8f5e8', 
                                                borderRadius: '6px',
                                                border: '1px solid #c3e6c3',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div style={{ flex: 1 }}>
                                                    <div style={{ fontWeight: '600', color: '#155724' }}>{element.name}</div>
                                                    <div style={{ fontSize: '14px', color: '#6c757d' }}>{element.description}</div>
                                                    <div style={{ fontSize: '12px', color: '#6c757d', marginTop: '4px' }}>
                                                        {i18n.t('Type: {{type}}', { type: element.valueType || 'INTEGER' })} | 
                                                        {i18n.t(' Aggregation: {{agg}}', { agg: element.aggregationType || 'SUM' })}
                                                    </div>
                                                </div>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                    <Button 
                                                        small 
                                                        secondary 
                                                        onClick={() => openDataElementModal(element)}
                                                    >
                                                        {i18n.t('Edit')}
                                                    </Button>
                                                    <Button 
                                                        small 
                                                        destructive 
                                                        onClick={() => deleteDataElement(element.id)}
                                                    >
                                                        {i18n.t('Delete')}
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )
                } else {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ 
                                textAlign: 'center', 
                                padding: '60px 20px',
                                backgroundColor: '#fff3cd',
                                borderRadius: '8px',
                                border: '2px dashed #ffeaa7'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>⚠️</div>
                                <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', color: '#856404' }}>
                                    {i18n.t('Please Select Metadata Source')}
                                </h3>
                                <p style={{ fontSize: '16px', color: '#856404', margin: 0 }}>
                                    {i18n.t('Go back to Assessment Details and choose your metadata source to continue.')}
                                </p>
                            </div>
                        </div>
                    )
                }

            case 'units':
                if (metadataSource === 'dhis2') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <OrganisationUnitManagement
                                dhis2Config={dhis2Config}
                                dataSets={selectedDataSets}
                                selectedDataElements={selectedDataElements}
                                value={selectedOrgUnits}
                                onChange={setSelectedOrgUnits}
                            />
                        </div>
                    )
                } else if (metadataSource === 'manual') {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ marginBottom: '24px' }}>
                                <h3 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '20px', 
                                    fontWeight: '600',
                                    color: '#2c3e50'
                                }}>
                                    {i18n.t('Create Organization Units')}
                                </h3>
                                <p style={{ fontSize: '14px', color: '#6c757d', margin: '0 0 24px 0' }}>
                                    {i18n.t('Define the organization units (facilities, districts, regions) for your assessment.')}
                                </p>
                            </div>
                            
                            <div style={{ 
                                padding: '32px', 
                                backgroundColor: '#f8f9fa', 
                                borderRadius: '8px',
                                border: '2px dashed #dee2e6',
                                textAlign: 'center'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>🏢</div>
                                <h4 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '18px', 
                                    fontWeight: '600', 
                                    color: '#495057' 
                                }}>
                                    {i18n.t('Manual Organization Unit Creation')}
                                </h4>
                                <p style={{ 
                                    fontSize: '16px', 
                                    color: '#6c757d', 
                                    margin: '0 0 24px 0',
                                    lineHeight: '1.5'
                                }}>
                                    {i18n.t('Create custom organization units for your assessment. These represent the facilities or administrative units where data will be collected.')}
                                </p>
                                
                                <div style={{ 
                                    display: 'grid', 
                                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
                                    gap: '16px',
                                    marginBottom: '24px'
                                }}>
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            🏥 {i18n.t('Health Facilities')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Hospitals, clinics, health centers')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            🏛️ {i18n.t('Districts')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Administrative districts')}
                                        </div>
                                    </div>
                                    
                                    <div style={{ 
                                        padding: '16px', 
                                        backgroundColor: 'white', 
                                        borderRadius: '6px',
                                        border: '1px solid #e9ecef'
                                    }}>
                                        <div style={{ fontWeight: '600', marginBottom: '8px', color: '#495057' }}>
                                            🌍 {i18n.t('Regions')}
                                        </div>
                                        <div style={{ fontSize: '14px', color: '#6c757d' }}>
                                            {i18n.t('Regional administrative units')}
                                        </div>
                                    </div>
                                </div>
                                
                                <div style={{ 
                                    padding: '16px', 
                                    backgroundColor: '#d1ecf1', 
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    color: '#0c5460',
                                    marginBottom: '20px'
                                }}>
                                    💡 {i18n.t('Coming Soon: Interactive organization unit creation interface will be available here.')}
                                </div>
                                
                                <ButtonStrip>
                                    <Button 
                                        primary 
                                        onClick={() => openOrgUnitModal()}
                                    >
                                        {i18n.t('Create New Organisation Unit')}
                                    </Button>
                                    <Button 
                                        secondary 
                                        onClick={() => {
                                            // Create default DQA org units
                                            const defaultOrgUnits = [
                                                {
                                                    id: `ou_central_hospital_${Date.now()}`,
                                                    name: 'Central Hospital',
                                                    shortName: 'Central Hospital',
                                                    description: 'Main referral hospital',
                                                    level: 4,
                                                    parent: null,
                                                    path: `/ou_central_hospital_${Date.now()}`,
                                                    leaf: true,
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `ou_health_center_${Date.now() + 1}`,
                                                    name: 'Community Health Center',
                                                    shortName: 'Health Center',
                                                    description: 'Primary health care facility',
                                                    level: 4,
                                                    parent: null,
                                                    path: `/ou_health_center_${Date.now() + 1}`,
                                                    leaf: true,
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                },
                                                {
                                                    id: `ou_rural_clinic_${Date.now() + 2}`,
                                                    name: 'Rural Clinic',
                                                    shortName: 'Rural Clinic',
                                                    description: 'Rural health clinic',
                                                    level: 4,
                                                    parent: null,
                                                    path: `/ou_rural_clinic_${Date.now() + 2}`,
                                                    leaf: true,
                                                    created: new Date().toISOString(),
                                                    lastUpdated: new Date().toISOString()
                                                }
                                            ]
                                            setSelectedOrgUnits(defaultOrgUnits)
                                        }}
                                    >
                                        {i18n.t('Create Default Health Facilities')}
                                    </Button>
                                </ButtonStrip>
                            </div>
                            
                            {selectedOrgUnits.length > 0 && (
                                <div style={{ marginTop: '24px' }}>
                                    <h4 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '600' }}>
                                        {i18n.t('Created Organization Units')} ({selectedOrgUnits.length})
                                    </h4>
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                        {selectedOrgUnits.map((orgUnit, index) => (
                                            <div key={index} style={{ 
                                                padding: '12px 16px', 
                                                backgroundColor: '#e8f5e8', 
                                                borderRadius: '6px',
                                                border: '1px solid #c3e6c3',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between'
                                            }}>
                                                <div style={{ flex: 1 }}>
                                                    <div style={{ fontWeight: '600', color: '#155724' }}>{orgUnit.name}</div>
                                                    <div style={{ fontSize: '14px', color: '#6c757d' }}>{orgUnit.description}</div>
                                                    <div style={{ fontSize: '12px', color: '#6c757d', marginTop: '4px' }}>
                                                        {i18n.t('Level: {{level}}', { level: orgUnit.level || 4 })} | 
                                                        {i18n.t(' Type: {{type}}', { type: orgUnit.leaf ? 'Facility' : 'Administrative' })}
                                                    </div>
                                                </div>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                    <Button 
                                                        small 
                                                        secondary 
                                                        onClick={() => openOrgUnitModal(orgUnit)}
                                                    >
                                                        {i18n.t('Edit')}
                                                    </Button>
                                                    <Button 
                                                        small 
                                                        destructive 
                                                        onClick={() => deleteOrgUnit(orgUnit.id)}
                                                    >
                                                        {i18n.t('Delete')}
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )
                } else {
                    return (
                        <div style={{ padding: '20px 40px', width: '100%' }}>
                            <div style={{ 
                                textAlign: 'center', 
                                padding: '60px 20px',
                                backgroundColor: '#fff3cd',
                                borderRadius: '8px',
                                border: '2px dashed #ffeaa7'
                            }}>
                                <div style={{ fontSize: '48px', marginBottom: '20px' }}>⚠️</div>
                                <h3 style={{ margin: '0 0 16px 0', fontSize: '20px', color: '#856404' }}>
                                    {i18n.t('Please Select Metadata Source')}
                                </h3>
                                <p style={{ fontSize: '16px', color: '#856404', margin: 0 }}>
                                    {i18n.t('Go back to Assessment Details and choose your metadata source to continue.')}
                                </p>
                            </div>
                        </div>
                    )
                }

            case 'mapping':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <OrganizationUnitMapping
                            dhis2Config={dhis2Config}
                            selectedOrgUnits={selectedOrgUnits}
                            value={orgUnitMappings}
                            onChange={setOrgUnitMappings}
                            onNext={() => changeTab('preparation')}
                        />
                    </div>
                )

            case 'preparation':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <DatasetPreparation
                            dhis2Config={dhis2Config}
                            selectedDataSets={selectedDataSets}
                            selectedDataElements={selectedDataElements}
                            orgUnitMappings={orgUnitMappings}
                            assessmentName={assessmentData.name}
                            period={`${new Date().getFullYear()}Q${Math.ceil((new Date().getMonth() + 1) / 3)}`}
                            onSave={(data) => {
                                console.log('Assessment metadata saved:', data)
                            }}
                            onFinish={(data) => {
                                console.log('Datasets created:', data)
                                setDatasetPreparationComplete(true)
                                changeTab('review')
                            }}
                        />
                    </div>
                )

            case 'review':
                return (
                    <div style={{ padding: '20px 40px', width: '100%' }}>
                        <h3 style={{ 
                            margin: '0 0 20px 0', 
                            fontSize: '20px', 
                            fontWeight: '600',
                            color: '#2c3e50'
                        }}>
                            {i18n.t('Review Assessment Configuration')}
                        </h3>
                        
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                            {/* Basic Information */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Basic Information')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Name')}:</strong> {assessmentData.name}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Type')}:</strong> {assessmentTypes.find(t => t.value === assessmentData.assessmentType)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Priority')}:</strong> {priorities.find(p => p.value === assessmentData.priority)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Reporting Level')}:</strong> {reportingLevels.find(r => r.value === assessmentData.reportingLevel)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Period')}:</strong> {assessmentData.startDate} to {assessmentData.endDate}</p>
                                    {assessmentData.description && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Description')}:</strong> {assessmentData.description.substring(0, 100)}{assessmentData.description.length > 100 ? '...' : ''}</p>
                                    )}
                                    {assessmentData.objectives && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Objectives')}:</strong> {assessmentData.objectives.substring(0, 80)}{assessmentData.objectives.length > 80 ? '...' : ''}</p>
                                    )}
                                    {assessmentData.scope && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Scope')}:</strong> {assessmentData.scope.substring(0, 80)}{assessmentData.scope.length > 80 ? '...' : ''}</p>
                                    )}
                                </div>
                            </div>

                            {/* Configuration */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Configuration')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('DHIS2 URL')}:</strong> {dhis2Config?.baseUrl || i18n.t('Not configured')}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Datasets')}:</strong> {selectedDataSets.length}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Data Elements')}:</strong> {selectedDataElements.length}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Organisation Units')}:</strong> {selectedOrgUnits.length}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Confidentiality')}:</strong> {confidentialityLevels.find(c => c.value === assessmentData.confidentialityLevel)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Data Retention')}:</strong> {dataRetentionPeriods.find(d => d.value === assessmentData.dataRetentionPeriod)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Public Access')}:</strong> {assessmentData.publicAccess ? i18n.t('Yes') : i18n.t('No')}</p>
                                </div>
                            </div>

            {/* Assessment Settings */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Assessment Settings')}
                                </h4>
                                <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Methodology')}:</strong> {methodologies.find(m => m.value === assessmentData.methodology)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Frequency')}:</strong> {frequencies.find(f => f.value === assessmentData.frequency)?.label}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Notifications')}:</strong> {assessmentData.notifications ? i18n.t('Enabled') : i18n.t('Disabled')}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Auto Sync')}:</strong> {assessmentData.autoSync ? i18n.t('Enabled') : i18n.t('Disabled')}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Validation Alerts')}:</strong> {assessmentData.validationAlerts ? i18n.t('Enabled') : i18n.t('Disabled')}</p>
                                    <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Historical Comparison')}:</strong> {assessmentData.historicalComparison ? i18n.t('Enabled') : i18n.t('Disabled')}</p>
                                    {assessmentData.tags.length > 0 && (
                                        <p style={{ margin: '0 0 6px 0' }}><strong>{i18n.t('Tags')}:</strong> {assessmentData.tags.join(', ')}</p>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Data Quality Dimensions */}
                        <div style={{ marginBottom: '20px' }}>
                            <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                {i18n.t('Data Quality Dimensions')} ({assessmentData.dataQualityDimensions.length})
                            </h4>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '12px' }}>
                                {assessmentData.dataQualityDimensions.map(dimensionValue => {
                                    const dimension = dataQualityDimensions.find(d => d.value === dimensionValue)
                                    return dimension ? (
                                        <Tag key={dimensionValue} positive small>
                                            {dimension.label}
                                        </Tag>
                                    ) : null
                                })}
                            </div>
                        </div>

                        {/* Additional Details */}
                        {(assessmentData.successCriteria || assessmentData.objectives || assessmentData.scope) && (
                            <div style={{ marginBottom: '20px' }}>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Additional Details')}
                                </h4>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                                    {assessmentData.objectives && (
                                        <div>
                                            <strong style={{ fontSize: '14px' }}>{i18n.t('Objectives')}:</strong>
                                            <p style={{ margin: '4px 0 0 0', fontSize: '13px', lineHeight: '1.4', color: '#666' }}>
                                                {assessmentData.objectives}
                                            </p>
                                        </div>
                                    )}
                                    {assessmentData.scope && (
                                        <div>
                                            <strong style={{ fontSize: '14px' }}>{i18n.t('Scope')}:</strong>
                                            <p style={{ margin: '4px 0 0 0', fontSize: '13px', lineHeight: '1.4', color: '#666' }}>
                                                {assessmentData.scope}
                                            </p>
                                        </div>
                                    )}
                                    {assessmentData.successCriteria && (
                                        <div>
                                            <strong style={{ fontSize: '14px' }}>{i18n.t('Success Criteria')}:</strong>
                                            <p style={{ margin: '4px 0 0 0', fontSize: '13px', lineHeight: '1.4', color: '#666' }}>
                                                {assessmentData.successCriteria}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Selected Items Details */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
                            {/* Selected Datasets */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Datasets')} ({selectedDataSets.length})
                                </h4>
                                <div style={{ maxHeight: '200px', overflowY: 'auto', fontSize: '14px' }}>
                                    {selectedDataSets.map(dataset => (
                                        <div key={dataset.id} style={{ padding: '4px 0', borderBottom: '1px solid #f0f0f0' }}>
                                            {dataset.displayName}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Selected Data Elements */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Data Elements')} ({selectedDataElements.length})
                                </h4>
                                <div style={{ maxHeight: '200px', overflowY: 'auto', fontSize: '14px' }}>
                                    {selectedDataElements.slice(0, 10).map(element => (
                                        <div key={element.id} style={{ padding: '4px 0', borderBottom: '1px solid #f0f0f0' }}>
                                            {element.displayName}
                                        </div>
                                    ))}
                                    {selectedDataElements.length > 10 && (
                                        <div style={{ padding: '4px 0', fontStyle: 'italic', color: '#666' }}>
                                            {i18n.t('... and {{count}} more', { count: selectedDataElements.length - 10 })}
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Selected Organisation Units */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Selected Organisation Units')} ({selectedOrgUnits.length})
                                </h4>
                                <div style={{ maxHeight: '200px', overflowY: 'auto', fontSize: '14px' }}>
                                    {selectedOrgUnits.slice(0, 10).map(unit => (
                                        <div key={unit.id} style={{ padding: '4px 0', borderBottom: '1px solid #f0f0f0' }}>
                                            {unit.displayName}
                                        </div>
                                    ))}
                                    {selectedOrgUnits.length > 10 && (
                                        <div style={{ padding: '4px 0', fontStyle: 'italic', color: '#666' }}>
                                            {i18n.t('... and {{count}} more', { count: selectedOrgUnits.length - 10 })}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Organization Unit Mappings and Dataset Preparation */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' }}>
                            {/* Organization Unit Mappings */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Organization Unit Mappings')} ({orgUnitMappings.filter(m => m.mapped).length}/{orgUnitMappings.length})
                                </h4>
                                <div style={{ maxHeight: '200px', overflowY: 'auto', fontSize: '14px' }}>
                                    {orgUnitMappings.filter(m => m.mapped).slice(0, 10).map(mapping => (
                                        <div key={mapping.external.id} style={{ padding: '4px 0', borderBottom: '1px solid #f0f0f0' }}>
                                            <div style={{ fontWeight: '500' }}>{mapping.external.displayName}</div>
                                            <div style={{ fontSize: '12px', color: '#666' }}>→ {mapping.local?.displayName}</div>
                                        </div>
                                    ))}
                                    {orgUnitMappings.filter(m => m.mapped).length > 10 && (
                                        <div style={{ padding: '4px 0', fontStyle: 'italic', color: '#666' }}>
                                            {i18n.t('... and {{count}} more mappings', { count: orgUnitMappings.filter(m => m.mapped).length - 10 })}
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Dataset Preparation Status */}
                            <div>
                                <h4 style={{ margin: '0 0 12px 0', color: '#495057', fontSize: '16px', fontWeight: '600' }}>
                                    {i18n.t('Dataset Preparation')}
                                </h4>
                                <div style={{ fontSize: '14px' }}>
                                    {datasetPreparationComplete ? (
                                        <div style={{ color: '#28a745', fontWeight: '500' }}>
                                            ✓ {i18n.t('4 datasets prepared and created successfully')}
                                        </div>
                                    ) : (
                                        <div style={{ color: '#dc3545' }}>
                                            ✗ {i18n.t('Dataset preparation not completed')}
                                        </div>
                                    )}
                                    <div style={{ marginTop: '8px', fontSize: '12px', color: '#666' }}>
                                        {i18n.t('Register, Summary, Reported, and Correction datasets')}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )

            default:
                return <div>{i18n.t('Tab content not found')}</div>
        }
    }

    // Navigation component
    const renderNavigation = (position = 'bottom') => (
        <div style={{ 
            padding: '16px 24px',
            borderTop: position === 'bottom' ? '1px solid #e8eaed' : 'none',
            borderBottom: position === 'top' ? '1px solid #e8eaed' : 'none',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: position === 'top' ? '#f8f9fa' : 'transparent'
        }}>
            <Button 
                secondary 
                onClick={handlePrevious}
                disabled={activeTab === 'details'}
            >
                {i18n.t('Previous')}
            </Button>

            <div style={{ display: 'flex', gap: '12px' }}>
                {activeTab === 'review' ? (
                    <Button 
                        primary 
                        onClick={handleCreateAssessment}
                        loading={loading}
                        disabled={!isTabValid('review')}
                    >
                        {i18n.t('Create Assessment')}
                    </Button>
                ) : (
                    <Button 
                        primary 
                        onClick={handleNext}
                        disabled={!isTabValid(activeTab)}
                    >
                        {i18n.t('Next')}
                    </Button>
                )}
            </div>
        </div>
    )

    return (
        <Box padding="24px">
            <Card style={{ minHeight: '600px' }}>
                {/* Header */}
                <div style={{ 
                    padding: '24px 24px 0 24px',
                    borderBottom: '1px solid #e8eaed',
                    marginBottom: '0'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                        <h1 style={{ margin: 0, fontSize: '24px', fontWeight: '600', color: '#2c3e50' }}>
                            {i18n.t('Create New Assessment')}
                        </h1>
                        <Button 
                            secondary 
                            onClick={() => navigate('/manage-assessments')}
                        >
                            {i18n.t('Cancel')}
                        </Button>
                    </div>

                    {/* Tab Navigation */}
                    <TabBar>
                        {tabs.map(tab => (
                            <Tab 
                                key={tab.id}
                                selected={activeTab === tab.id}
                                onClick={() => handleTabClick(tab.id)}
                                disabled={!canProceedToTab(tab.id)}
                            >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    {tab.label}
                                    {isTabValid(tab.id) && (
                                        <span style={{ color: '#4caf50', fontSize: '16px' }}>✓</span>
                                    )}
                                </div>
                            </Tab>
                        ))}
                    </TabBar>
                </div>

                {/* Top Navigation */}
                {renderNavigation('top')}

                {/* Tab Content */}
                <div style={{ minHeight: '400px' }}>
            

            <CategoryOptionFormModal
                isOpen={categoryOptionModalOpen}
                onClose={() => {
                    setCategoryOptionModalOpen(false)
                    setEditingCategoryOption(null)
                }}
                onSave={handleCategoryOptionSave}
                categoryOption={editingCategoryOption}
                availableCategoryOptionGroups={[]}
            />

            <CategoryFormModal
                isOpen={categoryModalOpen}
                onClose={() => {
                    setCategoryModalOpen(false)
                    setEditingCategory(null)
                }}
                onSave={handleCategorySave}
                category={editingCategory}
                availableCategoryOptions={categoryOptions}
            />

            <CategoryComboFormModal
                isOpen={categoryComboModalOpen}
                onClose={() => {
                    setCategoryComboModalOpen(false)
                    setEditingCategoryCombo(null)
                }}
                onSave={handleCategoryComboSave}
                categoryCombo={editingCategoryCombo}
                availableCategories={categories}
            />

            <AttributeFormModal
                isOpen={attributeModalOpen}
                onClose={() => {
                    setAttributeModalOpen(false)
                    setEditingAttribute(null)
                }}
                onSave={handleAttributeSave}
                attribute={editingAttribute}
                availableOptionSets={optionSets}
            />

            <OptionSetFormModal
                isOpen={optionSetModalOpen}
                onClose={() => {
                    setOptionSetModalOpen(false)
                    setEditingOptionSet(null)
                }}
                onSave={handleOptionSetSave}
                optionSet={editingOptionSet}
            />        {renderTabContent()}
                </div>

                {/* Footer Navigation */}
                {renderNavigation('bottom')}
            </Card>

            {/* Modals for Manual Metadata Creation */}
            <DatasetFormModal
                isOpen={datasetModalOpen}
                onClose={() => {
                    setDatasetModalOpen(false)
                    setEditingDataset(null)
                }}
                onSave={handleDatasetSave}
                dataset={editingDataset}
                availableDataElements={selectedDataElements}
                availableOrgUnits={selectedOrgUnits}
                availableCategoryOptions={[]}
                availableIndicators={[]}
            />

            <DataElementFormModal
                isOpen={dataElementModalOpen}
                onClose={() => {
                    setDataElementModalOpen(false)
                    setEditingDataElement(null)
                }}
                onSave={handleDataElementSave}
                dataElement={editingDataElement}
                availableDataElementGroups={[
                    { id: 'dqa_group', name: 'DQA Data Elements' },
                    { id: 'health_group', name: 'Health Indicators' },
                    { id: 'population_group', name: 'Population Data' }
                ]}
                availableOptionSets={[]}
                availableCategoryCombos={[]}
            />

            <OrganizationUnitFormModal
                isOpen={orgUnitModalOpen}
                onClose={() => {
                    setOrgUnitModalOpen(false)
                    setEditingOrgUnit(null)
                }}
                onSave={handleOrgUnitSave}
                organizationUnit={editingOrgUnit}
                availableParentOrgUnits={selectedOrgUnits.filter(ou => ou.id !== editingOrgUnit?.id)}
                availableOrgUnitGroups={[
                    { id: 'hospitals', name: 'Hospitals' },
                    { id: 'health_centers', name: 'Health Centers' },
                    { id: 'clinics', name: 'Clinics' },
                    { id: 'public', name: 'Public Facilities' },
                    { id: 'private', name: 'Private Facilities' }
                ]}
                availableOrgUnitGroupSets={[]}
            />

            <CategoryOptionFormModal
                isOpen={categoryOptionModalOpen}
                onClose={() => {
                    setCategoryOptionModalOpen(false)
                    setEditingCategoryOption(null)
                }}
                onSave={handleCategoryOptionSave}
                categoryOption={editingCategoryOption}
                availableCategoryOptionGroups={[]}
            />

            <CategoryFormModal
                isOpen={categoryModalOpen}
                onClose={() => {
                    setCategoryModalOpen(false)
                    setEditingCategory(null)
                }}
                onSave={handleCategorySave}
                category={editingCategory}
                availableCategoryOptions={categoryOptions}
            />

            <CategoryComboFormModal
                isOpen={categoryComboModalOpen}
                onClose={() => {
                    setCategoryComboModalOpen(false)
                    setEditingCategoryCombo(null)
                }}
                onSave={handleCategoryComboSave}
                categoryCombo={editingCategoryCombo}
                availableCategories={categories}
            />

            <AttributeFormModal
                isOpen={attributeModalOpen}
                onClose={() => {
                    setAttributeModalOpen(false)
                    setEditingAttribute(null)
                }}
                onSave={handleAttributeSave}
                attribute={editingAttribute}
                availableOptionSets={optionSets}
            />

            <OptionSetFormModal
                isOpen={optionSetModalOpen}
                onClose={() => {
                    setOptionSetModalOpen(false)
                    setEditingOptionSet(null)
                }}
                onSave={handleOptionSetSave}
                optionSet={editingOptionSet}
            />
        </Box>
    )
}