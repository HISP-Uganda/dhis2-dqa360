import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
    Box, 
    Button, 
    ButtonStrip,
    Card,
    Input,
    CircularLoader,
    NoticeBox,
    Tag,
    InputField,
    SingleSelectField,
    SingleSelectOption,
    Checkbox
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { DHIS2Configuration } from '../Metadata/DHIS2Configuration'
import { DataSetManagement } from '../Metadata/DataSetManagement'
import { OrganisationUnitManagement } from '../Metadata/OrganisationUnitManagement'

export const CreateAssessmentPage = () => {
    const navigate = useNavigate()
    const [currentStep, setCurrentStep] = useState(1)
    const [loading, setLoading] = useState(false)

    // Assessment Data State
    const [assessmentData, setAssessmentData] = useState({
        name: '',
        description: '',
        startDate: '',
        endDate: '',
        assessmentType: 'routine',
        frequency: 'monthly',
        priority: 'medium',
        tags: [],
        notifications: true,
        autoSync: false
    })

    // Wizard State
    const [dhis2Config, setDhis2Config] = useState(null)
    const [selectedDataSet, setSelectedDataSet] = useState(null)
    const [selectedDataElements, setSelectedDataElements] = useState([])
    const [selectedOrgUnits, setSelectedOrgUnits] = useState([])

    const steps = [
        {
            id: 1,
            label: i18n.t('Assessment Details'),
            description: i18n.t('Basic information about your assessment'),
            icon: '📋'
        },
        {
            id: 2,
            label: i18n.t('DHIS2 Connection'),
            description: i18n.t('Connect to your DHIS2 instance'),
            icon: '🔗'
        },
        {
            id: 3,
            label: i18n.t('Dataset Selection'),
            description: i18n.t('Choose datasets and data elements'),
            icon: '📊'
        },
        {
            id: 4,
            label: i18n.t('Organisation Units'),
            description: i18n.t('Select facilities and locations'),
            icon: '🏥'
        },
        {
            id: 5,
            label: i18n.t('Review & Create'),
            description: i18n.t('Review settings and create assessment'),
            icon: '✅'
        }
    ]

    const assessmentTypes = [
        { value: 'routine', label: i18n.t('Routine Assessment') },
        { value: 'special', label: i18n.t('Special Assessment') },
        { value: 'emergency', label: i18n.t('Emergency Assessment') },
        { value: 'baseline', label: i18n.t('Baseline Assessment') },
        { value: 'followup', label: i18n.t('Follow-up Assessment') }
    ]

    const frequencies = [
        { value: 'daily', label: i18n.t('Daily') },
        { value: 'weekly', label: i18n.t('Weekly') },
        { value: 'monthly', label: i18n.t('Monthly') },
        { value: 'quarterly', label: i18n.t('Quarterly') },
        { value: 'annually', label: i18n.t('Annually') },
        { value: 'adhoc', label: i18n.t('Ad-hoc') }
    ]

    const priorities = [
        { value: 'low', label: i18n.t('Low Priority') },
        { value: 'medium', label: i18n.t('Medium Priority') },
        { value: 'high', label: i18n.t('High Priority') },
        { value: 'critical', label: i18n.t('Critical Priority') }
    ]

    const handleNext = () => {
        if (currentStep < steps.length) {
            setCurrentStep(currentStep + 1)
        }
    }

    const handlePrevious = () => {
        if (currentStep > 1) {
            setCurrentStep(currentStep - 1)
        }
    }

    const handleCancel = () => {
        navigate('/manage-assessments')
    }

    const handleCreateAssessment = async () => {
        setLoading(true)
        setError(null)

        try {
            // Import the assessment tools creation logic
            const { createAssessmentTools } = await import('../../utils/assessmentToolsCreator')
            
            // Create the 4 DHIS2 datasets
            const result = await createAssessmentTools({
                dhis2Config,
                selectedDataSet,
                dataElements: selectedDataElements,
                orgUnits: selectedOrgUnits,
                onProgress: (progress) => {
                    console.log('Progress:', progress)
                }
            })

            if (result.success) {
                // Create the assessment object with enhanced data
                const newAssessment = {
                    id: Date.now().toString(),
                    ...assessmentData,
                    dhis2Config: {
                        baseUrl: dhis2Config.baseUrl,
                        username: dhis2Config.username
                        // Don't store password
                    },
                    sourceDataSet: {
                        id: selectedDataSet.id,
                        name: selectedDataSet.displayName
                    },
                    dataElements: selectedDataElements.map(de => ({
                        id: de.id,
                        name: de.displayName
                    })),
                    organisationUnits: selectedOrgUnits.map(ou => ({
                        id: ou.id,
                        name: ou.displayName
                    })),
                    createdDatasets: result.datasets,
                    status: 'active',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                    createdBy: dhis2Config.username,
                    statistics: {
                        totalDataElements: selectedDataElements.length,
                        totalOrgUnits: selectedOrgUnits.length,
                        expectedReports: selectedOrgUnits.length * 4, // 4 datasets
                        completedReports: 0
                    }
                }

                // Save to localStorage (in real app, this would be API call)
                const existingAssessments = JSON.parse(localStorage.getItem('dqa360_assessments') || '[]')
                existingAssessments.push(newAssessment)
                localStorage.setItem('dqa360_assessments', JSON.stringify(existingAssessments))

                // Navigate back to manage assessments
                navigate('/manage-assessments', { 
                    state: { 
                        message: i18n.t('Assessment "{{name}}" created successfully!', { name: assessmentData.name }),
                        type: 'success'
                    }
                })
            } else {
                setError(i18n.t('Failed to create assessment: {{error}}', { error: result.error }))
            }
        } catch (err) {
            console.error('Assessment creation failed:', err)
            setError(i18n.t('Failed to create assessment: {{error}}', { error: err.message }))
        } finally {
            setLoading(false)
        }
    }

    const isStepValid = (step) => {
        switch (step) {
            case 1:
                return assessmentData.name.trim() && assessmentData.startDate && assessmentData.endDate
            case 2:
                return dhis2Config?.configured
            case 3:
                return selectedDataSet && selectedDataElements.length > 0
            case 4:
                return selectedOrgUnits.length > 0
            case 5:
                return true
            default:
                return false
        }
    }

    const renderStepContent = () => {
        switch (currentStep) {
            case 1:
                return (
                    <Box padding="32px">
                        <Box marginBottom="32px" textAlign="center">
                            <Box 
                                display="inline-flex"
                                alignItems="center"
                                justifyContent="center"
                                style={{
                                    width: '64px',
                                    height: '64px',
                                    borderRadius: '50%',
                                    backgroundColor: '#667eea',
                                    color: 'white',
                                    fontSize: '24px',
                                    marginBottom: '16px'
                                }}
                            
                                display="inline-flex"
                                alignItems="center"
                                justifyContent="center"
                            style={{
                                    width: '64px',
                                    height: '64px',
                                    borderRadius: '50%',
                                    backgroundColor: '#667eea'
                               fontSize: '16px',
                                maxWidth: '500px',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                                lineHeight: '1.5'
                            }}>
                                 color: 'white',
                                    fontSize: '24px',
                                    marginBottom:  including name, period, type, and priority level.')}
                         <Box style={{ maxWidth: '800px', margin: '0 auto' }}>
                       }}
                            
                                display="inline-flex"
                                alignItems="center"
                   style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}              justifyContent="center"
                            style={{
                                    width: '64px',
                                    height: '64px',
                                    borderRadius: '50%',
                                    backgroundColor: '#667eea'
                               fontSize: '16px',
                                maxWidth: '500px',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                                lineHeight: '1.5'
                            }}>
                                 color: 'white',
                                    fontSize:  including name, period, type, and priority level.')}
                            </p>
                           marginBottom: '16px'
                                }}
                                helpText={i18n.t('Choose a clear, descriptive name that identifies the purpose of this assessment')}
                                    />
                                </Box>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                📋
                         <Box style={{ maxWidth: '800px', margin: '0 auto' }}>
                            <h3 style={{ 
                                margin: '0 0 8px 0', 
              style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                        helpText={i18n.t('Select the type of assessment based on your data quality needs')}
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}                   fontSize: '24px', 
                                fontWeight: '600',
                                color: '#333'
                            }}>
                                {i18n.t('Assessment Information')}
                            </h3>
                            <p style={{ 
                                margin: 0, 
                                color: '#666', 
                                fontSize: '16px',
                                maxWidth: '500px',
                                marginLeft: 'auto',
                                marginRight: 'auto',
        helpText={i18n.t('Choose a clear, descriptive name that identifies the purpose of this assessment')}
                                    />
                                </Box>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                {i18n.t('Provide basic information about your data quality assessment including name, period, type, and priority level.')}
                            </p>
                        </Box>

                        <Box style={{ maxWidth: '800px', margin: '0 auto' }}>
                                        helpText={i18n.t('Select the type of assessment based on your data quality needs')}
                            <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '32px', marginBottom: '32px' }}>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                    <InputField
                                        label={i18n.t('Assessment Name')}
                                        name="name"
                                        value={assessmentData.name}
                                        onChange={({ value }) => setAssessmentData(prev => ({ ...prev, name: value }))}
                                        placeholder={i18n.t('Enter a descriptive name for your assessment')}
                                        required
                                        helpText={i18n.t('Choose a clear, descriptive name that identifies the purpose of this assessment')}
                                    />
                                </Box>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                    <SingleSelectField
                                        label={i18n.t('Assessment Type')}
                                        selected={assessmentData.assessmentType}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, assessmentType: selected }))}
                                        helpText={i18n.t('Set the priority level to determine resource allocation and urgency')}
                                        helpText={i18n.t('Set the priority level to determine resource allocation and urgency')}
                                        helpText={i18n.t('Select the type of assessment based on your data quality needs')}
                                    >
                                        {assessmentTypes.map(type => (
                                            <SingleSelectOption key={type.value} value={type.value} label={type.label} />
                                        ))}
                                    </SingleSelectField>
                                </Box>
                            </Box>

                            <Box style={{
                                padding: '24px',
                                backgroundColor: '#f8f9fa',
                                borderRadius: '12px',
                                border: '2px solid #e9ecef',
                                marginBottom: '32px'
                            }}>
                                <InputField
                                    label={i18n.t('Description')}
                                    name="description"
                                    value={assessmentData.description}
                                    onChange={({ value }) => setAssessmentData(prev => ({ ...prev, description: value }))}
                                    placeholder={i18n.t('Describe the purpose, scope, and objectives of this assessment...')}
                                    multiline
                                    rows={4}
                                    helpText={i18n.t('Provide details about what this assessment will evaluate and its expected outcomes')}
                                />
                            </Box>

                            <Box style={{
                                padding: '24px',
                                backgroundColor: '#f8f9fa',
                                borderRadius: '12px',
                                border: '2px solid #e9ecef',
                                marginBottom: '32px'
                            }}>
                                <h4 style={{ 
                                    margin: '0 0 16px 0', 
                                    fontSize: '16px', 
                                    fontWeight: '600',
                                    color: '#333'
                                }}>
                                    {i18n.t('Assessment Period')}
                                </h4>
                                <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr 1fr', gap: '24px' }}>
                                    <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '16px', 
                                        fontWeight: '600',
                                        fontSize: '14px',
                                        color: '#333'
                                    }}>
                                        {i18n.t('Assessment Options')}
                                    </label>
                                    <Box display="flex" flexDirection="column" gap="12>
                                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#555' }}>
                                            {i18n.t('Start Date')} *
                                        </label>
                                        <Input
                                            type="date"
                                            value={assessmentData.startDate}
                                                                <p style={{ 
                                        margin: '12px 0 0 0', 
                                        fontSize: '12px', 
                                        color: '#666',
                                        lineHeight: '1.4'
                                    }}>
                                        {i18n.t('Configure additional options for your assessment workflow')}
                                    </Box>
                onChange={({ value }) => setAssessmentData(prev => ({ ...prev, startDate: value }))}
                                            style={{ width: '100%' }}
                                        />
                                    </Box>
                                    <Box>
                                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#555' }}>
                                            {i18n.t('End Date')} *
                                        </label>
                                        <Input
                                            type="date"
                                            value={assessmentData.endDate}
                                            onChange={({ value }) => setAssessmentData(prev => ({ ...prev, endDate: value }))}
              Box                              style={{ width: '100%' }}
                                        />
                                    </Box>
                                    <Box>
                                        <SingleSelectField
                                            label={i18n.t('Frequency')}
                                            selected={assessmentData.frequency}
                                            onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, frequency: selected }))}
                                            helpText={i18n.t('How often will this assessment run?')}
                                        >
                                            {frequencies.map(freq => (
                                                <SingleSelectOption key={freq.value} value={freq.value} label={freq.label} />
                                            ))}
                                        </SingleSelectField>
                                    </Box>
                                </Box>
                            </Box>

                            <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                    <SingleSelectField
                                                       <p style={{ 
                                        margin: '12px 0 0 0', 
                                        fontSize: '12px', 
                                        color: '#666',
                                        lineHeight: '1.4'
                                    }}>
                                        {i18n.t('Configure additional options for your assessment workflow')}
                                    </p>
                     label={i18n.t('Priority Level')}
                                        selected={assessmentData.priority}
                                        onChange={({ selected }) => setAssessmentData(prev => ({ ...prev, priority: selected }))}
                                        helpText={i18n.t('Set the priority level to determine resource allocation and urgency')}
                                    >
                                        {priorities.map(priority => (
                                            <SingleSelectOption key={priority.value} value={priority.value} label={priority.label} />
                                    Box    ))}
                                    </SingleSelectField>
                                </Box>
                                <Box style={{
                                    padding: '24px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '12px',
                                    border: '2px solid #e9ecef'
                                }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '16px', 
                                        fontWeight: '600',
                                        fontSize: '14px',
                                        color: '#333'
                                    }}>
                                        {i18n.t('Assessment Options')}
                                    </Box>
                                    <Box display="flex" flexDirection="column" gap="12px">
                                        <Checkbox
                                            label={i18n.t('Enable notifications')}
                                            checked={assessmentData.notifications}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, notifications: checked }))}
                                        />
                                        <Checkbox
                                            label={i18n.t('Auto-sync with DHIS2')}
                                            checked={assessmentData.autoSync}
                                            onChange={({ checked }) => setAssessmentData(prev => ({ ...prev, autoSync: checked }))}
                                        />
                                    </Box>
                                    <p style={{ 
                                        margin: '12px 0 0 0', 
                                        fontSize: '12px', 
                                        color: '#666',
                                        lineHeight: '1.4'
                                    }}>
                                        {i18n.t('Configure additional options for your assessment workflow')}
                                    </p>
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                )

            case 2:
                return (
                    <Box padding="32px">
                        <Box marginBottom="32px" textAlign="center">
                            <Box 
                                display="inline-flex"
                                alignItems="center"
                                justifyContent="center"
                                style={{
                                    width: '64px',
                                    height: '64px',
                                    borderRadius: '50%',
                                    backgroundColor: '#667eea',
                                    color: 'white',
                                    fontSize: '24px',
                                    marginBottom: '16px'
                                }}
                            >
                                🔗
                            </Box>
                            <h3 style={{ 
                                margin: '0 0 8px 0', 
                                fontSize: '24px', 
                                fontWeight: '600',
                                color: '#333'
                            }}>
                                {i18n.t('DHIS2 Connection')}
                            </h3>
                            <p style={{ 
                                margin: 0, 
                                color: '#666', 
                                fontSize: '16px',
                                maxWidth: '500px',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                                lineHeight: '1.5'
                            }}>
                                {i18n.t('Connect to your DHIS2 instance to access datasets, data elements, and organization units for your assessment.')}
                            </p>
                        </Box>

                        <Box style={{ maxWidth: '800px', margin: '0 auto' }}>
                            <DHIS2Configuration 
                                onConfigured={(config) => {
                                    setDhis2Config(config)
                                }}
                            />
                        </Box>
                    </Box>
                )

            case 3:
                return (
                    <Card>
                        <Box padding="24px">
                            <Box marginBottom="24px">
                                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Dataset Selection')}</h3>
                                <p style={{ margin: 0, color: '#666' }}>
                                    {i18n.t('Choose the source dataset and select relevant data elements for your assessment.')}
                                </p>
                            </Box>

                            {dhis2Config?.configured ? (
                                <DataSetManagement 
                                    dhis2Config={dhis2Config}
                                    onDataSetSelect={(dataSet) => {
                                        setSelectedDataSet(dataSet)
                                    }}
                                    onDataElementsSelect={(dataElements) => {
                                        setSelectedDataElements(dataElements)
                                    }}
                                />
                            ) : (
                                <NoticeBox warning title={i18n.t('DHIS2 Connection Required')}>
                                    {i18n.t('Please complete the DHIS2 connection step first.')}
                                </NoticeBox>
                            )}
                        </Box>
                    </Card>
                )

            case 4:
                return (
                    <Card>
                        <Box padding="24px">
                            <Box marginBottom="24px">
                                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Organisation Units')}</h3>
                                <p style={{ margin: 0, color: '#666' }}>
                                    {i18n.t('Select the facilities and organisation units to include in your assessment.')}
                                </p>
                            </Box>

                            {dhis2Config && selectedDataSet ? (
                                <OrganisationUnitManagement 
                                    dhis2Config={dhis2Config}
                                    selectedDataSet={selectedDataSet}
                                    selectedDataElements={selectedDataElements}
                                    onCreateTemplate={(data) => {
                                        setSelectedOrgUnits(data.organisationUnits || [])
                                    }}
                                />
                            ) : (
                                <NoticeBox warning title={i18n.t('Previous Steps Required')}>
                                    {i18n.t('Please complete the DHIS2 connection and dataset selection steps first.')}
                                </NoticeBox>
                            )}
                        </Box>
                    </Card>
                )

            case 5:
                return (
                    <Card>
                        <Box padding="24px">
                            <Box marginBottom="24px">
                                <h3 style={{ margin: '0 0 8px 0' }}>{i18n.t('Review & Create Assessment')}</h3>
                                <p style={{ margin: 0, color: '#666' }}>
                                    {i18n.t('Review your assessment configuration and create the assessment tools.')}
                                </p>
                            </Box>

                            {error && (
                                <Box marginBottom="16px">
                                    <NoticeBox error title={i18n.t('Error')}>
                                        {error}
                                    </NoticeBox>
                                </Box>
                            )}

                            <Box display="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                                <Box>
                                    <h4>{i18n.t('Assessment Details')}</h4>
                                    <Box padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                                        <p><strong>{i18n.t('Name')}:</strong> {assessmentData.name}</p>
                                        <p><strong>{i18n.t('Type')}:</strong> {assessmentTypes.find(t => t.value === assessmentData.assessmentType)?.label}</p>
                                        <p><strong>{i18n.t('Period')}:</strong> {assessmentData.startDate} to {assessmentData.endDate}</p>
                                        <p><strong>{i18n.t('Frequency')}:</strong> {frequencies.find(f => f.value === assessmentData.frequency)?.label}</p>
                                        <p><strong>{i18n.t('Priority')}:</strong> {priorities.find(p => p.value === assessmentData.priority)?.label}</p>
                                    </Box>
                                </React.Fragment>

                                <React.Fragment>
                                    <h4>{i18n.t('Data Configuration')}</h4>
                                    <Box padding="16px" style={{ backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                                        <p><strong>{i18n.t('DHIS2 Instance')}:</strong> {dhis2Config?.baseUrl}</p>
                                        <p><strong>{i18n.t('Source Dataset')}:</strong> {selectedDataSet?.displayName}</p>
                                        <p><strong>{i18n.t('Data Elements')}:</strong> {selectedDataElements.length} selected</p>
                                        <p><strong>{i18n.t('Organisation Units')}:</strong> {selectedOrgUnits.length} selected</p>
                                    </Box>
                                </Box>
                            </Box>

                            <Box marginTop="24px">
                                <NoticeBox title={i18n.t('What will be created')}>
                                    <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
                                        <li>{i18n.t('Primary Data Collection Tool ({{count}} data elements)', { count: selectedDataElements.length })}</li>
                                        <li>{i18n.t('Summary Analysis Tool (aggregated data)')}</li>
                                        <li>{i18n.t('DHIS2 Comparison Tool (for validation)')}</li>
                                        <li>{i18n.t('Data Correction Tool (for corrections)')}</li>
                                        <li>{i18n.t('Assessment record with full DQ capabilities')}</li>
                                    </ul>
                                </NoticeBox>
                            </Box>

                            {loading && (
                                <Box marginTop="16px" textAlign="center">
                                    <CircularLoader />
                                    <Box marginTop="8px">
                                        <p>{i18n.t('Creating assessment tools...')}</p>
                                        <LinearLoader />
                                    </Box>
                                </Box>
                            )}
                        </Box>
                    </Card>
                )

            default:
                return null
        }
    }

    return (
        <Box style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
            {/* Professional Header */}
            <Box style={{ 
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                padding: '24px 32px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
            }}>
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Box>
                        <h1 style={{ 
                            margin: '0 0 8px 0', 
                            fontSize: '28px', 
                            fontWeight: '700',
                            textShadow: '0 2px 4px rgba(0,0,0,0.3)'
                        }}>
                            {i18n.t('Create New Assessment')}
                        </h1>
                        <p style={{ 
                            margin: 0, 
                            color: 'rgba(255,255,255,0.9)', 
                            fontSize: '16px',
                            fontWeight: '400'
                        }}>
                            {i18n.t('Build a comprehensive data quality assessment in 5 simple steps')}
                        </p>
                    </Box>
                    <Button 
                        secondary 
                        onClick={handleCancel}
                        style={{
                            backgroundColor: 'rgba(255,255,255,0.2)',
                            border: '1px solid rgba(255,255,255,0.3)',
                            color: 'white',
                            fontWeight: '500',
                            padding: '12px 24px'
                        }}
                    >
                        {i18n.t('Cancel')}
                    </Button>
                </Box>
            </Box>

            {/* Enhanced Progress Indicator */}
            <Box padding="32px" style={{ backgroundColor: '#fff', borderBottom: '1px solid #e0e0e0' }}>
                <Box marginBottom="24px" textAlign="center">
                    <h2 style={{ 
                        margin: '0 0 8px 0', 
                        fontSize: '20px', 
                        fontWeight: '600',
                        color: '#333'
                    }}>
                        {steps[currentStep - 1]?.title}
                    </h2>
                    <p style={{ 
                        margin: '0 0 16px 0', 
                        color: '#666', 
                        fontSize: '14px',
                        maxWidth: '600px',
                        marginLeft: 'auto',
                        marginRight: 'auto'
                    }}>
                        {steps[currentStep - 1]?.description}
                    </p>
                    <Box style={{ 
                        backgroundColor: '#f0f0f0', 
                        borderRadius: '8px', 
                        height: '8px', 
                        overflow: 'hidden',
                        marginBottom: '16px'
                    }}>
                        <Box style={{
                            backgroundColor: '#667eea',
                            height: '100%',
                            width: `${Math.round((currentStep / steps.length) * 100)}%`,
                            transition: 'width 0.3s ease',
                            borderRadius: '8px'
                        }} />
                    </Box>
                    <p style={{ 
                        margin: 0, 
                        fontSize: '12px', 
                        color: '#888',
                        fontWeight: '500'
                    }}>
                        Step {currentStep} of {steps.length} • {Math.round((currentStep / steps.length) * 100)}% Complete
                    </p>
                </Box>
                
                <Box display="flex" justifyContent="center" alignItems="center" style={{ gap: '24px' }}>
                    {steps.map((step, index) => (
                        <React.Fragment key={step.id}>
                            <Box 
                                display="flex" 
                                flexDirection="column"
                                alignItems="center"
                                style={{ 
                                    minWidth: '120px',
                                    opacity: currentStep >= step.id ? 1 : 0.6,
                                    transition: 'opacity 0.3s ease'
                                }}
                            >
                                <Box 
                                    display="flex" 
                                    alignItems="center" 
                                    justifyContent="center"
                                    style={{
                                        width: '48px',
                                        height: '48px',
                                        borderRadius: '50%',
                                        backgroundColor: currentStep >= step.id ? '#667eea' : '#e0e0e0',
                                        color: currentStep >= step.id ? '#fff' : '#666',
                                        fontSize: '20px',
                                        marginBottom: '8px',
                                        boxShadow: currentStep === step.id ? '0 4px 12px rgba(102, 126, 234, 0.4)' : 'none',
                                        transform: currentStep === step.id ? 'scale(1.1)' : 'scale(1)',
                                        transition: 'all 0.3s ease'
                                    }}
                                >
                                    {currentStep > step.id ? '✓' : step.icon}
                                </Box>
                                <p style={{ 
                                    margin: '0 0 4px 0', 
                                    fontWeight: currentStep === step.id ? '600' : '500',
                                    color: currentStep >= step.id ? '#667eea' : '#666',
                                    fontSize: '13px',
                                    textAlign: 'center'
                                }}>
                                    {step.label}
                                </p>
                                <p style={{ 
                                    margin: 0, 
                                    fontSize: '11px', 
                                    color: '#999',
                                    textAlign: 'center',
                                    lineHeight: '1.3'
                                }}>
                                    {step.description}
                                </p>
                            </Box>
                            {index < steps.length - 1 && (
                                <Box 
                                    style={{
                                        width: '40px',
                                        height: '3px',
                                        backgroundColor: currentStep > step.id ? '#667eea' : '#e0e0e0',
                                        borderRadius: '2px',
                                        transition: 'background-color 0.3s ease'
                                    }}
                                />
                            )}
                        </React.Fragment>
                    ))}
                </Box>
            </Box>

            {/* Enhanced Content Area */}
            <Box padding="32px" style={{ maxWidth: '1200px', margin: '0 auto', minHeight: '500px' }}>
                <Box style={{
                    backgroundColor: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                    overflow: 'hidden'
                }}>
                    {renderStepContent()}
                </Box>
            </Box>

            {/* Professional Footer Actions */}
            <Box 
                style={{ 
                    background: 'linear-gradient(to right, #f8f9fa, #ffffff)',
                    borderTop: '1px solid #e0e0e0', 
                    padding: '20px 32px',
                    position: 'sticky',
                    bottom: 0,
                    boxShadow: '0 -4px 12px rgba(0,0,0,0.05)'
                }}
            >
                <Box display="flex" justifyContent="space-between" alignItems="center" style={{ maxWidth: '1200px', margin: '0 auto' }}>
                    <Box display="flex" alignItems="center" style={{ gap: '16px' }}>
                        <Tag 
                            positive={currentStep === steps.length}
                            neutral={currentStep < steps.length}
                            style={{ fontSize: '12px', fontWeight: '500' }}
                        >
                            Step {currentStep} of {steps.length}
                        </Tag>
                        {!isStepValid(currentStep) && currentStep < steps.length && (
                            <p style={{ 
                                margin: 0, 
                                fontSize: '12px', 
                                color: '#d32f2f',
                                fontWeight: '500'
                            }}>
                                Please complete all required fields to continue
                            </p>
                        )}
                    </Box>
                    
                    <ButtonStrip>
                        {currentStep > 1 && (
                            <Button 
                                secondary 
                                onClick={handlePrevious} 
                                disabled={loading}
                                style={{
                                    padding: '12px 24px',
                                    fontWeight: '500',
                                    borderRadius: '8px'
                                }}
                            >
                                ← {i18n.t('Previous')}
                            </Button>
                        )}
                        
                        {currentStep < steps.length ? (
                            <Button 
                                primary 
                                onClick={handleNext} 
                                disabled={!isStepValid(currentStep) || loading}
                                style={{
                                    padding: '12px 24px',
                                    fontWeight: '600',
                                    borderRadius: '8px',
                                    background: isStepValid(currentStep) ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : undefined,
                                    border: 'none',
                                    boxShadow: isStepValid(currentStep) ? '0 4px 12px rgba(102, 126, 234, 0.4)' : undefined
                                }}
                            >
                                {i18n.t('Next')} →
                            </Button>
                        ) : (
                            <Button 
                                primary 
                                onClick={handleCreateAssessment} 
                                disabled={!isStepValid(currentStep) || loading}
                                style={{
                                    padding: '12px 32px',
                                    fontWeight: '600',
                                    borderRadius: '8px',
                                    background: isStepValid(currentStep) && !loading ? 'linear-gradient(135deg, #4caf50 0%, #45a049 100%)' : undefined,
                                    border: 'none',
                                    boxShadow: isStepValid(currentStep) && !loading ? '0 4px 12px rgba(76, 175, 80, 0.4)' : undefined
                                }}
                            >
                                {loading ? (
                                    <>
                                        <CircularLoader small /> {i18n.t('Creating Assessment...')}
                                    </>
                                ) : (
                                    <>
                                        ✓ {i18n.t('Create Assessment')}
                                    </>
                                )}
                            </Button>
                        )}
                    </ButtonStrip>
                </Box>
            </Box>
        </Box>
    )
}