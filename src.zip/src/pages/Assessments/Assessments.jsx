import React, { useState } from 'react'
import { 
    Box, 
    Button, 
    Card, 
    DataTable,
    DataTableHead,
    DataTableRow,
    DataTableColumnHeader,
    DataTableBody,
    DataTableCell,
    Tag,
    ButtonStrip,
    Modal,
    ModalTitle,
    ModalContent,
    ModalActions
} from '@dhis2/ui'
import i18n from '@dhis2/d2-i18n'
import { CreateAssessmentForm } from './CreateAssessmentForm'

export const Assessments = () => {
    const [showCreateModal, setShowCreateModal] = useState(false)

    // Mock data - in real app, this would come from API
    const assessments = [
        {
            id: '1',
            name: 'Q4 2024 DQA Assessment',
            status: 'active',
            period: '2024Q4',
            facilities: 45,
            discrepancies: 23,
            createdDate: '2024-01-15'
        },
        {
            id: '2',
            name: 'Q3 2024 DQA Assessment',
            status: 'completed',
            period: '2024Q3',
            facilities: 42,
            discrepancies: 18,
            createdDate: '2024-01-01'
        },
        {
            id: '3',
            name: 'Q2 2024 DQA Assessment',
            status: 'draft',
            period: '2024Q2',
            facilities: 38,
            discrepancies: 0,
            createdDate: '2023-12-20'
        }
    ]

    const getStatusTag = (status) => {
        const statusConfig = {
            active: { color: 'positive', text: i18n.t('Active') },
            completed: { color: 'neutral', text: i18n.t('Completed') },
            draft: { color: 'default', text: i18n.t('Draft') }
        }
        
        const config = statusConfig[status] || statusConfig.draft
        return <Tag positive={config.color === 'positive'} neutral={config.color === 'neutral'}>{config.text}</Tag>
    }

    return (
        <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" marginBottom="24px">
                <div>
                    <h1>{i18n.t('DQA Assessments')}</h1>
                    <p>{i18n.t('Manage and monitor data quality assessments')}</p>
                </div>
                <Button primary onClick={() => setShowCreateModal(true)}>
                    {i18n.t('Create New Assessment')}
                </Button>
            </Box>

            <Card>
                <Box padding="16px">
                    <h3>{i18n.t('Assessment List')}</h3>
                    <DataTable>
                        <DataTableHead>
                            <DataTableRow>
                                <DataTableColumnHeader>
                                    {i18n.t('Assessment Name')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Status')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Period')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Facilities')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Discrepancies')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Created Date')}
                                </DataTableColumnHeader>
                                <DataTableColumnHeader>
                                    {i18n.t('Actions')}
                                </DataTableColumnHeader>
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableBody>
                            {assessments.map(assessment => (
                                <DataTableRow key={assessment.id}>
                                    <DataTableCell>{assessment.name}</DataTableCell>
                                    <DataTableCell>{getStatusTag(assessment.status)}</DataTableCell>
                                    <DataTableCell>{assessment.period}</DataTableCell>
                                    <DataTableCell>{assessment.facilities}</DataTableCell>
                                    <DataTableCell>{assessment.discrepancies}</DataTableCell>
                                    <DataTableCell>{assessment.createdDate}</DataTableCell>
                                    <DataTableCell>
                                        <ButtonStrip>
                                            <Button small>
                                                {i18n.t('View')}
                                            </Button>
                                            <Button small secondary>
                                                {i18n.t('Edit')}
                                            </Button>
                                        </ButtonStrip>
                                    </DataTableCell>
                                </DataTableRow>
                            ))}
                        </DataTableBody>
                    </DataTable>
                </Box>
            </Card>

            {showCreateModal && (
                <Modal large onClose={() => setShowCreateModal(false)}>
                    <ModalTitle>{i18n.t('Create New Assessment')}</ModalTitle>
                    <ModalContent>
                        <CreateAssessmentForm onClose={() => setShowCreateModal(false)} />
                    </ModalContent>
                </Modal>
            )}
        </Box>
    )
}