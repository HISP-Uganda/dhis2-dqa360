import React, { useState } from 'react'
import { useDataQuery } from '@dhis2/app-runtime'
import {
    Box,
    Button,
    ButtonStrip,
    Input,
    InputField,
    TextArea,
    SingleSelect,
    SingleSelectOption,
    MultiSelect,
    MultiSelectOption,
    CircularLoader,
    NoticeBox
} from '@dhis2/ui'
import { useForm, Controller } from 'react-hook-form'
import i18n from '@dhis2/d2-i18n'

const query = {
    dataSets: {
        resource: 'dataSets',
        params: {
            fields: 'id,displayName,periodType,dataElements[id,displayName]',
            paging: false
        }
    },
    organisationUnits: {
        resource: 'organisationUnits',
        params: {
            fields: 'id,displayName,level',
            paging: false,
            filter: 'level:eq:4' // Facility level
        }
    },
    dataElements: {
        resource: 'dataElements',
        params: {
            fields: 'id,displayName,valueType',
            paging: false,
            filter: 'domainType:eq:AGGREGATE'
        }
    }
}

export const CreateAssessmentForm = ({ onClose }) => {
    const { data, loading, error } = useDataQuery(query)
    const [isSubmitting, setIsSubmitting] = useState(false)
    
    const { control, handleSubmit, formState: { errors } } = useForm({
        defaultValues: {
            name: '',
            description: '',
            dataSet: '',
            period: '2024Q4',
            organisationUnits: []
        }
    })

    const onSubmit = async (formData) => {
        setIsSubmitting(true)
        try {
            // Here you would make API call to create assessment
            console.log('Creating assessment:', formData)
            
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000))
            
            onClose()
        } catch (error) {
            console.error('Error creating assessment:', error)
        } finally {
            setIsSubmitting(false)
        }
    }

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" padding="24px">
                <CircularLoader />
            </Box>
        )
    }

    if (error) {
        return (
            <NoticeBox error title={i18n.t('Error loading form data')}>
                {error.message}
            </NoticeBox>
        )
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <Box display="flex" flexDirection="column" gap="16px">
                <Controller
                    name="name"
                    control={control}
                    rules={{ required: i18n.t('Assessment name is required') }}
                    render={({ field }) => (
                        <InputField
                            label={i18n.t('Assessment Name')}
                            required
                            error={!!errors.name}
                            validationText={errors.name?.message}
                        >
                            <Input {...field} placeholder={i18n.t('Enter assessment name')} />
                        </InputField>
                    )}
                />

                <Controller
                    name="description"
                    control={control}
                    render={({ field }) => (
                        <InputField label={i18n.t('Description')}>
                            <TextArea {...field} placeholder={i18n.t('Enter assessment description')} />
                        </InputField>
                    )}
                />

                <Controller
                    name="dataSet"
                    control={control}
                    rules={{ required: i18n.t('Data set is required') }}
                    render={({ field }) => (
                        <InputField
                            label={i18n.t('Data Set')}
                            required
                            error={!!errors.dataSet}
                            validationText={errors.dataSet?.message}
                        >
                            <SingleSelect
                                {...field}
                                placeholder={i18n.t('Select data set')}
                                filterable
                            >
                                {data?.dataSets?.dataSets?.map(dataSet => (
                                    <SingleSelectOption
                                        key={dataSet.id}
                                        value={dataSet.id}
                                        label={dataSet.displayName}
                                    />
                                ))}
                            </SingleSelect>
                        </InputField>
                    )}
                />

                <Controller
                    name="period"
                    control={control}
                    rules={{ required: i18n.t('Period is required') }}
                    render={({ field }) => (
                        <InputField
                            label={i18n.t('Period')}
                            required
                            error={!!errors.period}
                            validationText={errors.period?.message}
                        >
                            <SingleSelect
                                {...field}
                                placeholder={i18n.t('Select period')}
                            >
                                <SingleSelectOption value="2024Q4" label="2024 Q4" />
                                <SingleSelectOption value="2024Q3" label="2024 Q3" />
                                <SingleSelectOption value="2024Q2" label="2024 Q2" />
                                <SingleSelectOption value="2024Q1" label="2024 Q1" />
                            </SingleSelect>
                        </InputField>
                    )}
                />

                <Controller
                    name="organisationUnits"
                    control={control}
                    rules={{ required: i18n.t('At least one facility must be selected') }}
                    render={({ field }) => (
                        <InputField
                            label={i18n.t('Facilities')}
                            required
                            error={!!errors.organisationUnits}
                            validationText={errors.organisationUnits?.message}
                        >
                            <MultiSelect
                                {...field}
                                placeholder={i18n.t('Select facilities')}
                                filterable
                            >
                                {data?.organisationUnits?.organisationUnits?.map(orgUnit => (
                                    <MultiSelectOption
                                        key={orgUnit.id}
                                        value={orgUnit.id}
                                        label={orgUnit.displayName}
                                    />
                                ))}
                            </MultiSelect>
                        </InputField>
                    )}
                />

                <ButtonStrip end>
                    <Button secondary onClick={onClose}>
                        {i18n.t('Cancel')}
                    </Button>
                    <Button primary type="submit" loading={isSubmitting}>
                        {i18n.t('Create Assessment')}
                    </Button>
                </ButtonStrip>
            </Box>
        </form>
    )
}