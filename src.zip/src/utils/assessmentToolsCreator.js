import i18n from '@dhis2/d2-i18n'
import { useDataEngine } from '@dhis2/app-runtime'

// Assessment tool configurations
const ASSESSMENT_TOOLS = [
    {
        name: 'Primary Data Collection Tool',
        suffix: '_PRIMARY',
        description: 'Primary data collection tool for field data entry and validation'
    },
    {
        name: 'Summary Analysis Tool', 
        suffix: '_SUMMARY',
        description: 'Summary analysis tool for aggregated data review and reporting'
    },
    {
        name: 'DHIS2 Comparison Tool',
        suffix: '_DHIS2', 
        description: 'DHIS2 comparison tool for cross-referencing with system data'
    },
    {
        name: 'Data Correction Tool',
        suffix: '_CORRECTION',
        description: 'Data correction tool for identified discrepancies and adjustments'
    }
]

// Default category combo ID (this should be configurable)
const getDefaultCategoryComboId = () => 'bjDvmb4bfuf' // Default category combo

/**
 * Create assessment tools (4 DHIS2 datasets) for a given configuration
 * @param {Object} config - Configuration object
 * @param {Object} config.dhis2Config - DHIS2 connection configuration
 * @param {Object} config.selectedDataSet - Selected source dataset
 * @param {Array} config.dataElements - Selected data elements
 * @param {Array} config.orgUnits - Selected organisation units
 * @param {Function} config.onProgress - Progress callback function
 * @returns {Promise<Object>} Result object with success status and created datasets
 */
export const createAssessmentTools = async (config) => {
    const { dhis2Config, selectedDataSet, dataElements, orgUnits, onProgress } = config
    
    // Validate prerequisites
    if (!dhis2Config?.configured) {
        throw new Error(i18n.t('DHIS2 configuration is required'))
    }
    
    if (!selectedDataSet) {
        throw new Error(i18n.t('Source dataset selection is required'))
    }
    
    if (!dataElements || dataElements.length === 0) {
        throw new Error(i18n.t('At least one data element must be selected'))
    }
    
    if (!orgUnits || orgUnits.length === 0) {
        throw new Error(i18n.t('At least one organisation unit must be selected'))
    }

    console.log('=== Starting Assessment Tool Creation ===')
    console.log('Selected Dataset:', selectedDataSet)
    console.log('Selected Data Elements:', dataElements.length)
    console.log('Selected Org Units:', orgUnits.length)

    const results = {
        success: false,
        createdDatasets: [],
        errors: [],
        summary: {
            total: ASSESSMENT_TOOLS.length,
            successful: 0,
            failed: 0
        }
    }

    // Progress tracking
    const updateProgress = (step, total, message) => {
        if (onProgress) {
            onProgress({
                current: step,
                total: total,
                message: message,
                percentage: Math.round((step / total) * 100)
            })
        }
    }

    try {
        // Step 1: Prepare data elements (ensure they exist)
        updateProgress(1, ASSESSMENT_TOOLS.length + 1, i18n.t('Preparing data elements...'))
        
        const validDataElements = dataElements.filter(de => de && de.id)
        if (validDataElements.length === 0) {
            throw new Error(i18n.t('No valid data elements with IDs found'))
        }

        // Remove duplicates
        const uniqueDataElements = validDataElements.filter((de, index, self) => 
            index === self.findIndex(d => d.id === de.id)
        )

        console.log(`Prepared ${uniqueDataElements.length} unique data elements`)

        // Step 2: Validate organisation units
        const validOrgUnits = orgUnits.filter(ou => ou && ou.id)
        if (validOrgUnits.length === 0) {
            throw new Error(i18n.t('No valid organisation units with IDs found'))
        }

        console.log(`Validated ${validOrgUnits.length} organisation units`)

        // Step 3: Create each assessment tool dataset
        for (let i = 0; i < ASSESSMENT_TOOLS.length; i++) {
            const toolConfig = ASSESSMENT_TOOLS[i]
            const stepNumber = i + 2 // +2 because step 1 was preparation
            
            updateProgress(stepNumber, ASSESSMENT_TOOLS.length + 1, 
                i18n.t('Creating {{toolName}}...', { toolName: toolConfig.name }))

            try {
                const datasetResult = await createSingleDataset({
                    toolConfig,
                    selectedDataSet,
                    dataElements: uniqueDataElements,
                    orgUnits: validOrgUnits,
                    dhis2Config
                })

                if (datasetResult.success) {
                    results.createdDatasets.push(datasetResult.dataSet)
                    results.summary.successful++
                    console.log(`✅ Successfully created: ${toolConfig.name}`)
                } else {
                    results.errors.push({
                        tool: toolConfig.name,
                        error: datasetResult.error
                    })
                    results.summary.failed++
                    console.error(`❌ Failed to create: ${toolConfig.name}`, datasetResult.error)
                }
            } catch (error) {
                results.errors.push({
                    tool: toolConfig.name,
                    error: error.message || error
                })
                results.summary.failed++
                console.error(`❌ Exception creating: ${toolConfig.name}`, error)
            }
        }

        // Final step
        updateProgress(ASSESSMENT_TOOLS.length + 1, ASSESSMENT_TOOLS.length + 1, 
            i18n.t('Assessment creation completed'))

        // Determine overall success
        results.success = results.summary.successful > 0

        console.log('=== Assessment Tool Creation Summary ===')
        console.log(`Total: ${results.summary.total}`)
        console.log(`Successful: ${results.summary.successful}`)
        console.log(`Failed: ${results.summary.failed}`)
        console.log('Created Datasets:', results.createdDatasets.map(ds => ds.name))

        return results

    } catch (error) {
        console.error('❌ Fatal error during assessment creation:', error)
        results.error = error.message || error
        return results
    }
}

/**
 * Create a single dataset for an assessment tool
 */
const createSingleDataset = async ({ toolConfig, selectedDataSet, dataElements, orgUnits, dhis2Config }) => {
    try {
        // Generate unique identifiers
        const timestamp = Date.now().toString().slice(-6)
        const baseDataSetName = selectedDataSet?.displayName || 'Unknown Dataset'
        const baseDataSetCode = selectedDataSet?.code || 'UNKNOWN'
        
        const dataSetName = `${baseDataSetName}${toolConfig.suffix}`
        const dataSetCode = `${baseDataSetCode}${toolConfig.suffix}_${timestamp}`
        
        // Generate intelligent short name with timestamp
        const baseShortName = selectedDataSet?.displayName || 'Unknown Dataset'
        const toolType = toolConfig.suffix.replace('_', ' ').trim()
        const uniqueShortName = `${baseShortName} ${toolType} ${timestamp}`.substring(0, 50)

        // Create dataset object
        const dataSet = {
            name: dataSetName,
            shortName: uniqueShortName,
            code: dataSetCode,
            periodType: selectedDataSet?.periodType || 'Monthly',
            dataSetElements: dataElements.map(de => ({
                dataElement: { id: de.id }
            })),
            organisationUnits: orgUnits.map(ou => ({ id: ou.id })),
            categoryCombo: { id: getDefaultCategoryComboId() },
            description: `${toolConfig.description} - Generated from ${selectedDataSet?.displayName || 'Unknown Dataset'}`,
            expiryDays: 0,
            openFuturePeriods: 0,
            timelyDays: 15,
            publicAccess: 'r-------',
            externalAccess: false
        }

        console.log(`Creating dataset: ${dataSetName}`)
        
        // Create the dataset using DHIS2 API
        const result = await createDataSet({ dataSet, dhis2Config })
        
        return { 
            success: true, 
            dataSet: { 
                ...dataSet, 
                id: result.response.uid,
                toolType: toolConfig.suffix
            } 
        }

    } catch (error) {
        console.error(`Error creating dataset for ${toolConfig.name}:`, error)
        
        // Handle 409 Conflict with retry logic
        if (error.status === 409 || error.httpStatusCode === 409) {
            console.log(`409 Conflict detected for ${toolConfig.name}, trying with more unique identifiers...`)
            
            try {
                // Generate more unique identifiers for retry
                const moreUniqueTimestamp = Date.now().toString()
                const retryDataSetName = `${dataSetName}_${moreUniqueTimestamp.slice(-8)}`
                const retryDataSetCode = `${dataSetCode}_${moreUniqueTimestamp.slice(-8)}`
                const retryShortName = `${uniqueShortName} ${moreUniqueTimestamp.slice(-4)}`.substring(0, 50)
                
                const retryDataSet = {
                    ...dataSet,
                    name: retryDataSetName,
                    shortName: retryShortName,
                    code: retryDataSetCode
                }
                
                console.log(`Retrying dataset creation with unique identifiers`)
                const retryResult = await createDataSet({ dataSet: retryDataSet, dhis2Config })
                
                return { 
                    success: true, 
                    dataSet: { 
                        ...retryDataSet, 
                        id: retryResult.response.uid,
                        toolType: toolConfig.suffix
                    } 
                }
            } catch (retryError) {
                console.error(`Retry also failed for ${toolConfig.name}:`, retryError)
                return { 
                    success: false, 
                    error: `Failed to create dataset even after retry: ${retryError.details?.message || retryError.message || retryError}`
                }
            }
        }
        
        return { 
            success: false, 
            error: error.details?.message || error.message || error
        }
    }
}

/**
 * Create a dataset in DHIS2 using the API
 */
const createDataSet = async ({ dataSet, dhis2Config }) => {
    const baseUrl = dhis2Config.baseUrl.replace(/\/$/, '')
    const auth = btoa(`${dhis2Config.username}:${dhis2Config.password}`)
    
    const response = await fetch(`${baseUrl}/api/dataSets`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Basic ${auth}`
        },
        body: JSON.stringify(dataSet)
    })

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        const error = new Error(`HTTP ${response.status}: ${response.statusText}`)
        error.status = response.status
        error.httpStatusCode = response.status
        error.details = errorData
        throw error
    }

    return await response.json()
}